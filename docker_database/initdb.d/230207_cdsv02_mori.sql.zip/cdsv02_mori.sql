-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2023 年 2 月 07 日 12:06
-- サーバのバージョン： 10.5.13-MariaDB-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cdsv02_mori`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_actionscheduler_actions`
--

CREATE TABLE IF NOT EXISTS `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_actionscheduler_actions`
--

INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(7, 'wp_mail_smtp_summary_report_email', 'complete', '2022-10-10 05:00:00', '2022-10-10 14:00:00', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":5:{s:22:"\0*\0scheduled_timestamp";i:1665378000;s:18:"\0*\0first_timestamp";i:1665378000;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1665378000;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;}', 2, 1, '2023-02-01 12:28:05', '2023-02-01 21:28:05', 0, NULL),
(9, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[3]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2023-02-01 12:28:05', '2023-02-01 21:28:05', 0, NULL),
(10, 'action_scheduler/migration_hook', 'complete', '2022-10-24 06:28:54', '2022-10-24 15:28:54', '[]', 'O:30:"ActionScheduler_SimpleSchedule":2:{s:22:"\0*\0scheduled_timestamp";i:1666592934;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1666592934;}', 1, 1, '2023-02-01 12:28:05', '2023-02-01 21:28:05', 0, NULL),
(11, 'wp_mail_smtp_summary_report_email', 'pending', '2023-02-08 12:28:05', '2023-02-08 21:28:05', '[1]', 'O:32:"ActionScheduler_IntervalSchedule":5:{s:22:"\0*\0scheduled_timestamp";i:1675859285;s:18:"\0*\0first_timestamp";i:1665378000;s:13:"\0*\0recurrence";i:604800;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1675859285;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:604800;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(12, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[4]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2023-02-03 09:32:48', '2023-02-03 18:32:48', 0, NULL),
(13, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[5]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 2, 1, '2023-02-06 15:32:17', '2023-02-07 00:32:17', 0, NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_actionscheduler_claims`
--

CREATE TABLE IF NOT EXISTS `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=2271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_actionscheduler_groups`
--

CREATE TABLE IF NOT EXISTS `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wp_mail_smtp');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_actionscheduler_logs`
--

CREATE TABLE IF NOT EXISTS `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_actionscheduler_logs`
--

INSERT INTO `wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(4, 7, 'action created', '2022-10-07 05:24:16', '2022-10-07 14:24:16'),
(8, 9, 'action created', '2022-10-21 06:29:59', '2022-10-21 15:29:59'),
(9, 10, 'action created', '2022-10-24 06:27:54', '2022-10-24 15:27:54'),
(10, 9, 'action started via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(11, 9, 'action complete via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(12, 7, 'action started via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(13, 7, 'action complete via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(14, 11, 'action created', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(15, 10, 'action started via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(16, 10, 'action complete via Async Request', '2023-02-01 12:28:05', '2023-02-01 21:28:05'),
(17, 12, 'action created', '2023-02-03 09:31:38', '2023-02-03 18:31:38'),
(18, 12, 'action started via WP Cron', '2023-02-03 09:32:48', '2023-02-03 18:32:48'),
(19, 12, 'action complete via WP Cron', '2023-02-03 09:32:48', '2023-02-03 18:32:48'),
(20, 13, 'action created', '2023-02-06 15:31:36', '2023-02-07 00:31:36'),
(21, 13, 'action started via WP Cron', '2023-02-06 15:32:17', '2023-02-07 00:32:17'),
(22, 13, 'action complete via WP Cron', '2023-02-06 15:32:17', '2023-02-07 00:32:17');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'WordPress コメントの投稿者', 'wapuu@wordpress.example', 'https://ja.wordpress.org/', '', '2022-10-07 13:42:12', '2022-10-07 04:42:12', 'こんにちは、これはコメントです。\nコメントの承認、編集、削除を始めるにはダッシュボードの「コメント」画面にアクセスしてください。\nコメントのアバターは「<a href="https://ja.gravatar.com/">Gravatar</a>」から取得されます。', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fb3d_pages`
--

CREATE TABLE IF NOT EXISTS `wp_fb3d_pages` (
  `page_ID` bigint(20) unsigned NOT NULL,
  `page_post_ID` bigint(20) unsigned NOT NULL,
  `page_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_source_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_source_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_thumbnail_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_thumbnail_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_meta_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `page_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_ff_scheduled_actions`
--

CREATE TABLE IF NOT EXISTS `wp_ff_scheduled_actions` (
  `id` bigint(20) unsigned NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_id` bigint(20) unsigned DEFAULT NULL,
  `origin_id` bigint(20) unsigned DEFAULT NULL,
  `feed_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT 'submission_action',
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `note` tinytext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `retry_count` int(10) unsigned DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_entry_details`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_entry_details` (
  `id` bigint(20) unsigned NOT NULL,
  `form_id` bigint(20) unsigned DEFAULT NULL,
  `submission_id` bigint(20) unsigned DEFAULT NULL,
  `field_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `sub_field_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `field_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_entry_details`
--

INSERT INTO `wp_fluentform_entry_details` (`id`, `form_id`, `submission_id`, `field_name`, `sub_field_name`, `field_value`) VALUES
(1, 3, 1, 'ak_js', '', '1675121013890'),
(2, 3, 1, 'names', 'first_name', '青木洋二'),
(3, 3, 1, 'names_1', 'first_name', 'アオキヨウジ'),
(4, 3, 1, 'email', '', 'konayukitabetai@docomo.ne.jp'),
(5, 3, 1, 'tel', '', '08096180042'),
(6, 3, 1, 'address', '', '帯広市自由が丘4-3-1'),
(7, 3, 1, 'message', '', 'こんにちは。\r\n問合せではないのですが、どうしてもお伝えしたく、あえてこちらに送らせてもらいます。\r\n長年リスナーとして聞いてきた森君が新たな挑戦を始めると言う事、様々な声があるでしょうが僕は大応援です。\r\nこれからは人との距離感の種類が変わり、戸惑う事も多いと思いますが、まずはしっかり地元の為に働いて政治を学んで下さい。\r\nしかる後、できれば北海道全体を代弁出来る議員に成長して欲しいと思います。\r\n森君は、道民全部の人ですから。\r\n今から志を高く掲げ、まずは足元から地道に歩き続けて下さい。\r\n僕は厚別在住ではありませんが、何かお手伝い出来る事があるかもしれないと考えています。\r\n昨年独立開業し、ツイッターからは離れていましたが、powdereaterと言うアカウントですので応援の為に再開させてみます。\r\n僕の地元には石川さんがいます。逢坂さんや徳永さんも応援していますが、これから一押しは森君になります。\r\nどうか、倦まず弛まず、サンダーロードを闊歩して行って下さい。\r\n健康と家族を大切に、頑張れ！'),
(8, 3, 1, 'terms-n-condition', '', 'on'),
(9, 3, 1, 'ak_bib', '', '1675121018330'),
(10, 3, 1, 'ak_bfs', '', '1675121743703'),
(11, 3, 1, 'ak_bkpc', '', '1090'),
(12, 3, 1, 'ak_bkp', '', '14,233;13,188;13,270;15,1090;13,169;13,122;14,153;11,103;12,257;13,1127;13,168;12,909;17,204;13,149;12,239;13,258;14,188;14,150;15,154;13,174;9,129;11,163;16,1979;14,392;16,380;13,604;14,154;11,1481;12,168;11,156;11,1157;14,204;17,1041;12,1221;13,206;11,273;14,304;12,791;12,722;12,208;12,172;13,169;8,133;13,1016;14,253;12,541;13,173;10,132;13,147;12,286;15,420;12,290;13,153;13,762;12,149;14,140;14,468;13,423;14,202;14,136;15,304;15,317;11,1059;14,239;14,136;14,136;12,154;11,427;12,1155;13,271;11,358;12,189;11,2110;12,710;13,170;13,170;11,2814;14,286;14,223;12,135;15,156;14,356;13,151;19,568;12,4483;14,2392;12,337;13,356;12,291;15,237;15,803;11,156;13,234;13,1024;12,255;16,891;8,116;12,246;8,136;9,125;'),
(13, 3, 1, 'ak_bmc', '', '56;24,7224;18,7350;17,7603;14,5818;10,16790;3,2892;8,1689;1,467041;1,210737;'),
(14, 3, 1, 'ak_bmcc', '', '10'),
(15, 3, 1, 'ak_bck', '', '207;208;269;290;292;381;437;437;444;444;497;497;539;539;539;554;558;567;567;573;585;661;706;706;706;789;789;789;789;789;789;789;789;789;801;801;801;801;801;801;808;981;981;981;993;1051;1058'),
(16, 3, 1, 'ak_btmc', '', '13'),
(17, 3, 1, 'ak_bsc', '', '9'),
(18, 3, 1, 'ak_bte', '', '81;90,7186;80,7294;80,7544;93,5737;46,16762;157,2746;328,892;80,393;126,1010;158,1141;374,436913;93,27211;142,53309;479,8685;410,491;410,6545;342,1647;442,2984;361,511;308,5073;243,123785;109,4487;'),
(19, 3, 1, 'ak_btec', '', '23'),
(20, 3, 2, 'ak_js', '', '1675130453203'),
(21, 3, 2, 'names', 'first_name', '伊藤　健太'),
(22, 3, 2, 'names_1', 'first_name', 'イトウ　ケンタ'),
(23, 3, 2, 'email', '', 'itoukenta.cdp@gmail.com'),
(24, 3, 2, 'tel', '', '09028788828'),
(25, 3, 2, 'address', '', '登別市千歳町４－５－２０５'),
(26, 3, 2, 'message', '', '選挙アカデミーでご一緒させていただきました、登別市議会議員の伊藤健太です。\r\n\r\n次期統一地方選挙へ向けて\r\nともに頑張りましょう！\r\n\r\n今後ともよろしくお願いいたします！'),
(27, 3, 2, 'terms-n-condition', '', 'on'),
(28, 3, 2, 'ak_bib', '', '1675130456981'),
(29, 3, 2, 'ak_bfs', '', '1675130682561'),
(30, 3, 2, 'ak_bkpc', '', '372'),
(31, 3, 2, 'ak_bkp', '', '14,122;20,270;13,131;16,120;16,201;13;12,153;14,206;11,117;14,140;12,136;10,120;19,1676;14,234;11,135;12,139;13,122;14,271;13,119;13,121;13,204;16;11,137;13,1757;12,121;13,154;16,775;12,1333;13,171;13,756;11,153;12,1325;13,271;12,103;12,206;13,137;12,689;22,222;14,2615;11,569;11,140;13,122;8,225;14,422;12,904;11,672;12,824;12,120;13,139;12,572;12,388;14,138;12,104;12,204;12,139;12,122;12,587;12;11,137;12,157;11,204;13,157;13,154;12,154;12,139;10,119;12,159;13,188;18;16,147;12,168;14,154;12,103;15,1407;8,80;15,1313;14,136;13,1370;11,100;20,1045;14,128;8,198;13,331;13,121;17,121;14,516;16,238;14,117;11,82;14,2044;19,422;15,113;15,119;18,501;12;9,120;9,124;8,125;9,142;12,732;'),
(32, 3, 2, 'ak_bmc', '', '39;18,6675;11,6499;15,22858;18,68760;5,17658;3,94375;6,10086;2,640;'),
(33, 3, 2, 'ak_bmcc', '', '9'),
(34, 3, 2, 'ak_bck', '', '28;28;28;28;28;28;28;28;28;37;87;104;269;269;269;269;269;269;269;269;269;269;269;269;269;269;269;269'),
(35, 3, 2, 'ak_bsc', '', '8'),
(36, 3, 2, 'ak_bte', '', '79;62,6647;75,6446;76,22790;64,68705;67,17620;66,94311;95,9960;41,644;'),
(37, 3, 2, 'ak_btec', '', '9'),
(38, 3, 3, 'ak_js', '', '1675245097408'),
(39, 3, 3, 'names', 'first_name', '平沼祐里'),
(40, 3, 3, 'names_1', 'first_name', 'ヒラヌマユリ'),
(41, 3, 3, 'email', '', 'zashikibuta2021@gmail.com'),
(42, 3, 3, 'tel', '', '09034624079'),
(43, 3, 3, 'address', '', '北海道函館市花園町31-7-504'),
(44, 3, 3, 'message', '', 'お問い合わせではないのですが\r\nTwitterアカウントの背景\r\nASAMORIのロゴははずしたほうがよいとおもいますがいつまでもairgの看板は背負わないでほしいです\r\n\r\n\r\n私はノースウェブ　カツノリさんのリスナーだけど朝moriの選曲は好きでした\r\n\r\n私は厚別区民でした\r\n厚別区から頑張ってください'),
(45, 3, 3, 'terms-n-condition', '', 'on'),
(46, 3, 3, 'ak_bib', '', '1675245114400'),
(47, 3, 3, 'ak_bfs', '', '1675245456425'),
(48, 3, 3, 'ak_bkpc', '', '527'),
(49, 3, 3, 'ak_bkp', '', '10,1009;17,582;14,1088;10,219;13,223;10,153;9,158;9,807;12,175;9,170;8,159;9,141;10,241;8,208;9,159;9,174;9,608;9,175;9,140;9,241;9,158;12,141;15,1336;9,321;11,258;11,189;9,173;11,424;10,189;10,156;11,174;9,155;10,209;10,189;13,890;9,255;10,173;12,158;13,654;10,170;8,491;10,158;10,404;10,174;9,319;10,174;9,190;10,191;9,107;9,442;9,141;10,224;10,156;10,141;9,757;13,189;10,238;9,191;10,157;10,157;12,324;10,187;7,193;9,158;11,140;11,204;14,889;9,1170;10,188;9,908;10,192;10,1270;12,420;11,259;10,190;10,156;9,191;9,524;10,191;9,173;10,174;10,157;11,221;16;9;10,157;9,209;10,156;10,156;10,191;9,207;10,174;10,173;9,141;11,189;11,208;13,171;9,172;10,174;9,140;'),
(50, 3, 3, 'ak_bmc', '', '43;22,3600;17,3776;16,4735;12,4929;8,5492;0,92793;1,1776;0,28946;1,36754;0,1708;0,14141;1,2203;0,711;0,12709;0,925;0,666;4,124667;2,1110;1,1140;'),
(51, 3, 3, 'ak_bmcc', '', '20'),
(52, 3, 3, 'ak_bck', '', '80;80;122;127;127;127;127;127;127;128;134;134;169;169;187;187;187;187;199;223;264;266;266;289;289;289;289;293;293;293;323;340;340;343;343;343;356;365;396;396;405;405;408;413;428;457;457'),
(53, 3, 3, 'ak_btmc', '', '8'),
(54, 3, 3, 'ak_bsc', '', '10'),
(55, 3, 3, 'ak_bte', '', '131;573,10639;194,872;95,623;48,1705;282,3048;44,264;47,3756;43,4704;8,4939;45,5461;43,92731;25,1757;42,28900;15,36751;39,1669;42,14079;59,2159;43,674;309,11760;40,575;23,927;41,610;61,3624;399,119504;83,1024;40,1070;43,1108;'),
(56, 3, 3, 'ak_btec', '', '28');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_forms`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_forms` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT 'Draft',
  `appearance_settings` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `form_fields` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_payment` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `conditions` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_forms`
--

INSERT INTO `wp_fluentform_forms` (`id`, `title`, `status`, `appearance_settings`, `form_fields`, `has_payment`, `type`, `conditions`, `created_by`, `created_at`, `updated_at`) VALUES
(3, 'お問い合わせ', 'published', NULL, '{"fields":[{"index":0,"element":"input_name","attributes":{"name":"names","data-type":"name-element"},"settings":{"container_class":"","admin_field_label":"Name","conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]},"label_placement":""},"fields":{"first_name":{"element":"input_text","attributes":{"type":"text","name":"first_name","value":"","id":"","class":"","placeholder":"山田　太郎"},"settings":{"container_class":"","label":"お名前","help_message":"","visible":true,"validation_rules":{"required":{"value":true,"message":"名前を入力してください"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"middle_name":{"element":"input_text","attributes":{"type":"text","name":"middle_name","value":"","id":"","class":"","placeholder":"","required":false},"settings":{"container_class":"","label":"Middle Name","help_message":"","error_message":"","visible":false,"validation_rules":{"required":{"value":false,"message":"This field is required"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"last_name":{"element":"input_text","attributes":{"type":"text","name":"last_name","value":"","id":"","class":"","placeholder":"Last Name","required":false},"settings":{"container_class":"","label":"Last Name","help_message":"","error_message":"","visible":false,"validation_rules":{"required":{"value":false,"message":"This field is required"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}}},"editor_options":{"title":"Name Fields","element":"name-fields","icon_class":"ff-edit-name","template":"nameFields"},"uniqElKey":"el_1570866006692"},{"index":0,"element":"input_name","attributes":{"name":"names_1","data-type":"name-element"},"settings":{"container_class":"","admin_field_label":"Name","conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]},"label_placement":"top"},"fields":{"first_name":{"element":"input_text","attributes":{"type":"text","name":"first_name","value":"","id":"","class":"","placeholder":"ヤマダ　タロウ","maxlength":""},"settings":{"container_class":"","label":"お名前(フリガナ)","help_message":"","visible":true,"validation_rules":{"required":{"value":true,"message":"フリガナを入力してください。"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"middle_name":{"element":"input_text","attributes":{"type":"text","name":"middle_name","value":"","id":"","class":"","placeholder":"Middle Name","required":false,"maxlength":""},"settings":{"container_class":"","label":"Middle Name","help_message":"","error_message":"","visible":false,"validation_rules":{"required":{"value":false,"message":"This field is required"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}},"last_name":{"element":"input_text","attributes":{"type":"text","name":"last_name","value":"","id":"","class":"","placeholder":"Last Name","required":false,"maxlength":""},"settings":{"container_class":"","label":"Last Name","help_message":"","error_message":"","visible":false,"validation_rules":{"required":{"value":false,"message":"This field is required"}},"conditional_logics":[]},"editor_options":{"template":"inputText"}}},"editor_options":{"title":"Name Fields","element":"name-fields","icon_class":"ff-edit-name","template":"nameFields"},"uniqElKey":"el_1666665664438"},{"index":1,"element":"input_email","attributes":{"type":"email","name":"email","value":"","id":"","class":"","placeholder":"emailaddress@mori-kiyonori.com"},"settings":{"container_class":"","label":"メールアドレス","label_placement":"","help_message":"","admin_field_label":"メールアドレス","validation_rules":{"required":{"value":true,"message":"メールアドレスを入力してください。"},"email":{"value":true,"message":"有効なe-mailを入力してください。"}},"conditional_logics":[],"is_unique":"no","unique_validation_message":"Email address need to be unique.","prefix_label":"","suffix_label":""},"editor_options":{"title":"Email Address","icon_class":"ff-edit-email","template":"inputText"},"uniqElKey":"el_1664845551870"},{"index":2,"element":"input_text","attributes":{"type":"text","name":"tel","value":"","class":"","placeholder":"09012345678","maxlength":""},"settings":{"container_class":"","label":"連絡先","label_placement":"","admin_field_label":"連絡先","help_message":"","prefix_label":"","suffix_label":"","validation_rules":{"required":{"value":true,"message":"連絡先を入力してください。"}},"conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]},"is_unique":"no","unique_validation_message":"This value need to be unique."},"editor_options":{"title":"Simple Text","icon_class":"ff-edit-text","template":"inputText"},"uniqElKey":"el_1664845742912"},{"index":2,"element":"input_text","attributes":{"type":"text","name":"address","value":"","class":"","placeholder":"","maxlength":""},"settings":{"container_class":"","label":"ご住所","label_placement":"","admin_field_label":"ご住所","help_message":"","prefix_label":"","suffix_label":"","validation_rules":{"required":{"value":true,"message":"住所を入力してください。"}},"conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]},"is_unique":"no","unique_validation_message":"This value need to be unique."},"editor_options":{"title":"Simple Text","icon_class":"ff-edit-text","template":"inputText"},"uniqElKey":"el_1664845655978"},{"index":3,"element":"textarea","attributes":{"name":"message","value":"","id":"","class":"","placeholder":"お問い合わせ内容","rows":"8","cols":2,"maxlength":""},"settings":{"container_class":"","label":"お問い合わせ内容","admin_field_label":"お問い合わせ内容","label_placement":"","help_message":"","validation_rules":{"required":{"value":true,"message":"必須項目です。"}},"conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]}},"editor_options":{"title":"Text Area","icon_class":"ff-edit-textarea","template":"inputTextarea"},"uniqElKey":"el_1570879001207"},{"index":5,"element":"terms_and_condition","attributes":{"type":"checkbox","name":"terms-n-condition","value":false,"class":""},"settings":{"tnc_html":"<p>個人情報の取扱いについて同意する</p>\\n<p class=\\"mt-2\\"><a style=\\"text-decoration: underline; color: skyblue;\\" href=\\"/privacy.html\\" target=\\"_blank\\" rel=\\"noopener\\">「ウェブサイトにおける個人情報の取扱いについて」</a> をご確認いただき、宜しければ「個人情報の取扱いについて同意する」にチェックをして、内容を送信して下さい。</p>","has_checkbox":true,"admin_field_label":"個人情報取扱の同意確認","container_class":"","validation_rules":{"required":{"value":true,"message":"必須項目です。"}},"conditional_logics":{"type":"any","status":false,"conditions":[{"field":"","value":"","operator":""}]}},"editor_options":{"title":"Terms & Conditions","icon_class":"ff-edit-terms-condition","template":"termsCheckbox"},"uniqElKey":"el_1664766139671"},{"index":2,"element":"recaptcha","attributes":{"name":"g-recaptcha-response"},"settings":{"label":"","label_placement":"","validation_rules":[]},"editor_options":{"title":"reCaptcha","icon_class":"ff-edit-recaptha","why_disabled_modal":"recaptcha","template":"recaptcha"},"uniqElKey":"el_16752527455320.05859574385993005"}],"submitButton":{"uniqElKey":"el_1524065200616","element":"button","attributes":{"type":"submit","class":"btn btn-more btn-primary"},"settings":{"align":"center","button_style":"","container_class":"","help_message":"","background_color":"","button_size":"lg","color":"","button_ui":{"type":"default","text":"お問い合わせ内容を送信","img_url":""},"normal_styles":{"backgroundColor":"rgba(0, 178, 146, 1)","borderColor":"rgba(0, 178, 146, 1)","color":"#ffffff","borderRadius":"50","minWidth":""},"hover_styles":{"backgroundColor":"rgba(5, 61, 150, 1)","borderColor":"rgba(5, 61, 150, 1)","color":"#FFFFFF","borderRadius":"50","minWidth":""},"current_state":"hover_styles"},"editor_options":{"title":"Submit Button"}}}', 0, '', NULL, 1, NULL, '2023-02-01 11:59:11');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_form_analytics`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_form_analytics` (
  `id` int(10) unsigned NOT NULL,
  `form_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `source_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `platform` char(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `browser` char(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip` char(15) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `count` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_form_analytics`
--

INSERT INTO `wp_fluentform_form_analytics` (`id`, `form_id`, `user_id`, `source_url`, `platform`, `browser`, `city`, `country`, `ip`, `count`, `created_at`) VALUES
(1, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '203.181.51.79', 13, '2023-01-27 16:49:23'),
(2, 3, 0, '', 'Android', 'Chrome', NULL, NULL, '66.249.79.161', 1, '2023-01-27 16:51:46'),
(3, 3, 0, '', 'unknown', 'GoogleBot', NULL, NULL, '66.249.79.191', 1, '2023-01-27 18:44:14'),
(4, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '14.9.148.193', 6, '2023-01-27 21:06:26'),
(5, 3, 0, 'http://localhost:8081/contact.html', 'Apple', 'Chrome', NULL, NULL, '14.9.148.193', 2, '2023-01-28 14:47:55'),
(6, 3, 0, 'http://localhost:8081/', 'Apple', 'Chrome', NULL, NULL, '121.1.137.98', 12, '2023-01-29 04:05:37'),
(7, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '14.9.129.192', 1, '2023-01-30 03:42:41'),
(8, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '1.75.234.1', 1, '2023-01-30 06:15:18'),
(9, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '220.220.254.49', 1, '2023-01-30 07:25:22'),
(10, 3, 0, 'http://localhost:8081/newslist.html', 'iPhone', 'iPhone', NULL, NULL, '121.1.137.98', 1, '2023-01-30 09:20:37'),
(11, 3, 0, 'http://localhost:8081/newslist.html', 'Windows', 'Opera', NULL, NULL, '219.111.13.233', 1, '2023-01-30 11:35:07'),
(12, 3, 0, 'http://localhost:8081/8.html', 'iPhone', 'iPhone', NULL, NULL, '175.134.83.17', 1, '2023-01-30 12:21:31'),
(13, 3, 0, '', 'unknown', 'Chrome', NULL, NULL, '157.55.39.41', 1, '2023-01-30 21:46:43'),
(14, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '49.97.26.230', 1, '2023-01-30 23:23:33'),
(15, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '14.9.128.97', 1, '2023-01-30 23:38:38'),
(16, 3, 0, '', 'Android', 'Chrome', NULL, NULL, '66.249.79.32', 4, '2023-01-31 00:56:56'),
(17, 3, 0, 'http://localhost:8081/8.html', 'iPhone', 'iPhone', NULL, NULL, '153.173.22.145', 1, '2023-01-31 00:59:50'),
(18, 3, 0, 'http://localhost:8081/8.html', 'iPhone', 'iPhone', NULL, NULL, '49.105.68.65', 1, '2023-01-31 01:25:15'),
(19, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '58.98.114.85', 1, '2023-01-31 01:42:27'),
(20, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '153.170.12.120', 1, '2023-01-31 02:00:53'),
(21, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.206.153.25', 1, '2023-01-31 02:01:30'),
(22, 3, 0, 'http://localhost:8081/newslist.html', 'Apple', 'Chrome', NULL, NULL, '203.181.51.79', 1, '2023-01-31 02:19:47'),
(23, 3, 0, '', 'unknown', 'Chrome', NULL, NULL, '52.167.144.36', 10, '2023-01-31 02:20:06'),
(24, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.169.3.237', 1, '2023-01-31 02:40:58'),
(25, 3, 0, 'http://localhost:8081/', 'unknown', 'Mozilla', NULL, NULL, '207.241.235.229', 1, '2023-01-31 02:43:21'),
(26, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '210.237.234.238', 1, '2023-01-31 02:56:32'),
(27, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '1.75.229.227', 1, '2023-01-31 02:57:08'),
(28, 3, 0, 'http://localhost:8081/newslist.html', 'Windows', 'Chrome', NULL, NULL, '126.237.169.28', 1, '2023-01-31 02:58:39'),
(29, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '58.93.168.121', 1, '2023-01-31 03:04:54'),
(30, 3, 0, '', 'Apple', 'Chrome', NULL, NULL, '121.1.137.98', 7, '2023-01-31 03:13:27'),
(31, 3, 0, 'http://localhost:8081/privacy-policy.html', 'Apple', 'Chrome', NULL, NULL, '121.1.137.98', 1, '2023-01-31 03:19:47'),
(32, 3, 0, 'http://localhost:8081/', 'Apple', 'Chrome', NULL, NULL, '153.206.62.175', 1, '2023-01-31 03:32:14'),
(33, 3, 0, 'http://localhost:8081/18.html', 'Windows', 'Chrome', NULL, NULL, '153.230.12.217', 1, '2023-01-31 03:32:52'),
(34, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '133.106.177.178', 1, '2023-01-31 03:37:18'),
(35, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.229.209.155', 1, '2023-01-31 03:57:59'),
(36, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '126.35.150.105', 1, '2023-01-31 05:09:28'),
(37, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '61.214.18.31', 1, '2023-01-31 05:19:54'),
(38, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '153.173.4.11', 2, '2023-01-31 05:29:50'),
(39, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '106.128.39.104', 1, '2023-01-31 05:32:26'),
(40, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '210.148.94.239', 1, '2023-01-31 05:35:56'),
(41, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '220.220.223.2', 1, '2023-01-31 06:46:02'),
(42, 3, 0, 'http://localhost:8081/18.html', 'Windows', 'Chrome', NULL, NULL, '106.186.232.237', 1, '2023-01-31 07:00:14'),
(43, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '125.172.4.78', 1, '2023-01-31 07:21:38'),
(44, 3, 0, 'http://localhost:8081/', 'iPad', 'iPad', NULL, NULL, '153.166.47.201', 1, '2023-01-31 08:45:29'),
(45, 3, 0, 'http://localhost:8081/8.html', 'Android', 'Chrome', NULL, NULL, '126.236.138.187', 1, '2023-01-31 09:52:56'),
(46, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.206.156.53', 1, '2023-01-31 11:05:35'),
(47, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '1.75.234.123', 1, '2023-01-31 11:18:58'),
(48, 3, 0, 'http://localhost:8081/newslist.html', 'iPhone', 'iPhone', NULL, NULL, '121.109.108.111', 1, '2023-01-31 12:17:38'),
(49, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '60.113.82.13', 2, '2023-01-31 12:24:11'),
(50, 3, 0, 'http://localhost:8081/', 'Apple', 'Chrome', NULL, NULL, '133.32.129.226', 1, '2023-01-31 12:33:36'),
(51, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '114.185.45.172', 1, '2023-01-31 12:43:41'),
(52, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '106.185.150.245', 1, '2023-01-31 13:22:19'),
(53, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '1.112.250.119', 1, '2023-01-31 13:29:55'),
(54, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '14.9.128.32', 1, '2023-01-31 14:03:39'),
(55, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '114.184.11.79', 1, '2023-01-31 14:56:58'),
(56, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '175.133.149.249', 1, '2023-01-31 23:29:03'),
(57, 3, 0, 'https://www.google.com/', 'Windows', 'Chrome', NULL, NULL, '121.1.137.98', 1, '2023-02-01 01:01:00'),
(58, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '49.105.76.6', 1, '2023-02-01 01:08:02'),
(59, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.238.192.3', 1, '2023-02-01 01:09:43'),
(60, 3, 0, 'http://localhost:8081/1.html', 'Android', 'Chrome', NULL, NULL, '126.166.130.17', 1, '2023-02-01 04:05:35'),
(61, 3, 0, '', 'Android', 'Android', NULL, NULL, '126.166.130.17', 1, '2023-02-01 04:05:35'),
(62, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.209.152.17', 1, '2023-02-01 04:51:31'),
(63, 3, 0, '', 'unknown', 'Mozilla', NULL, NULL, '51.222.253.12', 1, '2023-02-01 05:20:19'),
(64, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '61.25.0.94', 1, '2023-02-01 05:31:56'),
(65, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '118.157.114.215', 1, '2023-02-01 06:58:56'),
(66, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '133.187.4.141', 1, '2023-02-01 07:02:16'),
(67, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '60.114.121.27', 1, '2023-02-01 07:14:29'),
(68, 3, 0, 'http://localhost:8081/newslist.html', 'Windows', 'Chrome', NULL, NULL, '153.246.149.167', 1, '2023-02-01 08:37:16'),
(69, 3, 0, 'http://localhost:8081/newslist.html', 'Windows', 'Chrome', NULL, NULL, '175.131.233.85', 1, '2023-02-01 09:49:47'),
(70, 3, 0, 'http://localhost:8081/18.html', 'Android', 'Chrome', NULL, NULL, '60.35.31.200', 1, '2023-02-01 11:48:37'),
(71, 3, 0, 'http://localhost:8081/', 'iPhone', 'Chrome', NULL, NULL, '126.205.255.112', 1, '2023-02-01 12:49:42'),
(72, 3, 0, '', 'unknown', 'unknown', NULL, NULL, '18.183.14.179', 1, '2023-02-02 00:33:30'),
(73, 3, 0, '', 'unknown', 'unknown', NULL, NULL, '43.207.155.163', 1, '2023-02-02 00:34:43'),
(74, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '36.240.100.35', 1, '2023-02-02 02:49:23'),
(75, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '126.254.138.189', 2, '2023-02-02 04:40:23'),
(76, 3, 0, '', 'unknown', 'Mozilla', NULL, NULL, '72.13.46.6', 1, '2023-02-02 05:44:47'),
(77, 3, 0, 'http://localhost:8081/', 'Windows', 'Firefox', NULL, NULL, '210.128.201.102', 1, '2023-02-02 05:53:56'),
(78, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '115.65.76.8', 1, '2023-02-02 08:47:30'),
(79, 3, 0, '', 'unknown', 'GoogleBot', NULL, NULL, '66.249.79.59', 1, '2023-02-02 11:21:52'),
(80, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '121.105.42.177', 1, '2023-02-02 13:55:23'),
(81, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '133.202.126.171', 1, '2023-02-03 05:49:13'),
(82, 3, 0, '', 'unknown', 'unknown', NULL, NULL, '35.72.33.57', 1, '2023-02-03 07:35:53'),
(83, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '153.205.91.69', 1, '2023-02-03 07:49:50'),
(84, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '221.191.70.161', 1, '2023-02-03 08:00:15'),
(85, 3, 0, '', 'unknown', 'Mozilla', NULL, NULL, '65.109.26.102', 1, '2023-02-03 10:07:59'),
(86, 3, 0, '', 'Apple', 'Safari', NULL, NULL, '17.241.75.134', 1, '2023-02-03 11:26:06'),
(87, 3, 0, '', 'Windows', 'Chrome', NULL, NULL, '104.156.149.37', 1, '2023-02-03 19:42:03'),
(88, 3, 0, '', 'unknown', 'GoogleBot', NULL, NULL, '66.249.79.38', 2, '2023-02-04 00:19:47'),
(89, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '42.147.120.106', 1, '2023-02-04 21:39:20'),
(90, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '126.156.233.33', 1, '2023-02-05 05:02:11'),
(91, 3, 0, '', 'Apple', 'Safari', NULL, NULL, '17.241.219.220', 1, '2023-02-05 13:30:44'),
(92, 3, 0, 'http://localhost:8081/18.html', 'iPhone', 'iPhone', NULL, NULL, '106.173.151.21', 1, '2023-02-05 14:01:23'),
(93, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '1.73.128.83', 1, '2023-02-05 18:38:14'),
(94, 3, 0, 'http://localhost:8081/', 'iPad', 'iPad', NULL, NULL, '1.75.223.103', 1, '2023-02-06 00:36:22'),
(95, 3, 0, '', 'unknown', 'unknown', NULL, NULL, '18.179.11.238', 1, '2023-02-06 01:56:53'),
(96, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '153.173.22.145', 1, '2023-02-06 02:41:11'),
(97, 3, 0, 'http://localhost:8081/', 'Android', 'Chrome', NULL, NULL, '60.67.89.142', 1, '2023-02-06 04:29:27'),
(98, 3, 0, 'http://localhost:8081/newslist.html', 'Windows', 'Chrome', NULL, NULL, '210.130.205.26', 1, '2023-02-06 06:47:46'),
(99, 3, 0, 'http://localhost:8081/', 'iPhone', 'iPhone', NULL, NULL, '113.159.211.206', 1, '2023-02-06 08:29:33'),
(100, 3, 0, 'http://localhost:8081/18.html', 'Android', 'Chrome', NULL, NULL, '219.160.50.35', 1, '2023-02-06 10:35:16'),
(101, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '61.214.15.247', 1, '2023-02-06 11:52:51'),
(102, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '49.106.215.197', 1, '2023-02-06 12:22:14'),
(103, 3, 0, 'https://www.google.com/', 'iPhone', 'Chrome', NULL, NULL, '60.109.147.232', 1, '2023-02-06 12:27:07'),
(104, 3, 0, 'http://localhost:8081/8.html', 'Android', 'Chrome', NULL, NULL, '126.253.148.87', 1, '2023-02-07 00:22:41'),
(105, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '114.166.59.17', 1, '2023-02-07 00:53:03'),
(106, 3, 0, 'http://mori-kiyonori.com/', 'Windows', 'Chrome', NULL, NULL, '20.232.178.244', 1, '2023-02-07 01:48:15'),
(107, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '1.33.5.164', 1, '2023-02-07 01:54:35'),
(108, 3, 0, 'http://localhost:8081/', 'Windows', 'Chrome', NULL, NULL, '27.83.74.26', 1, '2023-02-07 02:46:28');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_form_meta`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_form_meta` (
  `id` int(10) unsigned NOT NULL,
  `form_id` int(10) unsigned DEFAULT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_form_meta`
--

INSERT INTO `wp_fluentform_form_meta` (`id`, `form_id`, `meta_key`, `value`) VALUES
(10, 3, 'template_name', 'basic_contact_form'),
(11, 3, 'formSettings', '{"confirmation":{"redirectTo":"samePage","messageToShow":"<h3 class=\\"text-center\\">\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3092\\u5b8c\\u4e86\\u3057\\u307e\\u3057\\u305f\\u3002<\\/h3>\\n<div class=\\"mt-5\\">\\n<p>\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3044\\u305f\\u3060\\u304d\\u3042\\u308a\\u304c\\u3068\\u3046\\u3054\\u3056\\u3044\\u307e\\u3057\\u305f\\u3002<br>\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3092\\u53d7\\u3051\\u4ed8\\u3051\\u307e\\u3057\\u305f\\u3002<\\/p>\\n<p>\\u6298\\u308a\\u8fd4\\u3057\\u3001\\u62c5\\u5f53\\u8005\\u3088\\u308a\\u3054\\u9023\\u7d61\\u3044\\u305f\\u3057\\u307e\\u3059\\u306e\\u3067\\u3001\\u6050\\u308c\\u5165\\u308a\\u307e\\u3059\\u304c\\u3001\\u3057\\u3070\\u3089\\u304f\\u304a\\u5f85\\u3061\\u304f\\u3060\\u3055\\u3044\\u3002<\\/p>\\n<p>\\u306a\\u304a\\u3001\\u3054\\u5165\\u529b\\u3044\\u305f\\u3060\\u3044\\u305f\\u30e1\\u30fc\\u30eb\\u30a2\\u30c9\\u30ec\\u30b9\\u5b9b\\u306b\\u53d7\\u4ed8\\u5b8c\\u4e86\\u30e1\\u30fc\\u30eb\\u3092\\u914d\\u4fe1\\u3057\\u3066\\u304a\\u308a\\u307e\\u3059\\u3002\\u5b8c\\u4e86\\u30e1\\u30fc\\u30eb\\u304c\\u5c4a\\u304b\\u306a\\u3044\\u5834\\u5408\\u3001\\u51e6\\u7406\\u304c\\u6b63\\u5e38\\u306b\\u884c\\u308f\\u308c\\u3066\\u3044\\u306a\\u3044\\u53ef\\u80fd\\u6027\\u304c\\u3042\\u308a\\u307e\\u3059\\u3002\\u5927\\u5909\\u304a\\u624b\\u6570\\u3067\\u3059\\u304c\\u3001\\u518d\\u5ea6\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u306e\\u624b\\u7d9a\\u304d\\u3092\\u304a\\u9858\\u3044\\u81f4\\u3057\\u307e\\u3059\\u3002<\\/p>\\n<\\/div>","customPage":null,"samePageFormBehavior":"hide_form","customUrl":null},"restrictions":{"limitNumberOfEntries":{"enabled":false,"numberOfEntries":null,"period":"total","limitReachedMsg":"Maximum number of entries exceeded."},"scheduleForm":{"enabled":false,"start":null,"end":null,"selectedDays":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],"pendingMsg":"Form submission is not started yet.","expiredMsg":"Form submission is now closed."},"requireLogin":{"enabled":false,"requireLoginMsg":"You must be logged in to submit the form."},"denyEmptySubmission":{"enabled":false,"message":"Sorry, you cannot submit an empty form. Let''s hear what you wanna say."}},"layout":{"labelPlacement":"top","helpMessagePlacement":"with_label","errorMessagePlacement":"inline","cssClassName":"","asteriskPlacement":"asterisk-right"},"delete_entry_on_submission":"no","appendSurveyResult":{"enabled":false,"showLabel":false,"showCount":false}}'),
(12, 3, 'advancedValidationSettings', '{"status":false,"type":"all","conditions":[{"field":"","operator":"=","value":""}],"error_message":"","validation_type":"fail_on_condition_met"}'),
(13, 3, 'double_optin_settings', '{"status":"no","confirmation_message":"Please check your email inbox to confirm this submission","email_body_type":"global","email_subject":"Please confirm your form submission","email_body":"<h2>Please Confirm Your Submission</h2><p>&nbsp;</p><p style="text-align: center;"><a style="color: #ffffff; background-color: #454545; font-size: 16px; border-radius: 5px; text-decoration: none; font-weight: normal; font-style: normal; padding: 0.8rem 1rem; border-color: #0072ff;" href="#confirmation_url#">Confirm Submission</a></p><p>&nbsp;</p><p>If you received this email by mistake, simply delete it. Your form submission won''t proceed if you don''t click the confirmation link above.</p>","email_field":"","skip_if_logged_in":"yes","skip_if_fc_subscribed":"no"}'),
(14, 3, '_primary_email_field', 'email'),
(15, 3, 'notifications', '{"name":"\\u304a\\u5ba2\\u69d8\\u7528\\u81ea\\u52d5\\u8fd4\\u4fe1","sendTo":{"type":"field","email":null,"field":"email","routing":[{"input_value":"","field":null,"operator":"=","value":null}]},"fromName":"\\u68ee\\u304d\\u3088\\u306e\\u308a\\u4e8b\\u52d9\\u6240","fromEmail":"info@mori-kiyonori.com","replyTo":"","bcc":"","subject":"\\u3010\\u68ee\\u304d\\u3088\\u306e\\u308a\\u4e8b\\u52d9\\u6240\\u3011\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3042\\u308a\\u304c\\u3068\\u3046\\u3054\\u3056\\u3044\\u307e\\u3059\\u3002","message":"<p>{inputs.names.first_name}\\u00a0\\u69d8<\\/p>\\n<p>\\u4ee5\\u4e0b\\u306e\\u5185\\u5bb9\\u3067\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3092\\u53d7\\u3051\\u4ed8\\u3051\\u307e\\u3057\\u305f\\u3002\\u5185\\u5bb9\\u3092\\u78ba\\u8a8d\\u3055\\u305b\\u3066\\u3044\\u305f\\u3060\\u304d\\u6b21\\u7b2c\\u3001\\u3054\\u8fd4\\u4fe1\\u3055\\u305b\\u3066\\u3044\\u305f\\u3060\\u304d\\u307e\\u3059\\u3002<\\/p>\\n<p>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501<\\/p>\\n<p>{all_data}<\\/p>\\n<p>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501<\\/p>\\n<p><br \\/>\\u3054\\u8cea\\u554f\\u5185\\u5bb9\\u306b\\u3088\\u3063\\u3066\\u306f\\u3001\\u304a\\u8fd4\\u4e8b\\u306b\\u304a\\u6642\\u9593\\u304c\\u304b\\u304b\\u308b\\u5834\\u5408\\u3084\\u3001\\u304a\\u8fd4\\u4e8b\\u3067\\u304d\\u306a\\u3044\\u5834\\u5408\\u3082\\u3054\\u3056\\u3044\\u307e\\u3059\\u306e\\u3067\\u3001\\u4f55\\u5352\\u3054\\u4e86\\u627f\\u304f\\u3060\\u3055\\u3044\\u3002<br \\/>------------------------------------------------------------<\\/p>\\n<h3>\\u7acb\\u61b2\\u6c11\\u4e3b\\u515a\\u539a\\u5225\\u533a\\u652f\\u90e8\\u526f\\u4ee3\\u8868\\u5e02\\u653f\\u62c5\\u5f53<br \\/><strong>\\u68ee\\u304d\\u3088\\u306e\\u308a<\\/strong><\\/h3>\\n<p>TEL\\uff1a 011-893-2200<br \\/>info@mori-kiyonori.com<br \\/>https:\\/\\/mori-kiyonori.com<br \\/>------------------------------------------------------------<\\/p>","conditionals":{"status":false,"type":"all","conditions":[{"field":null,"operator":"=","value":null}]},"enabled":true,"pdf_attachments":[],"attachments":[],"media_attachments":[],"feed_trigger_event":"payment_success"}'),
(16, 3, 'notifications', '{"name":"\\u7ba1\\u7406\\u8005\\u7528\\u901a\\u77e5","sendTo":{"type":"email","email":"info@mori-kiyonori.com","field":"email","routing":[{"input_value":"","field":null,"operator":"=","value":null}]},"fromName":"\\u68ee\\u304d\\u3088\\u306e\\u308a\\u4e8b\\u52d9\\u6240","fromEmail":"info@mori-kiyonori.com","replyTo":"","bcc":"","subject":"\\u3010\\u68ee\\u304d\\u3088\\u306e\\u308a\\u4e8b\\u52d9\\u6240\\u3011\\u65b0\\u3057\\u3044\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u3042\\u308a\\u307e\\u3059\\u3002","message":"<p>\\u4ee5\\u4e0b\\u306e\\u5185\\u5bb9\\u3067\\u304a\\u554f\\u3044\\u5408\\u308f\\u305b\\u304c\\u3042\\u308a\\u307e\\u3057\\u305f\\u3002<\\/p>\\n<p>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501<\\/p>\\n<p>{all_data}<\\/p>\\n<p>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501<\\/p>\\n<p><br \\/>\\u203b\\u672c\\u30e1\\u30fc\\u30eb\\u306f\\u304a\\u554f\\u5408\\u305b\\u304c\\u3042\\u3063\\u305f\\u969b\\u306e\\u81ea\\u52d5\\u914d\\u4fe1\\u30e1\\u30fc\\u30eb\\u3067\\u3059\\u3002<br \\/>\\u3054\\u5bfe\\u5fdc\\u3088\\u308d\\u3057\\u304f\\u304a\\u9858\\u3044\\u3044\\u305f\\u3057\\u307e\\u3059\\u3002<\\/p>","conditionals":{"status":false,"type":"all","conditions":[{"field":null,"operator":"=","value":null}]},"enabled":true,"pdf_attachments":[],"attachments":[],"media_attachments":[],"feed_trigger_event":"payment_success"}'),
(17, 3, '_total_views', '108');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_logs`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_logs` (
  `id` int(10) unsigned NOT NULL,
  `parent_source_id` int(10) unsigned DEFAULT NULL,
  `source_type` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `source_id` int(10) unsigned DEFAULT NULL,
  `component` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` char(30) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_logs`
--

INSERT INTO `wp_fluentform_logs` (`id`, `parent_source_id`, `source_type`, `source_id`, `component`, `status`, `title`, `description`, `created_at`) VALUES
(1, 3, 'submission_item', 1, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to konayukitabetai@docomo.ne.jp.<br />Subject: 【森きよのり事務所】お問い合わせありがとうございます。', '2023-01-30 23:35:44'),
(2, 3, 'submission_item', 1, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to info@mori-kiyonori.com.<br />Subject: 【森きよのり事務所】新しいお問い合わせあります。', '2023-01-30 23:35:44'),
(3, 3, 'submission_item', 2, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to itoukenta.cdp@gmail.com.<br />Subject: 【森きよのり事務所】お問い合わせありがとうございます。', '2023-01-31 02:04:42'),
(4, 3, 'submission_item', 2, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to info@mori-kiyonori.com.<br />Subject: 【森きよのり事務所】新しいお問い合わせあります。', '2023-01-31 02:04:42'),
(5, 3, 'submission_item', 3, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to zashikibuta2021@gmail.com.<br />Subject: 【森きよのり事務所】お問い合わせありがとうございます。', '2023-02-01 09:57:36'),
(6, 3, 'submission_item', 3, 'EmailNotification', 'info', 'Email sending initiated', 'Email Notification broadcasted to info@mori-kiyonori.com.<br />Subject: 【森きよのり事務所】新しいお問い合わせあります。', '2023-02-01 09:57:36');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_submissions`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_submissions` (
  `id` bigint(20) unsigned NOT NULL,
  `form_id` int(10) unsigned DEFAULT NULL,
  `serial_number` int(10) unsigned DEFAULT NULL,
  `response` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `source_url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT 'unread' COMMENT 'possible values: read, unread, trashed',
  `is_favourite` tinyint(1) NOT NULL DEFAULT 0,
  `browser` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `device` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `city` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_status` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_method` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_type` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `currency` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `payment_total` float DEFAULT NULL,
  `total_paid` float DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_submissions`
--

INSERT INTO `wp_fluentform_submissions` (`id`, `form_id`, `serial_number`, `response`, `source_url`, `user_id`, `status`, `is_favourite`, `browser`, `device`, `ip`, `city`, `country`, `payment_status`, `payment_method`, `payment_type`, `currency`, `payment_total`, `total_paid`, `created_at`, `updated_at`) VALUES
(1, 3, 1, '{"ak_hp_textarea":"","ak_js":"1675121013890","__fluent_form_embded_post_id":"2","_fluentform_3_fluentformnonce":"5cea972198","_wp_http_referer":"\\/contact.html","names":{"first_name":"青木洋二"},"names_1":{"first_name":"アオキヨウジ"},"email":"konayukitabetai@docomo.ne.jp","tel":"08096180042","address":"帯広市自由が丘4-3-1","message":"こんにちは。\\r\\n問合せではないのですが、どうしてもお伝えしたく、あえてこちらに送らせてもらいます。\\r\\n長年リスナーとして聞いてきた森君が新たな挑戦を始めると言う事、様々な声があるでしょうが僕は大応援です。\\r\\nこれからは人との距離感の種類が変わり、戸惑う事も多いと思いますが、まずはしっかり地元の為に働いて政治を学んで下さい。\\r\\nしかる後、できれば北海道全体を代弁出来る議員に成長して欲しいと思います。\\r\\n森君は、道民全部の人ですから。\\r\\n今から志を高く掲げ、まずは足元から地道に歩き続けて下さい。\\r\\n僕は厚別在住ではありませんが、何かお手伝い出来る事があるかもしれないと考えています。\\r\\n昨年独立開業し、ツイッターからは離れていましたが、powdereaterと言うアカウントですので応援の為に再開させてみます。\\r\\n僕の地元には石川さんがいます。逢坂さんや徳永さんも応援していますが、これから一押しは森君になります。\\r\\nどうか、倦まず弛まず、サンダーロードを闊歩して行って下さい。\\r\\n健康と家族を大切に、頑張れ！","terms-n-condition":"on","ak_bib":"1675121018330","ak_bfs":"1675121743703","ak_bkpc":"1090","ak_bkp":"14,233;13,188;13,270;15,1090;13,169;13,122;14,153;11,103;12,257;13,1127;13,168;12,909;17,204;13,149;12,239;13,258;14,188;14,150;15,154;13,174;9,129;11,163;16,1979;14,392;16,380;13,604;14,154;11,1481;12,168;11,156;11,1157;14,204;17,1041;12,1221;13,206;11,273;14,304;12,791;12,722;12,208;12,172;13,169;8,133;13,1016;14,253;12,541;13,173;10,132;13,147;12,286;15,420;12,290;13,153;13,762;12,149;14,140;14,468;13,423;14,202;14,136;15,304;15,317;11,1059;14,239;14,136;14,136;12,154;11,427;12,1155;13,271;11,358;12,189;11,2110;12,710;13,170;13,170;11,2814;14,286;14,223;12,135;15,156;14,356;13,151;19,568;12,4483;14,2392;12,337;13,356;12,291;15,237;15,803;11,156;13,234;13,1024;12,255;16,891;8,116;12,246;8,136;9,125;","ak_bmc":"56;24,7224;18,7350;17,7603;14,5818;10,16790;3,2892;8,1689;1,467041;1,210737;","ak_bmcc":"10","ak_bmk":"","ak_bck":"207;208;269;290;292;381;437;437;444;444;497;497;539;539;539;554;558;567;567;573;585;661;706;706;706;789;789;789;789;789;789;789;789;789;801;801;801;801;801;801;808;981;981;981;993;1051;1058","ak_bmmc":"0","ak_btmc":"13","ak_bsc":"9","ak_bte":"81;90,7186;80,7294;80,7544;93,5737;46,16762;157,2746;328,892;80,393;126,1010;158,1141;374,436913;93,27211;142,53309;479,8685;410,491;410,6545;342,1647;442,2984;361,511;308,5073;243,123785;109,4487;","ak_btec":"23","ak_bmm":""}', 'http://localhost:8081/wp/contact.html', 0, 'read', 0, 'iPhone', 'iPhone', '49.97.26.230', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-30 23:35:44', '2023-01-30 23:35:44'),
(2, 3, 2, '{"ak_hp_textarea":"","ak_js":"1675130453203","__fluent_form_embded_post_id":"2","_fluentform_3_fluentformnonce":"78c12b5241","_wp_http_referer":"\\/contact.html","names":{"first_name":"伊藤　健太"},"names_1":{"first_name":"イトウ　ケンタ"},"email":"itoukenta.cdp@gmail.com","tel":"09028788828","address":"登別市千歳町４－５－２０５","message":"選挙アカデミーでご一緒させていただきました、登別市議会議員の伊藤健太です。\\r\\n\\r\\n次期統一地方選挙へ向けて\\r\\nともに頑張りましょう！\\r\\n\\r\\n今後ともよろしくお願いいたします！","terms-n-condition":"on","ak_bib":"1675130456981","ak_bfs":"1675130682561","ak_bkpc":"372","ak_bkp":"14,122;20,270;13,131;16,120;16,201;13;12,153;14,206;11,117;14,140;12,136;10,120;19,1676;14,234;11,135;12,139;13,122;14,271;13,119;13,121;13,204;16;11,137;13,1757;12,121;13,154;16,775;12,1333;13,171;13,756;11,153;12,1325;13,271;12,103;12,206;13,137;12,689;22,222;14,2615;11,569;11,140;13,122;8,225;14,422;12,904;11,672;12,824;12,120;13,139;12,572;12,388;14,138;12,104;12,204;12,139;12,122;12,587;12;11,137;12,157;11,204;13,157;13,154;12,154;12,139;10,119;12,159;13,188;18;16,147;12,168;14,154;12,103;15,1407;8,80;15,1313;14,136;13,1370;11,100;20,1045;14,128;8,198;13,331;13,121;17,121;14,516;16,238;14,117;11,82;14,2044;19,422;15,113;15,119;18,501;12;9,120;9,124;8,125;9,142;12,732;","ak_bmc":"39;18,6675;11,6499;15,22858;18,68760;5,17658;3,94375;6,10086;2,640;","ak_bmcc":"9","ak_bmk":"","ak_bck":"28;28;28;28;28;28;28;28;28;37;87;104;269;269;269;269;269;269;269;269;269;269;269;269;269;269;269;269","ak_bmmc":"0","ak_btmc":"0","ak_bsc":"8","ak_bte":"79;62,6647;75,6446;76,22790;64,68705;67,17620;66,94311;95,9960;41,644;","ak_btec":"9","ak_bmm":""}', 'http://localhost:8081/wp/contact.html', 0, 'read', 0, 'iPhone', 'iPhone', '153.170.12.120', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-31 02:04:42', '2023-01-31 02:04:42'),
(3, 3, 3, '{"ak_hp_textarea":"","ak_js":"1675245097408","__fluent_form_embded_post_id":"2","_fluentform_3_fluentformnonce":"139391fc04","_wp_http_referer":"\\/contact.html","names":{"first_name":"平沼祐里"},"names_1":{"first_name":"ヒラヌマユリ"},"email":"zashikibuta2021@gmail.com","tel":"09034624079","address":"北海道函館市花園町31-7-504","message":"お問い合わせではないのですが\\r\\nTwitterアカウントの背景\\r\\nASAMORIのロゴははずしたほうがよいとおもいますがいつまでもairgの看板は背負わないでほしいです\\r\\n\\r\\n\\r\\n私はノースウェブ　カツノリさんのリスナーだけど朝moriの選曲は好きでした\\r\\n\\r\\n私は厚別区民でした\\r\\n厚別区から頑張ってください","terms-n-condition":"on","ak_bib":"1675245114400","ak_bfs":"1675245456425","ak_bkpc":"527","ak_bkp":"10,1009;17,582;14,1088;10,219;13,223;10,153;9,158;9,807;12,175;9,170;8,159;9,141;10,241;8,208;9,159;9,174;9,608;9,175;9,140;9,241;9,158;12,141;15,1336;9,321;11,258;11,189;9,173;11,424;10,189;10,156;11,174;9,155;10,209;10,189;13,890;9,255;10,173;12,158;13,654;10,170;8,491;10,158;10,404;10,174;9,319;10,174;9,190;10,191;9,107;9,442;9,141;10,224;10,156;10,141;9,757;13,189;10,238;9,191;10,157;10,157;12,324;10,187;7,193;9,158;11,140;11,204;14,889;9,1170;10,188;9,908;10,192;10,1270;12,420;11,259;10,190;10,156;9,191;9,524;10,191;9,173;10,174;10,157;11,221;16;9;10,157;9,209;10,156;10,156;10,191;9,207;10,174;10,173;9,141;11,189;11,208;13,171;9,172;10,174;9,140;","ak_bmc":"43;22,3600;17,3776;16,4735;12,4929;8,5492;0,92793;1,1776;0,28946;1,36754;0,1708;0,14141;1,2203;0,711;0,12709;0,925;0,666;4,124667;2,1110;1,1140;","ak_bmcc":"20","ak_bmk":"","ak_bck":"80;80;122;127;127;127;127;127;127;128;134;134;169;169;187;187;187;187;199;223;264;266;266;289;289;289;289;293;293;293;323;340;340;343;343;343;356;365;396;396;405;405;408;413;428;457;457","ak_bmmc":"0","ak_btmc":"8","ak_bsc":"10","ak_bte":"131;573,10639;194,872;95,623;48,1705;282,3048;44,264;47,3756;43,4704;8,4939;45,5461;43,92731;25,1757;42,28900;15,36751;39,1669;42,14079;59,2159;43,674;309,11760;40,575;23,927;41,610;61,3624;399,119504;83,1024;40,1070;43,1108;","ak_btec":"28","ak_bmm":""}', 'http://localhost:8081/wp/contact.html', 0, 'read', 0, 'iPhone', 'iPhone', '60.113.82.13', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-01 09:57:36', '2023-02-01 09:57:36');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_fluentform_submission_meta`
--

CREATE TABLE IF NOT EXISTS `wp_fluentform_submission_meta` (
  `id` bigint(20) unsigned NOT NULL,
  `response_id` bigint(20) unsigned DEFAULT NULL,
  `form_id` int(10) unsigned DEFAULT NULL,
  `meta_key` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_fluentform_submission_meta`
--

INSERT INTO `wp_fluentform_submission_meta` (`id`, `response_id`, `form_id`, `meta_key`, `value`, `status`, `user_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '_entry_uid_hash', '116c1a6b38258f43495d339c9bd8397c', NULL, NULL, NULL, '2023-01-30 23:35:44', '2023-01-30 23:35:44'),
(2, 1, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2023-01-30 23:35:44', '2023-01-30 23:35:44'),
(3, 2, 3, '_entry_uid_hash', '81ed487287e77e21915ac3370470db9f', NULL, NULL, NULL, '2023-01-31 02:04:42', '2023-01-31 02:04:42'),
(4, 2, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2023-01-31 02:04:42', '2023-01-31 02:04:42'),
(5, 3, 3, '_entry_uid_hash', '6354aa1e640e13b0cefb21fd75da4cc4', NULL, NULL, NULL, '2023-02-01 09:57:36', '2023-02-01 09:57:36'),
(6, 3, 3, 'is_form_action_fired', 'yes', NULL, NULL, NULL, '2023-02-01 09:57:36', '2023-02-01 09:57:36');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB AUTO_INCREMENT=12865 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8081/wp', 'yes'),
(2, 'home', 'http://localhost:8081', 'yes'),
(3, 'blogname', '森きよのり', 'yes'),
(4, 'blogdescription', '札幌市議会議員候補予定（厚別区） 立憲民主党公認', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'wp@clear-design.jp', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'Y年n月j日', 'yes'),
(24, 'time_format', 'g:i A', 'yes'),
(25, 'links_updated_date_format', 'Y年n月j日 g:i A', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%post_id%.html', 'yes'),
(29, 'rewrite_rules', 'a:118:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:39:"index.php?yoast-sitemap-xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:40:"c/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"c/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:16:"c/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:28:"c/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:10:"c/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:42:"t/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:37:"t/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:18:"t/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:30:"t/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:12:"t/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:40:"3d-flip-book/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"3d-flip-book/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"3d-flip-book/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"3d-flip-book/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"3d-flip-book/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:46:"3d-flip-book/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:29:"3d-flip-book/([^/]+)/embed/?$";s:45:"index.php?3d-flip-book=$matches[1]&embed=true";s:33:"3d-flip-book/([^/]+)/trackback/?$";s:39:"index.php?3d-flip-book=$matches[1]&tb=1";s:41:"3d-flip-book/([^/]+)/page/?([0-9]{1,})/?$";s:52:"index.php?3d-flip-book=$matches[1]&paged=$matches[2]";s:48:"3d-flip-book/([^/]+)/comment-page-([0-9]{1,})/?$";s:52:"index.php?3d-flip-book=$matches[1]&cpage=$matches[2]";s:37:"3d-flip-book/([^/]+)(?:/([0-9]+))?/?$";s:51:"index.php?3d-flip-book=$matches[1]&page=$matches[2]";s:29:"3d-flip-book/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"3d-flip-book/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"3d-flip-book/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"3d-flip-book/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"3d-flip-book/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"3d-flip-book/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:62:"3d-flip-book-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?3d-flip-book-category=$matches[1]&feed=$matches[2]";s:57:"3d-flip-book-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?3d-flip-book-category=$matches[1]&feed=$matches[2]";s:38:"3d-flip-book-category/([^/]+)/embed/?$";s:54:"index.php?3d-flip-book-category=$matches[1]&embed=true";s:50:"3d-flip-book-category/([^/]+)/page/?([0-9]{1,})/?$";s:61:"index.php?3d-flip-book-category=$matches[1]&paged=$matches[2]";s:32:"3d-flip-book-category/([^/]+)/?$";s:43:"index.php?3d-flip-book-category=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"date/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"date/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"date/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"date/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"date/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"date/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"date/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"date/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"date/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:18:"date/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:33:"[0-9]+.html/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"[0-9]+.html/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"[0-9]+.html/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"[0-9]+.html/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"[0-9]+.html/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"[0-9]+.html/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"([0-9]+).html/embed/?$";s:34:"index.php?p=$matches[1]&embed=true";s:26:"([0-9]+).html/trackback/?$";s:28:"index.php?p=$matches[1]&tb=1";s:46:"([0-9]+).html/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?p=$matches[1]&feed=$matches[2]";s:41:"([0-9]+).html/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?p=$matches[1]&feed=$matches[2]";s:34:"([0-9]+).html/page/?([0-9]{1,})/?$";s:41:"index.php?p=$matches[1]&paged=$matches[2]";s:41:"([0-9]+).html/comment-page-([0-9]{1,})/?$";s:41:"index.php?p=$matches[1]&cpage=$matches[2]";s:30:"([0-9]+).html(?:/([0-9]+))?/?$";s:40:"index.php?p=$matches[1]&page=$matches[2]";s:22:"[0-9]+.html/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"[0-9]+.html/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"[0-9]+.html/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"[0-9]+.html/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"[0-9]+.html/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"[0-9]+.html/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:32:".?.+?.html/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:".?.+?.html/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:".?.+?.html/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:".?.+?.html/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:".?.+?.html/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:".?.+?.html/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"(.?.+?).html/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:25:"(.?.+?).html/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:45:"(.?.+?).html/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:40:"(.?.+?).html/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:33:"(.?.+?).html/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:40:"(.?.+?).html/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:29:"(.?.+?).html(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:16:{i:0;s:31:"query-monitor/query-monitor.php";i:1;s:15:"admin/admin.php";i:2;s:30:"advanced-custom-fields/acf.php";i:3;s:19:"akismet/akismet.php";i:4;s:45:"bottom-admin-toolbar/bottom-admin-toolbar.php";i:5;s:37:"breadcrumb-navxt/breadcrumb-navxt.php";i:6;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:7;s:33:"duplicate-post/duplicate-post.php";i:8;s:25:"fluentform/fluentform.php";i:9;s:65:"html-editor-syntax-highlighter/html-editor-syntax-highlighter.php";i:10;s:33:"instagram-feed/instagram-feed.php";i:11;s:56:"interactive-3d-flipbook-powered-physics-engine/index.php";i:12;s:33:"ssh-sftp-updater-support/sftp.php";i:13;s:24:"wordpress-seo/wp-seo.php";i:14;s:29:"wp-mail-smtp/wp_mail_smtp.php";i:15;s:41:"wp-multibyte-patch/wp-multibyte-patch.php";}', 'yes'),
(34, 'category_base', '/c', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:3:{i:0;s:90:"/home/cdsv02/mori-kiyonori.com/public_html/wp/wp-content/themes/mori/block/index/index.php";i:2;s:78:"/home/cdsv02/mori-kiyonori.com/public_html/wp/wp-content/themes/mori/style.css";i:3;s:0:"";}', 'no'),
(40, 'template', 'mori', 'yes'),
(41, 'stylesheet', 'mori', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '/t', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '400', 'yes'),
(57, 'thumbnail_size_h', '0', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '600', 'yes'),
(60, 'medium_size_h', '400', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', '', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:3:{s:24:"wordpress-seo/wp-seo.php";s:14:"__return_false";s:25:"mw-wp-form/mw-wp-form.php";a:2:{i:0;s:10:"MW_WP_Form";i:1;s:10:"_uninstall";}s:33:"instagram-feed/instagram-feed.php";s:22:"sb_instagram_uninstall";}', 'no'),
(80, 'timezone_string', 'Asia/Tokyo', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '32', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1680669732', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:73:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:20:"wpseo_manage_options";b:1;s:10:"copy_posts";b:1;s:18:"bcn_manage_options";b:1;s:27:"fluentform_dashboard_access";b:1;s:24:"fluentform_forms_manager";b:1;s:25:"fluentform_entries_viewer";b:1;s:25:"fluentform_manage_entries";b:1;s:24:"fluentform_view_payments";b:1;s:26:"fluentform_manage_payments";b:1;s:27:"fluentform_settings_manager";b:1;s:22:"fluentform_full_access";b:1;s:29:"manage_instagram_feed_options";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:13:"wpseo_manager";a:2:{s:4:"name";s:11:"SEO Manager";s:12:"capabilities";a:39:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:20:"wpseo_manage_options";b:1;s:23:"view_site_health_checks";b:1;s:10:"copy_posts";b:1;}}s:12:"wpseo_editor";a:2:{s:4:"name";s:10:"SEO Editor";s:12:"capabilities";a:37:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;s:28:"wpseo_edit_advanced_metadata";b:1;s:10:"copy_posts";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ja', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:157:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>最近の投稿</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:233:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>最近のコメント</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:153:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>アーカイブ</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:155:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>カテゴリー</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:14:{i:1675739105;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1675739325;a:1:{s:29:"fluentform_do_scheduled_tasks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:21:"ff_every_five_minutes";s:4:"args";a:0:{}s:8:"interval";i:300;}}}i:1675741335;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1675744935;a:5:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675744938;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675744940;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675746666;a:2:{s:21:"sb_instagram_cron_job";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:23:"sb_instagram_twicedaily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675746727;a:1:{s:15:"sbi_feed_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1675747358;a:2:{s:13:"wpseo-reindex";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"wpseo_permalink_structure_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1675753425;a:1:{s:42:"fluentform_do_email_report_scheduled_tasks";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1676090535;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1676267199;a:1:{s:23:"sbi_usage_tracking_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1676300400;a:2:{s:29:"sb_instagram_feed_issue_email";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:9:"sbiweekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:23:"sbi_notification_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:9:"sbiweekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'recovery_keys', 'a:0:{}', 'yes'),
(121, 'https_detection_errors', 'a:0:{}', 'yes'),
(151, 'can_compress_scripts', '1', 'no'),
(152, 'new_admin_email', 'wp@clear-design.jp', 'yes'),
(161, 'finished_updating_comment_type', '1', 'yes'),
(162, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1665119588;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(167, 'current_theme', 'mori', 'yes'),
(168, 'theme_mods_default', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1666333829;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(169, 'theme_switched', '', 'yes'),
(172, 'auto_update_themes', 'a:1:{i:0;s:7:"default";}', 'no'),
(173, 'recently_activated', 'a:0:{}', 'yes'),
(177, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(178, 'schema-ActionScheduler_StoreSchema', '6.0.1665120156', 'yes'),
(179, 'schema-ActionScheduler_LoggerSchema', '3.0.1665120156', 'yes'),
(180, 'wp_mail_smtp_initial_version', '3.5.2', 'no'),
(181, 'wp_mail_smtp_version', '3.7.0', 'no'),
(182, 'wp_mail_smtp', 'a:11:{s:4:"mail";a:6:{s:10:"from_email";s:22:"info@mori-kiyonori.com";s:9:"from_name";s:24:"森きよのり事務所";s:6:"mailer";s:4:"smtp";s:11:"return_path";b:0;s:16:"from_email_force";b:1;s:15:"from_name_force";b:1;}s:4:"smtp";a:7:{s:7:"autotls";b:1;s:4:"auth";b:1;s:4:"host";s:18:"sv13249.xserver.jp";s:10:"encryption";s:3:"tls";s:4:"port";i:587;s:4:"user";s:22:"info@mori-kiyonori.com";s:4:"pass";s:68:"lRuZRAhce28A9H1fMm4KZ5y5KcEK/SS5Pjbj/Mi+wwttUsIavIH3NUso5JJ7YTpjjvc=";}s:7:"general";a:1:{s:29:"summary_report_email_disabled";b:0;}s:9:"sendlayer";a:1:{s:7:"api_key";s:0:"";}s:7:"smtpcom";a:2:{s:7:"api_key";s:0:"";s:7:"channel";s:0:"";}s:10:"sendinblue";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:5:"gmail";a:2:{s:9:"client_id";s:0:"";s:13:"client_secret";s:0:"";}s:7:"mailgun";a:3:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";s:6:"region";s:2:"US";}s:8:"postmark";a:2:{s:16:"server_api_token";s:0:"";s:14:"message_stream";s:0:"";}s:8:"sendgrid";a:2:{s:7:"api_key";s:0:"";s:6:"domain";s:0:"";}s:9:"sparkpost";a:2:{s:7:"api_key";s:0:"";s:6:"region";s:2:"US";}}', 'no'),
(183, 'wp_mail_smtp_activated_time', '1665120156', 'no'),
(184, 'wp_mail_smtp_activated', 'a:1:{s:4:"lite";i:1665120156;}', 'yes'),
(187, 'yoast_migrations_free', 'a:1:{s:7:"version";s:4:"20.0";}', 'yes'),
(188, 'wpseo', 'a:100:{s:8:"tracking";b:0;s:22:"license_server_version";s:1:"2";s:15:"ms_defaults_set";b:0;s:40:"ignore_search_engines_discouraged_notice";b:0;s:19:"indexing_first_time";b:1;s:16:"indexing_started";b:0;s:15:"indexing_reason";s:0:"";s:29:"indexables_indexing_completed";b:0;s:13:"index_now_key";s:0:"";s:7:"version";s:4:"20.0";s:16:"previous_version";s:0:"";s:20:"disableadvanced_meta";b:1;s:30:"enable_headless_rest_endpoints";b:1;s:17:"ryte_indexability";b:0;s:11:"baiduverify";s:0:"";s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:12:"yandexverify";s:0:"";s:9:"site_type";s:0:"";s:20:"has_multiple_authors";s:0:"";s:16:"environment_type";s:0:"";s:23:"content_analysis_active";b:1;s:23:"keyword_analysis_active";b:1;s:34:"inclusive_language_analysis_active";b:0;s:21:"enable_admin_bar_menu";b:1;s:26:"enable_cornerstone_content";b:1;s:18:"enable_xml_sitemap";b:1;s:24:"enable_text_link_counter";b:1;s:16:"enable_index_now";b:1;s:22:"show_onboarding_notice";b:0;s:18:"first_activated_on";s:10:"1673857927";s:13:"myyoast-oauth";b:0;s:26:"semrush_integration_active";b:1;s:14:"semrush_tokens";a:0:{}s:20:"semrush_country_code";s:2:"us";s:19:"permalink_structure";s:15:"/%post_id%.html";s:8:"home_url";s:25:"http://localhost:8081";s:18:"dynamic_permalinks";b:0;s:17:"category_base_url";s:1:"c";s:12:"tag_base_url";s:1:"t";s:21:"custom_taxonomy_slugs";a:1:{s:21:"3d-flip-book-category";s:21:"3d-flip-book-category";}s:29:"enable_enhanced_slack_sharing";b:1;s:25:"zapier_integration_active";b:0;s:19:"zapier_subscription";a:0:{}s:14:"zapier_api_key";s:0:"";s:23:"enable_metabox_insights";b:1;s:23:"enable_link_suggestions";b:1;s:26:"algolia_integration_active";b:0;s:14:"import_cursors";a:0:{}s:13:"workouts_data";a:1:{s:13:"configuration";a:1:{s:13:"finishedSteps";a:0:{}}}s:28:"configuration_finished_steps";a:0:{}s:36:"dismiss_configuration_workout_notice";b:1;s:34:"dismiss_premium_deactivated_notice";b:0;s:26:"dismiss_old_premium_notice";b:0;s:19:"importing_completed";a:0:{}s:26:"wincher_integration_active";b:1;s:14:"wincher_tokens";a:0:{}s:36:"wincher_automatically_add_keyphrases";b:0;s:18:"wincher_website_id";s:0:"";s:28:"wordproof_integration_active";b:0;s:29:"wordproof_integration_changed";b:0;s:18:"first_time_install";b:0;s:34:"should_redirect_after_install_free";b:0;s:34:"activation_redirect_timestamp_free";s:10:"1652258756";s:18:"remove_feed_global";b:0;s:27:"remove_feed_global_comments";b:0;s:25:"remove_feed_post_comments";b:0;s:19:"remove_feed_authors";b:0;s:22:"remove_feed_categories";b:0;s:16:"remove_feed_tags";b:0;s:29:"remove_feed_custom_taxonomies";b:0;s:22:"remove_feed_post_types";b:0;s:18:"remove_feed_search";b:0;s:21:"remove_atom_rdf_feeds";b:0;s:17:"remove_shortlinks";b:0;s:21:"remove_rest_api_links";b:0;s:20:"remove_rsd_wlw_links";b:0;s:19:"remove_oembed_links";b:0;s:16:"remove_generator";b:0;s:20:"remove_emoji_scripts";b:0;s:24:"remove_powered_by_header";b:0;s:22:"remove_pingback_header";b:0;s:28:"clean_campaign_tracking_urls";b:0;s:16:"clean_permalinks";b:0;s:32:"clean_permalinks_extra_variables";s:0:"";s:14:"search_cleanup";b:0;s:20:"search_cleanup_emoji";b:0;s:23:"search_cleanup_patterns";b:0;s:22:"search_character_limit";i:50;s:20:"deny_search_crawling";b:0;s:21:"deny_wp_json_crawling";b:0;s:27:"redirect_search_pretty_urls";b:0;s:29:"least_readability_ignore_list";a:0:{}s:27:"least_seo_score_ignore_list";a:0:{}s:23:"most_linked_ignore_list";a:0:{}s:24:"least_linked_ignore_list";a:0:{}s:28:"indexables_page_reading_list";a:5:{i:0;b:0;i:1;b:0;i:2;b:0;i:3;b:0;i:4;b:0;}s:25:"indexables_overview_state";s:21:"dashboard-not-visited";s:28:"last_known_public_post_types";a:4:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";i:3;s:12:"3d-flip-book";}s:28:"last_known_public_taxonomies";a:4:{i:0;s:8:"category";i:1;s:8:"post_tag";i:2;s:11:"post_format";i:3;s:21:"3d-flip-book-category";}}', 'yes'),
(189, 'wpseo_titles', 'a:128:{s:17:"forcerewritetitle";b:1;s:9:"separator";s:7:"sc-dash";s:16:"title-home-wpseo";s:33:"%%sitename%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:45:"%%name%% (%%sitename%% の投稿者) %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:60:"検索結果: %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:63:"ページが見つかりませんでした %%sep%% %%sitename%%";s:25:"social-title-author-wpseo";s:8:"%%name%%";s:26:"social-title-archive-wpseo";s:8:"%%date%%";s:31:"social-description-author-wpseo";s:0:"";s:32:"social-description-archive-wpseo";s:0:"";s:29:"social-image-url-author-wpseo";s:0:"";s:30:"social-image-url-archive-wpseo";s:0:"";s:28:"social-image-id-author-wpseo";i:0;s:29:"social-image-id-archive-wpseo";i:0;s:19:"metadesc-home-wpseo";s:576:"森きよのりは、リスナーが感じている声を札幌市政に直撞眉けたいというものでした。 ラジオを通して25年間、多くのリスナを重ね、実生活では大書な声を上げることができない人に寄り添い、声なき声に耳を傾けることの大切さを学びました。声なき声を言葉にすることを鍛えてき た経験を生かし、行政、議会、市民の双方向による街づくりを進めていきたい。 「森きよのり」と一緒に新しい札幌づく りに挑戦しませんか。";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:9:"rssbefore";s:0:"";s:8:"rssafter";s:73:"投稿 %%POSTLINK%% は %%BLOGLINK%% に最初に表示されました。";s:20:"noindex-author-wpseo";b:0;s:28:"noindex-author-noposts-wpseo";b:1;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:18:"disable-attachment";b:1;s:20:"breadcrumbs-404crumb";s:48:"エラー 404: ページが見つかりません";s:29:"breadcrumbs-display-blog-page";b:1;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:16:"アーカイブ:";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:9:"ホーム";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:13:"検索結果:";s:15:"breadcrumbs-sep";s:2:"»";s:12:"website_name";s:0:"";s:11:"person_name";s:0:"";s:11:"person_logo";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:22:"company_alternate_name";s:0:"";s:17:"company_or_person";s:7:"company";s:25:"company_or_person_user_id";b:0;s:17:"stripcategorybase";b:0;s:26:"open_graph_frontpage_title";s:33:"%%sitename%% %%sep%% %%sitedesc%%";s:25:"open_graph_frontpage_desc";s:576:"森きよのりは、リスナーが感じている声を札幌市政に直撞眉けたいというものでした。 ラジオを通して25年間、多くのリスナを重ね、実生活では大書な声を上げることができない人に寄り添い、声なき声に耳を傾けることの大切さを学びました。声なき声を言葉にすることを鍛えてき た経験を生かし、行政、議会、市民の双方向による街づくりを進めていきたい。 「森きよのり」と一緒に新しい札幌づく りに挑戦しませんか。";s:26:"open_graph_frontpage_image";s:63:"http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png";s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"noindex-post";b:0;s:23:"display-metabox-pt-post";b:1;s:23:"post_types-post-maintax";i:0;s:21:"schema-page-type-post";s:7:"WebPage";s:24:"schema-article-type-post";s:7:"Article";s:17:"social-title-post";s:9:"%%title%%";s:23:"social-description-post";s:0:"";s:21:"social-image-url-post";s:0:"";s:20:"social-image-id-post";i:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"noindex-page";b:0;s:23:"display-metabox-pt-page";b:1;s:23:"post_types-page-maintax";i:0;s:21:"schema-page-type-page";s:7:"WebPage";s:24:"schema-article-type-page";s:4:"None";s:17:"social-title-page";s:9:"%%title%%";s:23:"social-description-page";s:0:"";s:21:"social-image-url-page";s:0:"";s:20:"social-image-id-page";i:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:29:"display-metabox-pt-attachment";b:1;s:29:"post_types-attachment-maintax";i:0;s:27:"schema-page-type-attachment";s:7:"WebPage";s:30:"schema-article-type-attachment";s:4:"None";s:18:"title-tax-category";s:60:"%%term_title%% アーカイブ %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:28:"display-metabox-tax-category";b:1;s:20:"noindex-tax-category";b:0;s:25:"social-title-tax-category";s:30:"%%term_title%% アーカイブ";s:31:"social-description-tax-category";s:0:"";s:29:"social-image-url-tax-category";s:0:"";s:28:"social-image-id-tax-category";i:0;s:26:"taxonomy-category-ptparent";i:0;s:18:"title-tax-post_tag";s:60:"%%term_title%% アーカイブ %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:28:"display-metabox-tax-post_tag";b:1;s:20:"noindex-tax-post_tag";b:0;s:25:"social-title-tax-post_tag";s:30:"%%term_title%% アーカイブ";s:31:"social-description-tax-post_tag";s:0:"";s:29:"social-image-url-tax-post_tag";s:0:"";s:28:"social-image-id-tax-post_tag";i:0;s:26:"taxonomy-post_tag-ptparent";i:0;s:21:"title-tax-post_format";s:60:"%%term_title%% アーカイブ %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:31:"display-metabox-tax-post_format";b:1;s:23:"noindex-tax-post_format";b:1;s:28:"social-title-tax-post_format";s:30:"%%term_title%% アーカイブ";s:34:"social-description-tax-post_format";s:0:"";s:32:"social-image-url-tax-post_format";s:0:"";s:31:"social-image-id-tax-post_format";i:0;s:29:"taxonomy-post_format-ptparent";i:0;s:18:"title-3d-flip-book";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:21:"metadesc-3d-flip-book";s:0:"";s:20:"noindex-3d-flip-book";b:0;s:31:"display-metabox-pt-3d-flip-book";b:1;s:31:"post_types-3d-flip-book-maintax";i:0;s:29:"schema-page-type-3d-flip-book";s:7:"WebPage";s:32:"schema-article-type-3d-flip-book";s:4:"None";s:25:"social-title-3d-flip-book";s:9:"%%title%%";s:31:"social-description-3d-flip-book";s:0:"";s:29:"social-image-url-3d-flip-book";s:0:"";s:28:"social-image-id-3d-flip-book";i:0;s:31:"title-tax-3d-flip-book-category";s:60:"%%term_title%% アーカイブ %%page%% %%sep%% %%sitename%%";s:34:"metadesc-tax-3d-flip-book-category";s:0:"";s:41:"display-metabox-tax-3d-flip-book-category";b:1;s:33:"noindex-tax-3d-flip-book-category";b:0;s:38:"social-title-tax-3d-flip-book-category";s:30:"%%term_title%% アーカイブ";s:44:"social-description-tax-3d-flip-book-category";s:0:"";s:42:"social-image-url-tax-3d-flip-book-category";s:0:"";s:41:"social-image-id-tax-3d-flip-book-category";i:0;s:39:"taxonomy-3d-flip-book-category-ptparent";i:0;s:14:"person_logo_id";i:0;s:15:"company_logo_id";i:0;s:29:"open_graph_frontpage_image_id";i:34;}', 'yes'),
(190, 'wpseo_social', 'a:19:{s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:63:"http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png";s:19:"og_default_image_id";i:34;s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:21:"og_frontpage_image_id";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:19:"summary_large_image";s:11:"youtube_url";s:0:"";s:13:"wikipedia_url";s:0:"";s:17:"other_social_urls";a:0:{}}', 'yes'),
(191, 'action_scheduler_lock_async-request-runner', '1675737761', 'yes'),
(192, 'widget_akismet_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(193, 'widget_bcn_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(197, 'acf_version', '6.0.7', 'yes'),
(198, 'duplicate_post_show_notice', '0', 'no'),
(199, 'duplicate_post_copytitle', '1', 'yes'),
(200, 'duplicate_post_copydate', '0', 'yes'),
(201, 'duplicate_post_copystatus', '0', 'yes'),
(202, 'duplicate_post_copyslug', '0', 'yes'),
(203, 'duplicate_post_copyexcerpt', '1', 'yes'),
(204, 'duplicate_post_copycontent', '1', 'yes'),
(205, 'duplicate_post_copythumbnail', '1', 'yes'),
(206, 'duplicate_post_copytemplate', '1', 'yes'),
(207, 'duplicate_post_copyformat', '1', 'yes'),
(208, 'duplicate_post_copyauthor', '0', 'yes'),
(209, 'duplicate_post_copypassword', '0', 'yes'),
(210, 'duplicate_post_copyattachments', '0', 'yes'),
(211, 'duplicate_post_copychildren', '0', 'yes'),
(212, 'duplicate_post_copycomments', '0', 'yes'),
(213, 'duplicate_post_copymenuorder', '1', 'yes'),
(214, 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'),
(215, 'duplicate_post_blacklist', '', 'yes'),
(216, 'duplicate_post_types_enabled', 'a:2:{i:0;s:4:"post";i:1;s:4:"page";}', 'yes'),
(217, 'duplicate_post_show_original_column', '0', 'yes'),
(218, 'duplicate_post_show_original_in_post_states', '0', 'yes'),
(219, 'duplicate_post_show_original_meta_box', '0', 'yes'),
(220, 'duplicate_post_show_link', 'a:3:{s:9:"new_draft";s:1:"1";s:5:"clone";s:1:"1";s:17:"rewrite_republish";s:1:"1";}', 'yes'),
(221, 'duplicate_post_show_link_in', 'a:4:{s:3:"row";s:1:"1";s:8:"adminbar";s:1:"1";s:9:"submitbox";s:1:"1";s:11:"bulkactions";s:1:"1";}', 'yes'),
(222, 'duplicate_post_version', '4.5', 'yes'),
(223, 'wp_mail_smtp_migration_version', '5', 'yes'),
(224, 'wp_mail_smtp_debug_events_db_version', '1', 'yes'),
(241, 'wp_mail_smtp_review_notice', 'a:2:{s:4:"time";i:1665120160;s:9:"dismissed";b:0;}', 'yes'),
(250, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"ooda.work";s:8:"username";s:3:"dev";s:15:"connection_type";s:3:"ssh";}', 'yes'),
(260, 'akismet_strictness', '0', 'yes'),
(261, 'akismet_show_user_comments_approved', '0', 'yes'),
(262, 'akismet_comment_form_privacy_notice', 'hide', 'yes'),
(263, 'wordpress_api_key', '34f44e7aa9e2', 'yes'),
(264, 'akismet_spam_count', '0', 'yes'),
(265, 'wp_mail_smtp_notifications', 'a:4:{s:6:"update";i:1675697537;s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes'),
(320, 'theme_mods_politics', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1674784650;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'yes'),
(731, 'wpseo_taxonomy_meta', 'a:1:{s:8:"category";a:1:{i:1;a:3:{s:13:"wpseo_focuskw";s:9:"未分類";s:13:"wpseo_linkdex";s:2:"27";s:19:"wpseo_content_score";s:1:"0";}}}', 'yes'),
(732, 'category_children', 'a:0:{}', 'yes'),
(761, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(941, 'fluentform_entry_details_migrated', 'yes', 'no'),
(942, 'fluentform_db_fluentform_logs_added', '1', 'no'),
(943, 'fluentform_scheduled_actions_migrated', 'yes', 'no'),
(944, '__fluentform_global_form_settings', 'a:1:{s:6:"layout";a:5:{s:14:"labelPlacement";s:3:"top";s:17:"asteriskPlacement";s:14:"asterisk-right";s:20:"helpMessagePlacement";s:10:"with_label";s:21:"errorMessagePlacement";s:6:"inline";s:12:"cssClassName";s:0:"";}}', 'no'),
(945, '_fluentform_installed_version', '4.3.20', 'no'),
(946, 'fluentform_global_modules_status', 'a:9:{s:9:"mailchimp";s:2:"no";s:14:"activecampaign";s:2:"no";s:16:"campaign_monitor";s:2:"no";s:17:"constatantcontact";s:2:"no";s:11:"getresponse";s:2:"no";s:8:"icontact";s:2:"no";s:7:"webhook";s:2:"no";s:6:"zapier";s:2:"no";s:5:"slack";s:2:"no";}', 'no'),
(947, 'widget_fluentform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(958, 'wp_fb3d_pages_version', '1.1', 'yes'),
(962, '3d-flip-book-category_children', 'a:0:{}', 'yes'),
(1476, 'theme_mods_mori', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(1479, 'admin_sitename', '森きよのり', 'yes'),
(1480, 'admin_name', '立憲民主党厚別区支部副代表市政担当', 'yes'),
(1481, 'admin_pref', '〒004-0031', 'yes'),
(1482, 'admin_addr', '札幌市厚別区上野幌１条３丁目１−１６', 'yes'),
(1483, 'admin_addr2', '', 'yes'),
(1484, 'admin_tel', '011-893-2200', 'yes'),
(1485, 'admin_fax', '011-895-2627', 'yes'),
(1486, 'admin_mail', 'info@mori-kiyonori.com', 'yes'),
(1487, 'admin_twitter', 'https://twitter.com/KiyonoriMori', 'yes'),
(1488, 'admin_facebook', '', 'yes'),
(1489, 'admin_instagram', 'https://instagram.com/kiyo_morrison', 'yes'),
(1490, 'admin_line', '', 'yes'),
(1491, 'admin_note', '', 'yes'),
(1492, 'admin_youtube', '', 'yes'),
(1515, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1516, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1519, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:18:"wp@clear-design.jp";s:7:"version";s:5:"6.1.1";s:9:"timestamp";i:1674789445;}', 'no'),
(1522, '_transient_health-check-site-status-result', '{"good":17,"recommended":4,"critical":0}', 'yes'),
(1825, 'ssh_sftp_updater_support_dismiss_dash_notice_until', '1706517898', 'no'),
(2443, 'sbi_statuses', 'a:6:{s:8:"database";a:1:{s:14:"hashtag_column";b:1;}s:13:"first_install";i:1675055467;s:4:"gdpr";a:1:{s:19:"from_update_success";b:1;}s:12:"data_manager";a:2:{s:9:"last_used";i:1674969067;s:14:"num_db_updates";i:31;}s:24:"support_legacy_shortcode";b:0;s:12:"feed_locator";a:2:{s:10:"last_check";i:1675706809;s:11:"initialized";i:1675055537;}}', 'yes'),
(2444, 'sbi_usage_tracking', 'a:2:{s:7:"enabled";b:0;s:9:"last_send";i:0;}', 'yes'),
(2445, 'widget_instagram-feed-widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(2446, 'sbi_usage_tracking_config', 'a:6:{s:3:"day";i:1;s:4:"hour";i:5;s:6:"minute";i:46;s:6:"second";i:39;s:6:"offset";i:107199;s:8:"initsend";i:1675662399;}', 'yes'),
(2447, '_transient_timeout_instagram_feed_rating_notice_waiting', '1676265067', 'no'),
(2448, '_transient_instagram_feed_rating_notice_waiting', 'waiting', 'no'),
(2449, 'sbi_rating_notice', 'pending', 'no'),
(2450, 'sbi_db_version', '2.1', 'yes'),
(2451, 'sb_instagram_errors', 'a:9:{s:10:"connection";a:0:{}s:7:"hashtag";a:0:{}s:8:"resizing";a:0:{}s:15:"database_create";a:0:{}s:10:"upload_dir";a:0:{}s:8:"accounts";a:0:{}s:9:"error_log";a:0:{}s:10:"action_log";a:1:{i:0;s:41:"01-30 05:11:07 - Retesting GDPR features.";}s:7:"revoked";a:0:{}}', 'no'),
(2452, 'sb_instagram_settings', 'a:44:{s:15:"sb_instagram_at";s:0:"";s:20:"sb_instagram_user_id";s:0:"";s:30:"sb_instagram_preserve_settings";s:0:"";s:23:"sb_instagram_ajax_theme";b:0;s:27:"sb_instagram_disable_resize";b:0;s:23:"sb_instagram_cache_time";i:1;s:28:"sb_instagram_cache_time_unit";s:5:"hours";s:16:"sbi_caching_type";s:10:"background";s:23:"sbi_cache_cron_interval";s:7:"12hours";s:19:"sbi_cache_cron_time";s:1:"1";s:20:"sbi_cache_cron_am_pm";s:2:"am";s:18:"sb_instagram_width";s:3:"100";s:23:"sb_instagram_width_unit";s:1:"%";s:28:"sb_instagram_feed_width_resp";b:0;s:19:"sb_instagram_height";s:0:"";s:16:"sb_instagram_num";s:2:"20";s:24:"sb_instagram_height_unit";s:0:"";s:17:"sb_instagram_cols";s:1:"4";s:27:"sb_instagram_disable_mobile";b:0;s:26:"sb_instagram_image_padding";s:1:"5";s:31:"sb_instagram_image_padding_unit";s:2:"px";s:17:"sb_instagram_sort";s:4:"none";s:23:"sb_instagram_background";s:0:"";s:21:"sb_instagram_show_btn";b:1;s:27:"sb_instagram_btn_background";s:0:"";s:27:"sb_instagram_btn_text_color";s:0:"";s:21:"sb_instagram_btn_text";s:24:"さらに読み込む...";s:22:"sb_instagram_image_res";s:4:"auto";s:24:"sb_instagram_show_header";b:1;s:24:"sb_instagram_header_size";s:5:"small";s:25:"sb_instagram_header_color";s:0:"";s:28:"sb_instagram_show_follow_btn";b:1;s:33:"sb_instagram_folow_btn_background";s:0:"";s:34:"sb_instagram_follow_btn_text_color";s:0:"";s:28:"sb_instagram_follow_btn_text";s:25:"Instagram でフォロー";s:23:"sb_instagram_custom_css";s:0:"";s:22:"sb_instagram_custom_js";s:0:"";s:17:"sb_instagram_cron";s:2:"no";s:19:"sb_instagram_backup";b:1;s:15:"sb_ajax_initial";b:0;s:24:"enqueue_css_in_shortcode";b:0;s:30:"sb_instagram_disable_mob_swipe";b:0;s:28:"sb_instagram_disable_awesome";b:0;s:18:"connected_accounts";a:0:{}}', 'yes'),
(2453, 'sbi_single_cache', '/5WbdhN9Gx4ufNMnnrj0CnFQUy9KRm1YalZmMVFXS1ZmTjRxcTlBQlcvMjRrODByeW5FcEI3b3pHeEt0dGtZaTAyMTI0dGl0RXRKWlIwTU9ralZRa1NhSnRyc1NaSGVEczJ5d0JxQVc=', 'no'),
(2455, 'sbi_notifications', 'a:4:{s:6:"update";i:1675697496;s:4:"feed";a:0:{}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2456, 'sbi_newuser_notifications', 'a:4:{s:6:"update";i:1675055468;s:4:"feed";a:2:{s:6:"review";a:6:{s:5:"title";s:22:"Could you help us out?";s:7:"content";s:273:"It''s great to see that you''ve been using the <strong><span>{plugin}</span></strong> plugin for a while now. Hopefully you''re happy with it!&nbsp; If so, would you consider leaving a positive review? It really helps to support the plugin and helps others to discover it too!";s:2:"id";s:6:"review";s:5:"image";s:12:"sbi-icon.png";s:4:"btns";a:4:{s:7:"primary";a:4:{s:3:"url";s:12:"{review-url}";s:4:"attr";a:1:{i:0;s:11:"targetblank";}s:5:"class";s:31:"sbi_notice_dismiss sbi_main_cta";s:4:"text";s:18:"Sure, I''d love to!";}s:7:"dismiss";a:3:{s:3:"url";a:1:{s:28:"sbi_ignore_rating_notice_nag";s:1:"1";}s:5:"class";s:18:"sbi_notice_dismiss";s:4:"text";s:9:"No thanks";}s:8:"complete";a:3:{s:3:"url";a:1:{s:28:"sbi_ignore_rating_notice_nag";s:1:"1";}s:5:"class";s:18:"sbi_notice_dismiss";s:4:"text";s:27:"I''ve already given a review";}s:5:"later";a:3:{s:3:"url";a:1:{s:28:"sbi_ignore_rating_notice_nag";s:5:"later";}s:5:"class";s:18:"sbi_notice_dismiss";s:4:"text";s:12:"Ask Me Later";}}s:4:"wait";s:2:"14";}s:8:"discount";a:8:{s:5:"title";s:28:"Attention {platform} Lovers!";s:7:"content";s:221:"<strong><span>Exclusive offer!</span></strong> We don''t run promotions very often, but for a limited time we''re offering <strong><span>{amount} off</span></strong> our Pro version to all users of our free {plugin} plugin.";s:2:"id";s:8:"discount";s:6:"amount";s:3:"60%";s:5:"image";s:12:"sbi-icon.png";s:13:"image_overlay";s:7:"60% off";s:4:"btns";a:2:{s:7:"primary";a:4:{s:3:"url";s:127:"https://smashballoon.com/{slug}/?utm_campaign={campaign}&utm_source=notices&utm_medium=newuser&discount={lowerplatform}thankyou";s:5:"class";s:32:"sbi_notice_dismiss sbi_offer_btn";s:4:"text";s:14:"Get this offer";s:4:"attr";a:1:{i:0;s:11:"targetblank";}}s:7:"dismiss";a:3:{s:3:"url";a:1:{s:31:"sbi_ignore_new_user_sale_notice";s:6:"always";}s:5:"class";s:18:"sbi_notice_dismiss";s:4:"text";s:18:"I''m not interested";}}s:4:"wait";s:2:"30";}}s:6:"events";a:0:{}s:9:"dismissed";a:0:{}}', 'yes'),
(2458, 'sbi_cron_report', 'a:1:{s:5:"notes";a:2:{s:8:"time_ran";s:19:"2023-02-06 18:06:49";s:20:"num_found_transients";i:0;}}', 'no'),
(2641, '_site_transient_timeout_browser_6b3508613cbf72edec551de22b792dd5', '1675673979', 'no'),
(2642, '_site_transient_browser_6b3508613cbf72edec551de22b792dd5', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:9:"109.0.0.0";s:8:"platform";s:9:"Macintosh";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(2645, 'admin_header', '<!-- Google tag (gtag.js) -->\r\n<script async src="https://www.googletagmanager.com/gtag/js?id=G-421SWY3EY6"></script>\r\n<script>\r\n  window.dataLayer = window.dataLayer || [];\r\n  function gtag(){dataLayer.push(arguments);}\r\n  gtag(''js'', new Date());\r\n\r\n  gtag(''config'', ''G-421SWY3EY6'');\r\n</script>', 'yes'),
(2646, 'admin_body', '', 'yes'),
(2647, 'admin_footer', '', 'yes'),
(6540, '_site_transient_timeout_browser_b9cbd8dc13f19f9e7eb854f472bfa274', '1675856983', 'no'),
(6541, '_site_transient_browser_b9cbd8dc13f19f9e7eb854f472bfa274', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:9:"109.0.0.0";s:8:"platform";s:7:"Windows";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(6561, '_fluentform_reCaptcha_details', 'a:3:{s:7:"siteKey";s:40:"6LciUUMkAAAAAGMV8gtVzVV2sNwjbCsry-GHc8xd";s:9:"secretKey";s:40:"6LciUUMkAAAAACyJ_xCiLKhw_SN9tbKPGw91t8CJ";s:11:"api_version";s:12:"v3_invisible";}', 'no'),
(6562, '_fluentform_reCaptcha_keys_status', '1', 'no'),
(6620, 'action_scheduler_migration_status', 'complete', 'yes'),
(6626, 'wp_mail_smtp_debug', 'a:0:{}', 'no'),
(6627, 'wp_mail_smtp_mail_key', 'VeiYHp4DpNxLaFAuYbxqw6l8cEylDzzjjtZ/fQaTbgk=', 'yes'),
(6628, 'wp_mail_smtp_lite_sent_email_counter', '2', 'yes'),
(6629, 'wp_mail_smtp_lite_weekly_sent_email_counter', 'a:2:{s:2:"05";i:1;s:2:"06";i:1;}', 'yes'),
(9217, '_site_transient_timeout_php_check_990bfacb848fa087bcfc06850f5e4447', '1676021498', 'no'),
(9218, '_site_transient_php_check_990bfacb848fa087bcfc06850f5e4447', 'a:5:{s:19:"recommended_version";s:3:"7.4";s:15:"minimum_version";s:6:"5.6.20";s:12:"is_supported";b:1;s:9:"is_secure";b:1;s:13:"is_acceptable";b:1;}', 'no'),
(9625, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:62:"https://downloads.wordpress.org/release/ja/wordpress-6.1.1.zip";s:6:"locale";s:2:"ja";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:62:"https://downloads.wordpress.org/release/ja/wordpress-6.1.1.zip";s:10:"no_content";s:0:"";s:11:"new_bundled";s:0:"";s:7:"partial";s:0:"";s:8:"rollback";s:0:"";}s:7:"current";s:5:"6.1.1";s:7:"version";s:5:"6.1.1";s:11:"php_version";s:6:"5.6.20";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"6.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1675702430;s:15:"version_checked";s:5:"6.1.1";s:12:"translations";a:0:{}}', 'no'),
(9626, '_site_transient_update_themes', 'O:8:"stdClass":5:{s:12:"last_checked";i:1675697544;s:7:"checked";a:1:{s:4:"mori";s:5:"1.0.0";}s:8:"response";a:0:{}s:9:"no_update";a:0:{}s:12:"translations";a:0:{}}', 'no'),
(12109, '_transient_timeout_wpseo_total_unindexed_post_type_archives', '1675783896', 'no'),
(12110, '_transient_wpseo_total_unindexed_post_type_archives', '0', 'no'),
(12111, '_transient_timeout_wpseo_total_unindexed_general_items', '1675783896', 'no'),
(12112, '_transient_wpseo_total_unindexed_general_items', '0', 'no'),
(12113, '_transient_timeout_wpseo_unindexed_post_link_count', '1675783896', 'no'),
(12114, '_transient_wpseo_unindexed_post_link_count', '0', 'no'),
(12115, '_transient_timeout_wpseo_unindexed_term_link_count', '1675783896', 'no'),
(12116, '_transient_wpseo_unindexed_term_link_count', '0', 'no'),
(12117, '_site_transient_timeout_browser_894dc60a4e148f4652615ed246d3e298', '1676302296', 'no'),
(12118, '_site_transient_browser_894dc60a4e148f4652615ed246d3e298', 'a:10:{s:4:"name";s:6:"Chrome";s:7:"version";s:9:"109.0.0.0";s:8:"platform";s:9:"Macintosh";s:10:"update_url";s:29:"https://www.google.com/chrome";s:7:"img_src";s:43:"http://s.w.org/images/browsers/chrome.png?1";s:11:"img_src_ssl";s:44:"https://s.w.org/images/browsers/chrome.png?1";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;s:6:"mobile";b:0;}', 'no'),
(12198, '_site_transient_timeout_theme_roots', '1675704230', 'no'),
(12199, '_site_transient_theme_roots', 'a:1:{s:4:"mori";s:7:"/themes";}', 'no'),
(12200, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1675702431;s:8:"response";a:2:{s:56:"interactive-3d-flipbook-powered-physics-engine/index.php";O:8:"stdClass":12:{s:2:"id";s:60:"w.org/plugins/interactive-3d-flipbook-powered-physics-engine";s:4:"slug";s:46:"interactive-3d-flipbook-powered-physics-engine";s:6:"plugin";s:56:"interactive-3d-flipbook-powered-physics-engine/index.php";s:11:"new_version";s:6:"1.15.0";s:3:"url";s:77:"https://wordpress.org/plugins/interactive-3d-flipbook-powered-physics-engine/";s:7:"package";s:89:"https://downloads.wordpress.org/plugin/interactive-3d-flipbook-powered-physics-engine.zip";s:5:"icons";a:2:{s:2:"2x";s:99:"https://ps.w.org/interactive-3d-flipbook-powered-physics-engine/assets/icon-256x256.gif?rev=2361823";s:2:"1x";s:99:"https://ps.w.org/interactive-3d-flipbook-powered-physics-engine/assets/icon-128x128.gif?rev=2361823";}s:7:"banners";a:1:{s:2:"1x";s:101:"https://ps.w.org/interactive-3d-flipbook-powered-physics-engine/assets/banner-772x250.png?rev=2860556";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.3";s:6:"tested";s:5:"6.1.1";s:12:"requires_php";s:3:"5.3";}s:25:"fluentform/fluentform.php";O:8:"stdClass":12:{s:2:"id";s:24:"w.org/plugins/fluentform";s:4:"slug";s:10:"fluentform";s:6:"plugin";s:25:"fluentform/fluentform.php";s:11:"new_version";s:6:"4.3.24";s:3:"url";s:41:"https://wordpress.org/plugins/fluentform/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/fluentform.4.3.24.zip";s:5:"icons";a:2:{s:2:"2x";s:63:"https://ps.w.org/fluentform/assets/icon-256x256.png?rev=1794277";s:2:"1x";s:63:"https://ps.w.org/fluentform/assets/icon-128x128.png?rev=1794277";}s:7:"banners";a:2:{s:2:"2x";s:66:"https://ps.w.org/fluentform/assets/banner-1544x500.png?rev=2592144";s:2:"1x";s:65:"https://ps.w.org/fluentform/assets/banner-772x250.png?rev=2592144";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.5";s:6:"tested";s:5:"6.1.1";s:12:"requires_php";s:3:"5.6";}}s:12:"translations";a:0:{}s:9:"no_update";a:14:{s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":10:{s:2:"id";s:36:"w.org/plugins/advanced-custom-fields";s:4:"slug";s:22:"advanced-custom-fields";s:6:"plugin";s:30:"advanced-custom-fields/acf.php";s:11:"new_version";s:5:"6.0.7";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:71:"https://downloads.wordpress.org/plugin/advanced-custom-fields.6.0.7.zip";s:5:"icons";a:2:{s:2:"2x";s:75:"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746";s:2:"1x";s:75:"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746";}s:7:"banners";a:2:{s:2:"2x";s:78:"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099";s:2:"1x";s:77:"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.7";}s:19:"akismet/akismet.php";O:8:"stdClass":10:{s:2:"id";s:21:"w.org/plugins/akismet";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"5.0.2";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.5.0.2.zip";s:5:"icons";a:2:{s:2:"2x";s:60:"https://ps.w.org/akismet/assets/icon-256x256.png?rev=2818463";s:2:"1x";s:60:"https://ps.w.org/akismet/assets/icon-128x128.png?rev=2818463";}s:7:"banners";a:1:{s:2:"1x";s:61:"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.0";}s:45:"bottom-admin-toolbar/bottom-admin-toolbar.php";O:8:"stdClass":10:{s:2:"id";s:34:"w.org/plugins/bottom-admin-toolbar";s:4:"slug";s:20:"bottom-admin-toolbar";s:6:"plugin";s:45:"bottom-admin-toolbar/bottom-admin-toolbar.php";s:11:"new_version";s:5:"1.5.1";s:3:"url";s:51:"https://wordpress.org/plugins/bottom-admin-toolbar/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/bottom-admin-toolbar.1.5.1.zip";s:5:"icons";a:2:{s:2:"2x";s:73:"https://ps.w.org/bottom-admin-toolbar/assets/icon-256x256.png?rev=2614063";s:2:"1x";s:73:"https://ps.w.org/bottom-admin-toolbar/assets/icon-128x128.png?rev=2614063";}s:7:"banners";a:2:{s:2:"2x";s:76:"https://ps.w.org/bottom-admin-toolbar/assets/banner-1544x500.png?rev=2614062";s:2:"1x";s:75:"https://ps.w.org/bottom-admin-toolbar/assets/banner-772x250.png?rev=2618780";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.9";}s:37:"breadcrumb-navxt/breadcrumb-navxt.php";O:8:"stdClass":10:{s:2:"id";s:30:"w.org/plugins/breadcrumb-navxt";s:4:"slug";s:16:"breadcrumb-navxt";s:6:"plugin";s:37:"breadcrumb-navxt/breadcrumb-navxt.php";s:11:"new_version";s:5:"7.1.0";s:3:"url";s:47:"https://wordpress.org/plugins/breadcrumb-navxt/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/breadcrumb-navxt.7.1.0.zip";s:5:"icons";a:3:{s:2:"2x";s:69:"https://ps.w.org/breadcrumb-navxt/assets/icon-256x256.png?rev=2410525";s:2:"1x";s:61:"https://ps.w.org/breadcrumb-navxt/assets/icon.svg?rev=1927103";s:3:"svg";s:61:"https://ps.w.org/breadcrumb-navxt/assets/icon.svg?rev=1927103";}s:7:"banners";a:2:{s:2:"2x";s:72:"https://ps.w.org/breadcrumb-navxt/assets/banner-1544x500.png?rev=1927103";s:2:"1x";s:71:"https://ps.w.org/breadcrumb-navxt/assets/banner-772x250.png?rev=1927103";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.9";}s:43:"custom-post-type-ui/custom-post-type-ui.php";O:8:"stdClass":10:{s:2:"id";s:33:"w.org/plugins/custom-post-type-ui";s:4:"slug";s:19:"custom-post-type-ui";s:6:"plugin";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:11:"new_version";s:6:"1.13.4";s:3:"url";s:50:"https://wordpress.org/plugins/custom-post-type-ui/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.13.4.zip";s:5:"icons";a:2:{s:2:"2x";s:72:"https://ps.w.org/custom-post-type-ui/assets/icon-256x256.png?rev=2744389";s:2:"1x";s:72:"https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=2744389";}s:7:"banners";a:2:{s:2:"2x";s:75:"https://ps.w.org/custom-post-type-ui/assets/banner-1544x500.png?rev=2744389";s:2:"1x";s:74:"https://ps.w.org/custom-post-type-ui/assets/banner-772x250.png?rev=2744389";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.9";}s:65:"html-editor-syntax-highlighter/html-editor-syntax-highlighter.php";O:8:"stdClass":10:{s:2:"id";s:44:"w.org/plugins/html-editor-syntax-highlighter";s:4:"slug";s:30:"html-editor-syntax-highlighter";s:6:"plugin";s:65:"html-editor-syntax-highlighter/html-editor-syntax-highlighter.php";s:11:"new_version";s:5:"2.4.4";s:3:"url";s:61:"https://wordpress.org/plugins/html-editor-syntax-highlighter/";s:7:"package";s:79:"https://downloads.wordpress.org/plugin/html-editor-syntax-highlighter.2.4.4.zip";s:5:"icons";a:3:{s:2:"2x";s:83:"https://ps.w.org/html-editor-syntax-highlighter/assets/icon-256x256.png?rev=2013780";s:2:"1x";s:75:"https://ps.w.org/html-editor-syntax-highlighter/assets/icon.svg?rev=2013780";s:3:"svg";s:75:"https://ps.w.org/html-editor-syntax-highlighter/assets/icon.svg?rev=2013780";}s:7:"banners";a:2:{s:2:"2x";s:86:"https://ps.w.org/html-editor-syntax-highlighter/assets/banner-1544x500.png?rev=2013780";s:2:"1x";s:85:"https://ps.w.org/html-editor-syntax-highlighter/assets/banner-772x250.png?rev=2013780";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.0";}s:31:"query-monitor/query-monitor.php";O:8:"stdClass":10:{s:2:"id";s:27:"w.org/plugins/query-monitor";s:4:"slug";s:13:"query-monitor";s:6:"plugin";s:31:"query-monitor/query-monitor.php";s:11:"new_version";s:6:"3.11.1";s:3:"url";s:44:"https://wordpress.org/plugins/query-monitor/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/query-monitor.3.11.1.zip";s:5:"icons";a:3:{s:2:"2x";s:66:"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2301273";s:2:"1x";s:58:"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073";s:3:"svg";s:58:"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073";}s:7:"banners";a:2:{s:2:"2x";s:69:"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=2457098";s:2:"1x";s:68:"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=2457098";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.9";}s:33:"instagram-feed/instagram-feed.php";O:8:"stdClass":10:{s:2:"id";s:28:"w.org/plugins/instagram-feed";s:4:"slug";s:14:"instagram-feed";s:6:"plugin";s:33:"instagram-feed/instagram-feed.php";s:11:"new_version";s:5:"6.1.1";s:3:"url";s:45:"https://wordpress.org/plugins/instagram-feed/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/instagram-feed.6.1.1.zip";s:5:"icons";a:2:{s:2:"2x";s:67:"https://ps.w.org/instagram-feed/assets/icon-256x256.png?rev=2700807";s:2:"1x";s:67:"https://ps.w.org/instagram-feed/assets/icon-128x128.png?rev=2700807";}s:7:"banners";a:2:{s:2:"2x";s:70:"https://ps.w.org/instagram-feed/assets/banner-1544x500.png?rev=2679382";s:2:"1x";s:69:"https://ps.w.org/instagram-feed/assets/banner-772x250.png?rev=2679382";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"4.1";}s:33:"ssh-sftp-updater-support/sftp.php";O:8:"stdClass":10:{s:2:"id";s:38:"w.org/plugins/ssh-sftp-updater-support";s:4:"slug";s:24:"ssh-sftp-updater-support";s:6:"plugin";s:33:"ssh-sftp-updater-support/sftp.php";s:11:"new_version";s:5:"0.8.5";s:3:"url";s:55:"https://wordpress.org/plugins/ssh-sftp-updater-support/";s:7:"package";s:73:"https://downloads.wordpress.org/plugin/ssh-sftp-updater-support.0.8.5.zip";s:5:"icons";a:1:{s:7:"default";s:68:"https://s.w.org/plugins/geopattern-icon/ssh-sftp-updater-support.svg";}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"3.1";}s:41:"wordpress-importer/wordpress-importer.php";O:8:"stdClass":10:{s:2:"id";s:32:"w.org/plugins/wordpress-importer";s:4:"slug";s:18:"wordpress-importer";s:6:"plugin";s:41:"wordpress-importer/wordpress-importer.php";s:11:"new_version";s:3:"0.8";s:3:"url";s:49:"https://wordpress.org/plugins/wordpress-importer/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/wordpress-importer.0.8.zip";s:5:"icons";a:3:{s:2:"2x";s:71:"https://ps.w.org/wordpress-importer/assets/icon-256x256.png?rev=2791650";s:2:"1x";s:63:"https://ps.w.org/wordpress-importer/assets/icon.svg?rev=2791650";s:3:"svg";s:63:"https://ps.w.org/wordpress-importer/assets/icon.svg?rev=2791650";}s:7:"banners";a:1:{s:2:"1x";s:72:"https://ps.w.org/wordpress-importer/assets/banner-772x250.png?rev=547654";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.2";}s:29:"wp-mail-smtp/wp_mail_smtp.php";O:8:"stdClass":10:{s:2:"id";s:26:"w.org/plugins/wp-mail-smtp";s:4:"slug";s:12:"wp-mail-smtp";s:6:"plugin";s:29:"wp-mail-smtp/wp_mail_smtp.php";s:11:"new_version";s:5:"3.7.0";s:3:"url";s:43:"https://wordpress.org/plugins/wp-mail-smtp/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/wp-mail-smtp.3.7.0.zip";s:5:"icons";a:2:{s:2:"2x";s:65:"https://ps.w.org/wp-mail-smtp/assets/icon-256x256.png?rev=1755440";s:2:"1x";s:65:"https://ps.w.org/wp-mail-smtp/assets/icon-128x128.png?rev=1755440";}s:7:"banners";a:2:{s:2:"2x";s:68:"https://ps.w.org/wp-mail-smtp/assets/banner-1544x500.jpg?rev=2811094";s:2:"1x";s:67:"https://ps.w.org/wp-mail-smtp/assets/banner-772x250.jpg?rev=2811094";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.2";}s:41:"wp-multibyte-patch/wp-multibyte-patch.php";O:8:"stdClass":10:{s:2:"id";s:32:"w.org/plugins/wp-multibyte-patch";s:4:"slug";s:18:"wp-multibyte-patch";s:6:"plugin";s:41:"wp-multibyte-patch/wp-multibyte-patch.php";s:11:"new_version";s:3:"2.9";s:3:"url";s:49:"https://wordpress.org/plugins/wp-multibyte-patch/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/wp-multibyte-patch.2.9.zip";s:5:"icons";a:1:{s:7:"default";s:62:"https://s.w.org/plugins/geopattern-icon/wp-multibyte-patch.svg";}s:7:"banners";a:0:{}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.2";}s:33:"duplicate-post/duplicate-post.php";O:8:"stdClass":10:{s:2:"id";s:28:"w.org/plugins/duplicate-post";s:4:"slug";s:14:"duplicate-post";s:6:"plugin";s:33:"duplicate-post/duplicate-post.php";s:11:"new_version";s:3:"4.5";s:3:"url";s:45:"https://wordpress.org/plugins/duplicate-post/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/duplicate-post.4.5.zip";s:5:"icons";a:2:{s:2:"2x";s:67:"https://ps.w.org/duplicate-post/assets/icon-256x256.png?rev=2336666";s:2:"1x";s:67:"https://ps.w.org/duplicate-post/assets/icon-128x128.png?rev=2336666";}s:7:"banners";a:2:{s:2:"2x";s:70:"https://ps.w.org/duplicate-post/assets/banner-1544x500.png?rev=2336666";s:2:"1x";s:69:"https://ps.w.org/duplicate-post/assets/banner-772x250.png?rev=2336666";}s:11:"banners_rtl";a:0:{}s:8:"requires";s:3:"5.9";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":10:{s:2:"id";s:27:"w.org/plugins/wordpress-seo";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:4:"20.0";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/wordpress-seo.20.0.zip";s:5:"icons";a:3:{s:2:"2x";s:66:"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=2643727";s:2:"1x";s:58:"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699";s:3:"svg";s:58:"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=2363699";}s:7:"banners";a:2:{s:2:"2x";s:69:"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=2643727";s:2:"1x";s:68:"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=2643727";}s:11:"banners_rtl";a:2:{s:2:"2x";s:73:"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=2643727";s:2:"1x";s:72:"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=2643727";}s:8:"requires";s:3:"6.0";}}s:7:"checked";a:17:{s:56:"interactive-3d-flipbook-powered-physics-engine/index.php";s:6:"1.14.0";s:30:"advanced-custom-fields/acf.php";s:5:"6.0.7";s:19:"akismet/akismet.php";s:5:"5.0.2";s:45:"bottom-admin-toolbar/bottom-admin-toolbar.php";s:5:"1.5.1";s:37:"breadcrumb-navxt/breadcrumb-navxt.php";s:5:"7.1.0";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:6:"1.13.4";s:25:"fluentform/fluentform.php";s:6:"4.3.22";s:65:"html-editor-syntax-highlighter/html-editor-syntax-highlighter.php";s:5:"2.4.4";s:15:"admin/admin.php";s:5:"1.0.0";s:31:"query-monitor/query-monitor.php";s:6:"3.11.1";s:33:"instagram-feed/instagram-feed.php";s:5:"6.1.1";s:33:"ssh-sftp-updater-support/sftp.php";s:5:"0.8.5";s:41:"wordpress-importer/wordpress-importer.php";s:3:"0.8";s:29:"wp-mail-smtp/wp_mail_smtp.php";s:5:"3.7.0";s:41:"wp-multibyte-patch/wp-multibyte-patch.php";s:3:"2.9";s:33:"duplicate-post/duplicate-post.php";s:3:"4.5";s:24:"wordpress-seo/wp-seo.php";s:4:"20.0";}}', 'no'),
(12678, '_site_transient_timeout_available_translations', '1675744891', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(12679, '_site_transient_available_translations', 'a:130:{s:2:"af";a:8:{s:8:"language";s:2:"af";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-05-13 15:59:22";s:12:"english_name";s:9:"Afrikaans";s:11:"native_name";s:9:"Afrikaans";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8-beta/af.zip";s:3:"iso";a:2:{i:1;s:2:"af";i:2;s:3:"afr";}s:7:"strings";a:1:{s:8:"continue";s:10:"Gaan voort";}}s:2:"am";a:8:{s:8:"language";s:2:"am";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-09-29 20:43:49";s:12:"english_name";s:7:"Amharic";s:11:"native_name";s:12:"አማርኛ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.0.3/am.zip";s:3:"iso";a:2:{i:1;s:2:"am";i:2;s:3:"amh";}s:7:"strings";a:1:{s:8:"continue";s:9:"ቀጥል";}}s:3:"arg";a:8:{s:8:"language";s:3:"arg";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-09-22 16:46:56";s:12:"english_name";s:9:"Aragonese";s:11:"native_name";s:9:"Aragonés";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/6.1.1/arg.zip";s:3:"iso";a:3:{i:1;s:2:"an";i:2;s:3:"arg";i:3;s:3:"arg";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continar";}}s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-04 13:58:35";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:3:"ary";a:8:{s:8:"language";s:3:"ary";s:7:"version";s:6:"4.8.21";s:7:"updated";s:19:"2017-01-26 15:42:35";s:12:"english_name";s:15:"Moroccan Arabic";s:11:"native_name";s:31:"العربية المغربية";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.8.21/ary.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:3;s:3:"ary";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"as";a:8:{s:8:"language";s:2:"as";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-31 21:31:35";s:12:"english_name";s:8:"Assamese";s:11:"native_name";s:21:"অসমীয়া";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/as.zip";s:3:"iso";a:3:{i:1;s:2:"as";i:2;s:3:"asm";i:3;s:3:"asm";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-06 00:09:27";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:3:"azb";a:8:{s:8:"language";s:3:"azb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-12 20:34:31";s:12:"english_name";s:17:"South Azerbaijani";s:11:"native_name";s:29:"گؤنئی آذربایجان";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:3;s:3:"azb";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:3:"bel";a:8:{s:8:"language";s:3:"bel";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2019-10-29 07:54:22";s:12:"english_name";s:10:"Belarusian";s:11:"native_name";s:29:"Беларуская мова";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.9.22/bel.zip";s:3:"iso";a:2:{i:1;s:2:"be";i:2;s:3:"bel";}s:7:"strings";a:1:{s:8:"continue";s:20:"Працягнуць";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-16 13:00:35";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:12:"Напред";}}s:5:"bn_BD";a:8:{s:8:"language";s:5:"bn_BD";s:7:"version";s:6:"5.4.12";s:7:"updated";s:19:"2020-10-31 08:48:37";s:12:"english_name";s:20:"Bengali (Bangladesh)";s:11:"native_name";s:15:"বাংলা";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/5.4.12/bn_BD.zip";s:3:"iso";a:1:{i:1;s:2:"bn";}s:7:"strings";a:1:{s:8:"continue";s:23:"এগিয়ে চল.";}}s:2:"bo";a:8:{s:8:"language";s:2:"bo";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2020-10-30 03:24:38";s:12:"english_name";s:7:"Tibetan";s:11:"native_name";s:21:"བོད་ཡིག";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8-beta/bo.zip";s:3:"iso";a:2:{i:1;s:2:"bo";i:2;s:3:"tib";}s:7:"strings";a:1:{s:8:"continue";s:33:"མུ་མཐུད་དུ།";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-24 12:03:10";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-13 14:46:37";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:3:"ceb";a:8:{s:8:"language";s:3:"ceb";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-02 17:25:51";s:12:"english_name";s:7:"Cebuano";s:11:"native_name";s:7:"Cebuano";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip";s:3:"iso";a:2:{i:2;s:3:"ceb";i:3;s:3:"ceb";}s:7:"strings";a:1:{s:8:"continue";s:7:"Padayun";}}s:5:"cs_CZ";a:8:{s:8:"language";s:5:"cs_CZ";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-25 20:56:45";s:12:"english_name";s:5:"Czech";s:11:"native_name";s:9:"Čeština";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/cs_CZ.zip";s:3:"iso";a:2:{i:1;s:2:"cs";i:2;s:3:"ces";}s:7:"strings";a:1:{s:8:"continue";s:11:"Pokračovat";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-14 15:48:08";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-10 08:19:28";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsæt";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-16 12:27:22";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:14:"de_CH_informal";a:8:{s:8:"language";s:14:"de_CH_informal";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-16 12:27:34";s:12:"english_name";s:30:"German (Switzerland, Informal)";s:11:"native_name";s:21:"Deutsch (Schweiz, Du)";s:7:"package";s:73:"https://downloads.wordpress.org/translation/core/6.1.1/de_CH_informal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-17 17:06:48";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:5:"de_AT";a:8:{s:8:"language";s:5:"de_AT";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-03-17 12:58:14";s:12:"english_name";s:16:"German (Austria)";s:11:"native_name";s:21:"Deutsch (Österreich)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.0.3/de_AT.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:12:"de_DE_formal";a:8:{s:8:"language";s:12:"de_DE_formal";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-17 17:02:15";s:12:"english_name";s:15:"German (Formal)";s:11:"native_name";s:13:"Deutsch (Sie)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/6.1.1/de_DE_formal.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:6:"Weiter";}}s:3:"dsb";a:8:{s:8:"language";s:3:"dsb";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-07-16 12:13:09";s:12:"english_name";s:13:"Lower Sorbian";s:11:"native_name";s:16:"Dolnoserbšćina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/6.1.1/dsb.zip";s:3:"iso";a:2:{i:2;s:3:"dsb";i:3;s:3:"dsb";}s:7:"strings";a:1:{s:8:"continue";s:5:"Dalej";}}s:3:"dzo";a:8:{s:8:"language";s:3:"dzo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-06-29 08:59:03";s:12:"english_name";s:8:"Dzongkha";s:11:"native_name";s:18:"རྫོང་ཁ";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip";s:3:"iso";a:2:{i:1;s:2:"dz";i:2;s:3:"dzo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-31 21:42:00";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-10 21:58:00";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-16 06:36:35";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-31 12:11:44";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_ZA";a:8:{s:8:"language";s:5:"en_ZA";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2021-12-24 12:36:39";s:12:"english_name";s:22:"English (South Africa)";s:11:"native_name";s:22:"English (South Africa)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.0.3/en_ZA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_NZ";a:8:{s:8:"language";s:5:"en_NZ";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-04-01 22:35:34";s:12:"english_name";s:21:"English (New Zealand)";s:11:"native_name";s:21:"English (New Zealand)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.0.3/en_NZ.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-18 21:56:09";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_AR";a:8:{s:8:"language";s:5:"es_AR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-17 14:28:26";s:12:"english_name";s:19:"Spanish (Argentina)";s:11:"native_name";s:21:"Español de Argentina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_AR.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_VE";a:8:{s:8:"language";s:5:"es_VE";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-16 13:13:32";s:12:"english_name";s:19:"Spanish (Venezuela)";s:11:"native_name";s:21:"Español de Venezuela";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_VE.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CR";a:8:{s:8:"language";s:5:"es_CR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-01 03:10:20";s:12:"english_name";s:20:"Spanish (Costa Rica)";s:11:"native_name";s:22:"Español de Costa Rica";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_CR.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_DO";a:8:{s:8:"language";s:5:"es_DO";s:7:"version";s:5:"5.8.6";s:7:"updated";s:19:"2021-10-08 14:32:50";s:12:"english_name";s:28:"Spanish (Dominican Republic)";s:11:"native_name";s:33:"Español de República Dominicana";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8.6/es_DO.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"5.8.6";s:7:"updated";s:19:"2021-10-04 20:53:18";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8.6/es_PE.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-06-14 16:02:22";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:67:"https://downloads.wordpress.org/translation/core/5.8-beta/es_CL.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_UY";a:8:{s:8:"language";s:5:"es_UY";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-03-31 18:33:26";s:12:"english_name";s:17:"Spanish (Uruguay)";s:11:"native_name";s:19:"Español de Uruguay";s:7:"package";s:67:"https://downloads.wordpress.org/translation/core/5.8-beta/es_UY.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PR";a:8:{s:8:"language";s:5:"es_PR";s:7:"version";s:6:"5.4.12";s:7:"updated";s:19:"2020-04-29 15:36:59";s:12:"english_name";s:21:"Spanish (Puerto Rico)";s:11:"native_name";s:23:"Español de Puerto Rico";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/5.4.12/es_PR.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_GT";a:8:{s:8:"language";s:5:"es_GT";s:7:"version";s:6:"5.2.17";s:7:"updated";s:19:"2019-03-02 06:35:01";s:12:"english_name";s:19:"Spanish (Guatemala)";s:11:"native_name";s:21:"Español de Guatemala";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/5.2.17/es_GT.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-10 19:19:07";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_MX.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-10 18:26:21";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_ES.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_EC";a:8:{s:8:"language";s:5:"es_EC";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-11 23:25:26";s:12:"english_name";s:17:"Spanish (Ecuador)";s:11:"native_name";s:19:"Español de Ecuador";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_EC.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CO";a:8:{s:8:"language";s:5:"es_CO";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-07-22 14:08:10";s:12:"english_name";s:18:"Spanish (Colombia)";s:11:"native_name";s:20:"Español de Colombia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/es_CO.zip";s:3:"iso";a:3:{i:1;s:2:"es";i:2;s:3:"spa";i:3;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"et";a:8:{s:8:"language";s:2:"et";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2020-08-12 08:38:59";s:12:"english_name";s:8:"Estonian";s:11:"native_name";s:5:"Eesti";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8-beta/et.zip";s:3:"iso";a:2:{i:1;s:2:"et";i:2;s:3:"est";}s:7:"strings";a:1:{s:8:"continue";s:6:"Jätka";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-15 05:47:03";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_AF";a:8:{s:8:"language";s:5:"fa_AF";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-19 05:14:04";s:12:"english_name";s:21:"Persian (Afghanistan)";s:11:"native_name";s:31:"(فارسی (افغانستان";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/fa_AF.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-17 08:19:07";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-07 05:25:25";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-23 13:11:21";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_CA";a:8:{s:8:"language";s:5:"fr_CA";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-12 18:38:54";s:12:"english_name";s:15:"French (Canada)";s:11:"native_name";s:19:"Français du Canada";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/fr_CA.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:5:"fr_BE";a:8:{s:8:"language";s:5:"fr_BE";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-02-22 13:54:46";s:12:"english_name";s:16:"French (Belgium)";s:11:"native_name";s:21:"Français de Belgique";s:7:"package";s:67:"https://downloads.wordpress.org/translation/core/5.8-beta/fr_BE.zip";s:3:"iso";a:2:{i:1;s:2:"fr";i:2;s:3:"fra";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:3:"fur";a:8:{s:8:"language";s:3:"fur";s:7:"version";s:6:"4.8.21";s:7:"updated";s:19:"2018-01-29 17:32:35";s:12:"english_name";s:8:"Friulian";s:11:"native_name";s:8:"Friulian";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.8.21/fur.zip";s:3:"iso";a:2:{i:2;s:3:"fur";i:3;s:3:"fur";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"fy";a:8:{s:8:"language";s:2:"fy";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-25 12:53:23";s:12:"english_name";s:7:"Frisian";s:11:"native_name";s:5:"Frysk";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/fy.zip";s:3:"iso";a:2:{i:1;s:2:"fy";i:2;s:3:"fry";}s:7:"strings";a:1:{s:8:"continue";s:9:"Trochgean";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-08-23 17:41:37";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-03 10:28:43";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"gu";a:8:{s:8:"language";s:2:"gu";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2018-09-14 12:33:48";s:12:"english_name";s:8:"Gujarati";s:11:"native_name";s:21:"ગુજરાતી";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.9.22/gu.zip";s:3:"iso";a:2:{i:1;s:2:"gu";i:2;s:3:"guj";}s:7:"strings";a:1:{s:8:"continue";s:31:"ચાલુ રાખવું";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:6:"4.4.29";s:7:"updated";s:19:"2015-12-05 00:59:09";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.4.29/haz.zip";s:3:"iso";a:1:{i:3;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-06 19:08:00";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:8:"המשך";}}s:5:"hi_IN";a:8:{s:8:"language";s:5:"hi_IN";s:7:"version";s:6:"5.4.12";s:7:"updated";s:19:"2020-11-06 12:34:38";s:12:"english_name";s:5:"Hindi";s:11:"native_name";s:18:"हिन्दी";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/5.4.12/hi_IN.zip";s:3:"iso";a:2:{i:1;s:2:"hi";i:2;s:3:"hin";}s:7:"strings";a:1:{s:8:"continue";s:25:"जारी रखें";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-06 12:29:04";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:3:"hsb";a:8:{s:8:"language";s:3:"hsb";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-07-18 19:40:10";s:12:"english_name";s:13:"Upper Sorbian";s:11:"native_name";s:17:"Hornjoserbšćina";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/6.1.1/hsb.zip";s:3:"iso";a:2:{i:2;s:3:"hsb";i:3;s:3:"hsb";}s:7:"strings";a:1:{s:8:"continue";s:4:"Dale";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-23 17:09:07";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:10:"Folytatás";}}s:2:"hy";a:8:{s:8:"language";s:2:"hy";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-12-03 16:21:10";s:12:"english_name";s:8:"Armenian";s:11:"native_name";s:14:"Հայերեն";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip";s:3:"iso";a:2:{i:1;s:2:"hy";i:2;s:3:"hye";}s:7:"strings";a:1:{s:8:"continue";s:20:"Շարունակել";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-29 15:17:58";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2018-12-11 10:40:02";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.9.22/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-02 09:52:07";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-06 07:11:58";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:6:"次へ";}}s:5:"jv_ID";a:8:{s:8:"language";s:5:"jv_ID";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2019-02-16 23:58:56";s:12:"english_name";s:8:"Javanese";s:11:"native_name";s:9:"Basa Jawa";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.9.22/jv_ID.zip";s:3:"iso";a:2:{i:1;s:2:"jv";i:2;s:3:"jav";}s:7:"strings";a:1:{s:8:"continue";s:9:"Nerusaké";}}s:5:"ka_GE";a:8:{s:8:"language";s:5:"ka_GE";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-10-24 08:01:09";s:12:"english_name";s:8:"Georgian";s:11:"native_name";s:21:"ქართული";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.0.3/ka_GE.zip";s:3:"iso";a:2:{i:1;s:2:"ka";i:2;s:3:"kat";}s:7:"strings";a:1:{s:8:"continue";s:30:"გაგრძელება";}}s:3:"kab";a:8:{s:8:"language";s:3:"kab";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-21 21:13:06";s:12:"english_name";s:6:"Kabyle";s:11:"native_name";s:9:"Taqbaylit";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/6.1.1/kab.zip";s:3:"iso";a:2:{i:2;s:3:"kab";i:3;s:3:"kab";}s:7:"strings";a:1:{s:8:"continue";s:6:"Kemmel";}}s:2:"kk";a:8:{s:8:"language";s:2:"kk";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2018-07-10 11:35:44";s:12:"english_name";s:6:"Kazakh";s:11:"native_name";s:19:"Қазақ тілі";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.9.22/kk.zip";s:3:"iso";a:2:{i:1;s:2:"kk";i:2;s:3:"kaz";}s:7:"strings";a:1:{s:8:"continue";s:20:"Жалғастыру";}}s:2:"km";a:8:{s:8:"language";s:2:"km";s:7:"version";s:6:"5.2.17";s:7:"updated";s:19:"2019-06-10 16:18:28";s:12:"english_name";s:5:"Khmer";s:11:"native_name";s:27:"ភាសាខ្មែរ";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/5.2.17/km.zip";s:3:"iso";a:2:{i:1;s:2:"km";i:2;s:3:"khm";}s:7:"strings";a:1:{s:8:"continue";s:12:"បន្ត";}}s:2:"kn";a:8:{s:8:"language";s:2:"kn";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-10-20 17:15:28";s:12:"english_name";s:7:"Kannada";s:11:"native_name";s:15:"ಕನ್ನಡ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/kn.zip";s:3:"iso";a:2:{i:1;s:2:"kn";i:2;s:3:"kan";}s:7:"strings";a:1:{s:8:"continue";s:30:"ಮುಂದುವರಿಸು";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-21 23:01:12";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:3:"ckb";a:8:{s:8:"language";s:3:"ckb";s:7:"version";s:5:"5.8.6";s:7:"updated";s:19:"2021-12-07 16:32:30";s:12:"english_name";s:16:"Kurdish (Sorani)";s:11:"native_name";s:13:"كوردی‎";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/5.8.6/ckb.zip";s:3:"iso";a:2:{i:1;s:2:"ku";i:3;s:3:"ckb";}s:7:"strings";a:1:{s:8:"continue";s:30:"به‌رده‌وام به‌";}}s:2:"lo";a:8:{s:8:"language";s:2:"lo";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 09:59:23";s:12:"english_name";s:3:"Lao";s:11:"native_name";s:21:"ພາສາລາວ";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip";s:3:"iso";a:2:{i:1;s:2:"lo";i:2;s:3:"lao";}s:7:"strings";a:1:{s:8:"continue";s:18:"ຕໍ່​ໄປ";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-24 03:51:58";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:2:"lv";a:8:{s:8:"language";s:2:"lv";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-06 16:38:45";s:12:"english_name";s:7:"Latvian";s:11:"native_name";s:16:"Latviešu valoda";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/lv.zip";s:3:"iso";a:2:{i:1;s:2:"lv";i:2;s:3:"lav";}s:7:"strings";a:1:{s:8:"continue";s:9:"Turpināt";}}s:5:"mk_MK";a:8:{s:8:"language";s:5:"mk_MK";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-10-01 09:23:52";s:12:"english_name";s:10:"Macedonian";s:11:"native_name";s:31:"Македонски јазик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.0.3/mk_MK.zip";s:3:"iso";a:2:{i:1;s:2:"mk";i:2;s:3:"mkd";}s:7:"strings";a:1:{s:8:"continue";s:16:"Продолжи";}}s:5:"ml_IN";a:8:{s:8:"language";s:5:"ml_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:43:32";s:12:"english_name";s:9:"Malayalam";s:11:"native_name";s:18:"മലയാളം";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ml";i:2;s:3:"mal";}s:7:"strings";a:1:{s:8:"continue";s:18:"തുടരുക";}}s:2:"mn";a:8:{s:8:"language";s:2:"mn";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-02 15:24:05";s:12:"english_name";s:9:"Mongolian";s:11:"native_name";s:12:"Монгол";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/mn.zip";s:3:"iso";a:2:{i:1;s:2:"mn";i:2;s:3:"mon";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"mr";a:8:{s:8:"language";s:2:"mr";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2019-11-22 15:32:08";s:12:"english_name";s:7:"Marathi";s:11:"native_name";s:15:"मराठी";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.9.22/mr.zip";s:3:"iso";a:2:{i:1;s:2:"mr";i:2;s:3:"mar";}s:7:"strings";a:1:{s:8:"continue";s:25:"सुरु ठेवा";}}s:5:"ms_MY";a:8:{s:8:"language";s:5:"ms_MY";s:7:"version";s:6:"5.5.11";s:7:"updated";s:19:"2022-03-11 13:52:22";s:12:"english_name";s:5:"Malay";s:11:"native_name";s:13:"Bahasa Melayu";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/5.5.11/ms_MY.zip";s:3:"iso";a:2:{i:1;s:2:"ms";i:2;s:3:"msa";}s:7:"strings";a:1:{s:8:"continue";s:8:"Teruskan";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:6:"4.2.34";s:7:"updated";s:19:"2017-12-26 11:57:10";s:12:"english_name";s:17:"Myanmar (Burmese)";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.2.34/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ဆောင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-11 01:42:08";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"ne_NP";a:8:{s:8:"language";s:5:"ne_NP";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-24 12:00:31";s:12:"english_name";s:6:"Nepali";s:11:"native_name";s:18:"नेपाली";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/ne_NP.zip";s:3:"iso";a:2:{i:1;s:2:"ne";i:2;s:3:"nep";}s:7:"strings";a:1:{s:8:"continue";s:43:"जारी राख्नुहोस्";}}s:12:"nl_NL_formal";a:8:{s:8:"language";s:12:"nl_NL_formal";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-05 12:28:58";s:12:"english_name";s:14:"Dutch (Formal)";s:11:"native_name";s:20:"Nederlands (Formeel)";s:7:"package";s:71:"https://downloads.wordpress.org/translation/core/6.1.1/nl_NL_formal.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-26 10:11:03";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nl_BE";a:8:{s:8:"language";s:5:"nl_BE";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-31 09:04:37";s:12:"english_name";s:15:"Dutch (Belgium)";s:11:"native_name";s:20:"Nederlands (België)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/nl_BE.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"nn_NO";a:8:{s:8:"language";s:5:"nn_NO";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-03-18 10:59:16";s:12:"english_name";s:19:"Norwegian (Nynorsk)";s:11:"native_name";s:13:"Norsk nynorsk";s:7:"package";s:67:"https://downloads.wordpress.org/translation/core/5.8-beta/nn_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nn";i:2;s:3:"nno";}s:7:"strings";a:1:{s:8:"continue";s:9:"Hald fram";}}s:3:"oci";a:8:{s:8:"language";s:3:"oci";s:7:"version";s:6:"4.8.21";s:7:"updated";s:19:"2017-08-25 10:03:08";s:12:"english_name";s:7:"Occitan";s:11:"native_name";s:7:"Occitan";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/4.8.21/oci.zip";s:3:"iso";a:2:{i:1;s:2:"oc";i:2;s:3:"oci";}s:7:"strings";a:1:{s:8:"continue";s:9:"Contunhar";}}s:5:"pa_IN";a:8:{s:8:"language";s:5:"pa_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-16 05:19:43";s:12:"english_name";s:15:"Panjabi (India)";s:11:"native_name";s:18:"ਪੰਜਾਬੀ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip";s:3:"iso";a:2:{i:1;s:2:"pa";i:2;s:3:"pan";}s:7:"strings";a:1:{s:8:"continue";s:25:"ਜਾਰੀ ਰੱਖੋ";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-30 18:34:57";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:6:"4.3.30";s:7:"updated";s:19:"2015-12-02 21:41:29";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.3.30/ps.zip";s:3:"iso";a:2:{i:1;s:2:"ps";i:2;s:3:"pus";}s:7:"strings";a:1:{s:8:"continue";s:19:"دوام ورکړه";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-09 08:47:14";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:10:"pt_PT_ao90";a:8:{s:8:"language";s:10:"pt_PT_ao90";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-08-09 12:26:21";s:12:"english_name";s:27:"Portuguese (Portugal, AO90)";s:11:"native_name";s:17:"Português (AO90)";s:7:"package";s:69:"https://downloads.wordpress.org/translation/core/6.1.1/pt_PT_ao90.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_AO";a:8:{s:8:"language";s:5:"pt_AO";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-10-01 12:16:29";s:12:"english_name";s:19:"Portuguese (Angola)";s:11:"native_name";s:20:"Português de Angola";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/pt_AO.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-01 21:54:59";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"rhg";a:8:{s:8:"language";s:3:"rhg";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-16 13:03:18";s:12:"english_name";s:8:"Rohingya";s:11:"native_name";s:8:"Ruáinga";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip";s:3:"iso";a:1:{i:3;s:3:"rhg";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-05 04:37:02";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-25 17:58:11";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:3:"sah";a:8:{s:8:"language";s:3:"sah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-21 02:06:41";s:12:"english_name";s:5:"Sakha";s:11:"native_name";s:14:"Сахалыы";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip";s:3:"iso";a:2:{i:2;s:3:"sah";i:3;s:3:"sah";}s:7:"strings";a:1:{s:8:"continue";s:12:"Салҕаа";}}s:3:"snd";a:8:{s:8:"language";s:3:"snd";s:7:"version";s:6:"5.4.12";s:7:"updated";s:19:"2020-07-07 01:53:37";s:12:"english_name";s:6:"Sindhi";s:11:"native_name";s:8:"سنڌي";s:7:"package";s:63:"https://downloads.wordpress.org/translation/core/5.4.12/snd.zip";s:3:"iso";a:3:{i:1;s:2:"sd";i:2;s:3:"snd";i:3;s:3:"snd";}s:7:"strings";a:1:{s:8:"continue";s:15:"اڳتي هلو";}}s:5:"si_LK";a:8:{s:8:"language";s:5:"si_LK";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-12 06:00:52";s:12:"english_name";s:7:"Sinhala";s:11:"native_name";s:15:"සිංහල";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip";s:3:"iso";a:2:{i:1;s:2:"si";i:2;s:3:"sin";}s:7:"strings";a:1:{s:8:"continue";s:44:"දිගටම කරගෙන යන්න";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-20 04:27:59";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:3:"skr";a:8:{s:8:"language";s:3:"skr";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-06 09:43:42";s:12:"english_name";s:7:"Saraiki";s:11:"native_name";s:14:"سرائیکی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/6.1.1/skr.zip";s:3:"iso";a:1:{i:3;s:3:"skr";}s:7:"strings";a:1:{s:8:"continue";s:17:"جاری رکھو";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-11 12:48:55";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:8:"Nadaljuj";}}s:2:"sq";a:8:{s:8:"language";s:2:"sq";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-02-02 09:37:20";s:12:"english_name";s:8:"Albanian";s:11:"native_name";s:5:"Shqip";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/sq.zip";s:3:"iso";a:2:{i:1;s:2:"sq";i:2;s:3:"sqi";}s:7:"strings";a:1:{s:8:"continue";s:6:"Vazhdo";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"5.8.6";s:7:"updated";s:19:"2021-08-01 21:21:06";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/5.8.6/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-24 23:38:28";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"sw";a:8:{s:8:"language";s:2:"sw";s:7:"version";s:6:"5.3.14";s:7:"updated";s:19:"2019-10-13 15:35:35";s:12:"english_name";s:7:"Swahili";s:11:"native_name";s:9:"Kiswahili";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/5.3.14/sw.zip";s:3:"iso";a:2:{i:1;s:2:"sw";i:2;s:3:"swa";}s:7:"strings";a:1:{s:8:"continue";s:7:"Endelea";}}s:3:"szl";a:8:{s:8:"language";s:3:"szl";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-09-24 19:58:14";s:12:"english_name";s:8:"Silesian";s:11:"native_name";s:17:"Ślōnskŏ gŏdka";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip";s:3:"iso";a:1:{i:3;s:3:"szl";}s:7:"strings";a:1:{s:8:"continue";s:13:"Kōntynuować";}}s:5:"ta_IN";a:8:{s:8:"language";s:5:"ta_IN";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-27 03:22:47";s:12:"english_name";s:5:"Tamil";s:11:"native_name";s:15:"தமிழ்";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip";s:3:"iso";a:2:{i:1;s:2:"ta";i:2;s:3:"tam";}s:7:"strings";a:1:{s:8:"continue";s:24:"தொடரவும்";}}s:5:"ta_LK";a:8:{s:8:"language";s:5:"ta_LK";s:7:"version";s:6:"4.2.34";s:7:"updated";s:19:"2015-12-03 01:07:44";s:12:"english_name";s:17:"Tamil (Sri Lanka)";s:11:"native_name";s:15:"தமிழ்";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.2.34/ta_LK.zip";s:3:"iso";a:2:{i:1;s:2:"ta";i:2;s:3:"tam";}s:7:"strings";a:1:{s:8:"continue";s:18:"தொடர்க";}}s:2:"te";a:8:{s:8:"language";s:2:"te";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2017-01-26 15:47:39";s:12:"english_name";s:6:"Telugu";s:11:"native_name";s:18:"తెలుగు";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.7.2/te.zip";s:3:"iso";a:2:{i:1;s:2:"te";i:2;s:3:"tel";}s:7:"strings";a:1:{s:8:"continue";s:30:"కొనసాగించు";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"5.8.6";s:7:"updated";s:19:"2022-06-08 04:30:30";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/5.8.6/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:2:"tl";a:8:{s:8:"language";s:2:"tl";s:7:"version";s:6:"4.8.21";s:7:"updated";s:19:"2017-09-30 09:04:29";s:12:"english_name";s:7:"Tagalog";s:11:"native_name";s:7:"Tagalog";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.8.21/tl.zip";s:3:"iso";a:2:{i:1;s:2:"tl";i:2;s:3:"tgl";}s:7:"strings";a:1:{s:8:"continue";s:10:"Magpatuloy";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2023-01-04 13:32:22";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"tt_RU";a:8:{s:8:"language";s:5:"tt_RU";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-11-20 20:20:50";s:12:"english_name";s:5:"Tatar";s:11:"native_name";s:19:"Татар теле";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip";s:3:"iso";a:2:{i:1;s:2:"tt";i:2;s:3:"tat";}s:7:"strings";a:1:{s:8:"continue";s:17:"дәвам итү";}}s:3:"tah";a:8:{s:8:"language";s:3:"tah";s:7:"version";s:5:"4.7.2";s:7:"updated";s:19:"2016-03-06 18:39:39";s:12:"english_name";s:8:"Tahitian";s:11:"native_name";s:10:"Reo Tahiti";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip";s:3:"iso";a:3:{i:1;s:2:"ty";i:2;s:3:"tah";i:3;s:3:"tah";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:6:"4.9.22";s:7:"updated";s:19:"2021-07-03 18:41:33";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:16:"ئۇيغۇرچە";s:7:"package";s:65:"https://downloads.wordpress.org/translation/core/4.9.22/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:2:"uk";a:8:{s:8:"language";s:2:"uk";s:7:"version";s:5:"6.0.3";s:7:"updated";s:19:"2022-09-11 15:51:48";s:12:"english_name";s:9:"Ukrainian";s:11:"native_name";s:20:"Українська";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.0.3/uk.zip";s:3:"iso";a:2:{i:1;s:2:"uk";i:2;s:3:"ukr";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продовжити";}}s:2:"ur";a:8:{s:8:"language";s:2:"ur";s:7:"version";s:6:"5.4.12";s:7:"updated";s:19:"2020-04-09 11:17:33";s:12:"english_name";s:4:"Urdu";s:11:"native_name";s:8:"اردو";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/5.4.12/ur.zip";s:3:"iso";a:2:{i:1;s:2:"ur";i:2;s:3:"urd";}s:7:"strings";a:1:{s:8:"continue";s:19:"جاری رکھیں";}}s:5:"uz_UZ";a:8:{s:8:"language";s:5:"uz_UZ";s:7:"version";s:8:"5.8-beta";s:7:"updated";s:19:"2021-02-28 12:02:22";s:12:"english_name";s:5:"Uzbek";s:11:"native_name";s:11:"O‘zbekcha";s:7:"package";s:67:"https://downloads.wordpress.org/translation/core/5.8-beta/uz_UZ.zip";s:3:"iso";a:2:{i:1;s:2:"uz";i:2;s:3:"uzb";}s:7:"strings";a:1:{s:8:"continue";s:11:"Davom etish";}}s:2:"vi";a:8:{s:8:"language";s:2:"vi";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-17 10:13:02";s:12:"english_name";s:10:"Vietnamese";s:11:"native_name";s:14:"Tiếng Việt";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/6.1.1/vi.zip";s:3:"iso";a:2:{i:1;s:2:"vi";i:2;s:3:"vie";}s:7:"strings";a:1:{s:8:"continue";s:12:"Tiếp tục";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-12-18 06:20:30";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}s:5:"zh_HK";a:8:{s:8:"language";s:5:"zh_HK";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-07-15 15:25:03";s:12:"english_name";s:19:"Chinese (Hong Kong)";s:11:"native_name";s:12:"香港中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/zh_HK.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"6.1.1";s:7:"updated";s:19:"2022-11-15 22:21:52";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/6.1.1/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}}', 'no'),
(12680, '_transient_timeout_wpseo_total_unindexed_posts_limited', '1675735000', 'no'),
(12681, '_transient_wpseo_total_unindexed_posts_limited', '0', 'no'),
(12682, '_transient_timeout_wpseo_total_unindexed_terms_limited', '1675735000', 'no'),
(12683, '_transient_wpseo_total_unindexed_terms_limited', '0', 'no'),
(12863, '_transient_timeout_global_styles_mori', '1675739117', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(12864, '_transient_global_styles_mori', 'body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url(''#wp-duotone-dark-grayscale'');--wp--preset--duotone--grayscale: url(''#wp-duotone-grayscale'');--wp--preset--duotone--purple-yellow: url(''#wp-duotone-purple-yellow'');--wp--preset--duotone--blue-red: url(''#wp-duotone-blue-red'');--wp--preset--duotone--midnight: url(''#wp-duotone-midnight'');--wp--preset--duotone--magenta-yellow: url(''#wp-duotone-magenta-yellow'');--wp--preset--duotone--purple-green: url(''#wp-duotone-purple-green'');--wp--preset--duotone--blue-orange: url(''#wp-duotone-blue-orange'');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}', 'no');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_edit_lock', '1675069994:1'),
(4, 6, '_wp_attached_file', '2022/10/57446296.jpeg'),
(5, 6, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:566;s:4:"file";s:21:"2022/10/57446296.jpeg";s:8:"filesize";i:88882;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"57446296-600x340.jpeg";s:5:"width";i:600;s:6:"height";i:340;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:46441;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"57446296-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18131;}s:12:"medium_large";a:5:{s:4:"file";s:21:"57446296-768x435.jpeg";s:5:"width";i:768;s:6:"height";i:435;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67671;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(9, 1, '_edit_last', '1'),
(10, 1, '_yoast_wpseo_primary_category', '1'),
(11, 1, '_yoast_wpseo_content_score', '90'),
(12, 1, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(13, 1, '_yoast_wpseo_wordproof_timestamp', ''),
(17, 8, '_yoast_wpseo_primary_category', '1'),
(18, 8, '_yoast_wpseo_content_score', '60'),
(19, 8, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(20, 8, '_yoast_wpseo_wordproof_timestamp', ''),
(21, 8, '_dp_original', '1'),
(22, 8, '_edit_lock', '1675069983:1'),
(23, 8, '_edit_last', '1'),
(24, 13, '_edit_last', '1'),
(25, 13, '_edit_lock', '1666596414:1'),
(26, 15, '_wp_attached_file', '2022/10/3c360c78436f1ce29f0729837da04af1.pdf'),
(27, 15, '_wp_attachment_metadata', 'a:2:{s:5:"sizes";a:4:{s:4:"full";a:5:{s:4:"file";s:40:"3c360c78436f1ce29f0729837da04af1-pdf.jpg";s:5:"width";i:1058;s:6:"height";i:1497;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:336449;}s:6:"medium";a:5:{s:4:"file";s:48:"3c360c78436f1ce29f0729837da04af1-pdf-283x400.jpg";s:5:"width";i:283;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:72775;}s:5:"large";a:5:{s:4:"file";s:49:"3c360c78436f1ce29f0729837da04af1-pdf-724x1024.jpg";s:5:"width";i:724;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:193997;}s:9:"thumbnail";a:5:{s:4:"file";s:48:"3c360c78436f1ce29f0729837da04af1-pdf-141x200.jpg";s:5:"width";i:141;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:47302;}}s:8:"filesize";i:974326;}'),
(28, 13, '3dfb_type', 'pdf'),
(29, 13, '3dfb_thumbnail', 'a:2:{s:4:"data";a:1:{s:7:"post_ID";s:1:"0";}s:4:"type";s:4:"auto";}'),
(30, 13, '3dfb_data', 'a:4:{s:7:"post_ID";s:2:"15";s:4:"guid";s:88:"http://localhost:8081/wp/wp-content/uploads/2022/10/3c360c78436f1ce29f0729837da04af1.pdf";s:9:"pdf_pages";s:1:"2";s:19:"pages_customization";s:4:"none";}'),
(31, 13, '3dfb_book_style', 'flat'),
(32, 13, '3dfb_ready_function', ''),
(33, 13, '3dfb_props', 'a:14:{s:11:"cachedPages";s:4:"auto";s:19:"renderInactivePages";s:4:"auto";s:27:"renderInactivePagesOnMobile";s:4:"auto";s:19:"renderWhileFlipping";s:4:"auto";s:12:"preloadPages";s:4:"auto";s:3:"rtl";s:4:"auto";s:18:"interactiveCorners";s:4:"auto";s:5:"sheet";a:11:{s:13:"startVelocity";s:4:"auto";s:4:"wave";s:4:"auto";s:5:"shape";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:5:"color";s:4:"auto";s:4:"side";s:4:"auto";s:15:"cornerDeviation";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:12:"heightTexels";s:4:"auto";}s:5:"cover";a:14:{s:4:"wave";s:4:"auto";s:5:"color";s:4:"auto";s:13:"binderTexture";s:4:"auto";s:5:"depth";s:4:"auto";s:7:"padding";s:4:"auto";s:13:"startVelocity";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:12:"heightTexels";s:4:"auto";s:4:"mass";s:4:"auto";s:4:"side";s:4:"auto";s:5:"shape";s:4:"auto";}s:4:"page";a:12:{s:4:"wave";s:4:"auto";s:5:"color";s:4:"auto";s:5:"depth";s:4:"auto";s:13:"startVelocity";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:12:"heightTexels";s:4:"auto";s:4:"mass";s:4:"auto";s:4:"side";s:4:"auto";s:5:"shape";s:4:"auto";}s:6:"height";s:4:"auto";s:5:"width";s:4:"auto";s:7:"gravity";s:4:"auto";s:18:"pagesForPredicting";s:4:"auto";}'),
(34, 13, '3dfb_controlProps', 'a:1:{s:7:"actions";a:3:{s:7:"cmdSave";a:2:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";}s:8:"cmdPrint";a:2:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";}s:13:"cmdSinglePage";a:4:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";s:6:"active";s:4:"auto";s:15:"activeForMobile";s:4:"auto";}}}'),
(35, 13, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(36, 13, '_yoast_wpseo_wordproof_timestamp', ''),
(37, 3, '_edit_lock', '1675210745:1'),
(38, 3, '_edit_last', '1'),
(39, 3, '_yoast_wpseo_content_score', '30'),
(40, 3, '_yoast_wpseo_estimated-reading-time-minutes', '5'),
(41, 3, '_yoast_wpseo_wordproof_timestamp', ''),
(42, 2, '_edit_lock', '1675210741:1'),
(43, 2, '_edit_last', '1'),
(44, 2, '_has_fluentform', 'a:1:{i:3;s:1:"3";}'),
(45, 2, '_yoast_wpseo_estimated-reading-time-minutes', '1'),
(46, 2, '_yoast_wpseo_wordproof_timestamp', ''),
(47, 2, '_yoast_wpseo_content_score', '90'),
(50, 18, '_yoast_wpseo_primary_category', '1'),
(52, 18, '_yoast_wpseo_estimated-reading-time-minutes', '2'),
(53, 18, '_yoast_wpseo_wordproof_timestamp', ''),
(55, 18, '_dp_original', '8'),
(56, 18, '_edit_lock', '1675070000:1'),
(57, 19, '_wp_attached_file', '2022/10/32324171.jpeg'),
(58, 19, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:685;s:4:"file";s:21:"2022/10/32324171.jpeg";s:8:"filesize";i:213792;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:21:"32324171-584x400.jpeg";s:5:"width";i:584;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:90035;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"32324171-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28775;}s:12:"medium_large";a:5:{s:4:"file";s:21:"32324171-768x526.jpeg";s:5:"width";i:768;s:6:"height";i:526;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:146179;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(60, 18, '_edit_last', '1'),
(61, 13, '_wp_trash_meta_status', 'publish'),
(62, 13, '_wp_trash_meta_time', '1674830302'),
(63, 13, '_wp_desired_post_slug', '%e7%ab%8b%e6%86%b2%e6%b0%91%e4%b8%bb%e5%8f%b7%e5%a4%96'),
(64, 22, '_edit_last', '1'),
(65, 22, '_edit_lock', '1675067945:1'),
(66, 24, '_wp_attached_file', '2023/01/mori-kiyonori_compressed.pdf'),
(67, 24, '_wp_attachment_metadata', 'a:2:{s:5:"sizes";a:4:{s:4:"full";a:5:{s:4:"file";s:32:"mori-kiyonori_compressed-pdf.jpg";s:5:"width";i:3051;s:6:"height";i:2176;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:725799;}s:6:"medium";a:5:{s:4:"file";s:40:"mori-kiyonori_compressed-pdf-561x400.jpg";s:5:"width";i:561;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58282;}s:5:"large";a:5:{s:4:"file";s:41:"mori-kiyonori_compressed-pdf-1024x730.jpg";s:5:"width";i:1024;s:6:"height";i:730;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:145885;}s:9:"thumbnail";a:5:{s:4:"file";s:40:"mori-kiyonori_compressed-pdf-400x285.jpg";s:5:"width";i:400;s:6:"height";i:285;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34294;}}s:8:"filesize";i:447041;}'),
(70, 22, '3dfb_type', 'pdf'),
(71, 22, '3dfb_thumbnail', 'a:2:{s:4:"data";a:1:{s:7:"post_ID";s:2:"30";}s:4:"type";s:10:"mediaImage";}'),
(72, 22, '3dfb_data', 'a:4:{s:7:"post_ID";s:2:"24";s:4:"guid";s:84:"http://localhost:8081/wp/wp-content/uploads/2023/01/mori-kiyonori_compressed.pdf";s:9:"pdf_pages";s:1:"2";s:19:"pages_customization";s:4:"none";}'),
(73, 22, '3dfb_book_style', 'flat'),
(74, 22, '3dfb_ready_function', ''),
(75, 22, '3dfb_book_template', 'none'),
(76, 22, '3dfb_props', 'a:15:{s:11:"cachedPages";s:4:"auto";s:19:"renderInactivePages";s:4:"auto";s:27:"renderInactivePagesOnMobile";s:4:"auto";s:19:"renderWhileFlipping";s:4:"auto";s:12:"preloadPages";s:4:"auto";s:16:"autoPlayDuration";s:4:"auto";s:3:"rtl";s:4:"auto";s:18:"interactiveCorners";s:4:"auto";s:5:"sheet";a:11:{s:13:"startVelocity";s:4:"auto";s:4:"wave";s:4:"auto";s:5:"shape";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:5:"color";s:4:"auto";s:4:"side";s:4:"auto";s:15:"cornerDeviation";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:12:"heightTexels";s:4:"auto";}s:5:"cover";a:14:{s:4:"wave";s:4:"auto";s:5:"color";s:4:"auto";s:13:"binderTexture";s:4:"auto";s:5:"depth";s:4:"auto";s:7:"padding";s:4:"auto";s:13:"startVelocity";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:12:"heightTexels";s:4:"auto";s:4:"mass";s:4:"auto";s:4:"side";s:4:"auto";s:5:"shape";s:4:"auto";}s:4:"page";a:12:{s:4:"wave";s:4:"auto";s:5:"color";s:4:"auto";s:5:"depth";s:4:"auto";s:13:"startVelocity";s:4:"auto";s:11:"flexibility";s:4:"auto";s:14:"flexibleCorner";s:4:"auto";s:7:"bending";s:4:"auto";s:11:"widthTexels";s:4:"auto";s:12:"heightTexels";s:4:"auto";s:4:"mass";s:4:"auto";s:4:"side";s:4:"auto";s:5:"shape";s:4:"auto";}s:6:"height";s:4:"auto";s:5:"width";s:4:"auto";s:7:"gravity";s:4:"auto";s:18:"pagesForPredicting";s:4:"auto";}'),
(77, 22, '3dfb_controlProps', 'a:1:{s:7:"actions";a:6:{s:6:"cmdToc";a:4:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";s:6:"active";s:4:"auto";s:10:"defaultTab";s:4:"auto";}s:11:"cmdAutoPlay";a:3:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";s:6:"active";s:4:"auto";}s:7:"cmdSave";a:2:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";}s:8:"cmdPrint";a:2:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";}s:13:"cmdSinglePage";a:4:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";s:6:"active";s:4:"auto";s:15:"activeForMobile";s:4:"auto";}s:10:"widToolbar";a:2:{s:7:"enabled";s:4:"auto";s:15:"enabledInNarrow";s:4:"auto";}}}'),
(78, 22, '3dfb_outline', 'a:0:{}'),
(79, 22, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(80, 22, '_yoast_wpseo_wordproof_timestamp', ''),
(83, 27, '_edit_last', '1'),
(84, 27, '_edit_lock', '1675210743:1'),
(85, 27, '_yoast_wpseo_estimated-reading-time-minutes', '0'),
(86, 27, '_yoast_wpseo_wordproof_timestamp', ''),
(87, 30, '_wp_attached_file', '2023/01/maki3ori_A4_3_hidari_omote.jpg'),
(88, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:360;s:6:"height";i:257;s:4:"file";s:38:"2023/01/maki3ori_A4_3_hidari_omote.jpg";s:8:"filesize";i:48040;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(89, 31, '_wp_attached_file', '2023/01/favi.png'),
(90, 31, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:16:"2023/01/favi.png";s:8:"filesize";i:18119;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:16:"favi-400x400.png";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:20224;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"favi-400x400.png";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:20224;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(91, 32, '_wp_attached_file', '2023/01/cropped-favi.png'),
(92, 32, '_wp_attachment_context', 'site-icon'),
(93, 32, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:24:"2023/01/cropped-favi.png";s:8:"filesize";i:5578;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"cropped-favi-400x400.png";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18510;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"cropped-favi-400x400.png";s:5:"width";i:400;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18510;}s:13:"site_icon-270";a:5:{s:4:"file";s:24:"cropped-favi-270x270.png";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12332;}s:13:"site_icon-192";a:5:{s:4:"file";s:24:"cropped-favi-192x192.png";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8823;}s:13:"site_icon-180";a:5:{s:4:"file";s:24:"cropped-favi-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8156;}s:12:"site_icon-32";a:5:{s:4:"file";s:22:"cropped-favi-32x32.png";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1200;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(94, 33, '_wp_trash_meta_status', 'publish'),
(95, 33, '_wp_trash_meta_time', '1674832827'),
(96, 34, '_wp_attached_file', '2023/01/ogp.png'),
(97, 34, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1024;s:6:"height";i:512;s:4:"file";s:15:"2023/01/ogp.png";s:8:"filesize";i:348306;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:15:"ogp-600x300.png";s:5:"width";i:600;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:116466;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"ogp-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:59217;}s:12:"medium_large";a:5:{s:4:"file";s:15:"ogp-768x384.png";s:5:"width";i:768;s:6:"height";i:384;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:176918;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(104, 18, '_yoast_wpseo_content_score', '30'),
(115, 18, '_wp_old_date', '2022-10-25'),
(118, 8, '_wp_old_date', '2022-10-24'),
(121, 1, '_wp_old_date', '2022-10-07'),
(124, 18, '_wp_old_date', '2022-10-28'),
(127, 1, '_wp_old_date', '2022-10-28'),
(132, 45, '_wp_attached_file', '2023/01/test.png'),
(133, 45, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1913;s:6:"height";i:1859;s:4:"file";s:16:"2023/01/test.png";s:8:"filesize";i:2887600;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:16:"test-412x400.png";s:5:"width";i:412;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:186406;}s:5:"large";a:5:{s:4:"file";s:17:"test-1024x995.png";s:5:"width";i:1024;s:6:"height";i:995;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:903839;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"test-400x389.png";s:5:"width";i:400;s:6:"height";i:389;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:177131;}s:12:"medium_large";a:5:{s:4:"file";s:16:"test-768x746.png";s:5:"width";i:768;s:6:"height";i:746;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:553362;}s:9:"1536x1536";a:5:{s:4:"file";s:18:"test-1536x1493.png";s:5:"width";i:1536;s:6:"height";i:1493;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1798084;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(138, 47, '_wp_attached_file', '2023/01/test-1.png'),
(139, 47, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1913;s:6:"height";i:1859;s:4:"file";s:18:"2023/01/test-1.png";s:8:"filesize";i:2887600;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:18:"test-1-412x400.png";s:5:"width";i:412;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:186406;}s:5:"large";a:5:{s:4:"file";s:19:"test-1-1024x995.png";s:5:"width";i:1024;s:6:"height";i:995;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:903839;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"test-1-400x389.png";s:5:"width";i:400;s:6:"height";i:389;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:177131;}s:12:"medium_large";a:5:{s:4:"file";s:18:"test-1-768x746.png";s:5:"width";i:768;s:6:"height";i:746;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:553362;}s:9:"1536x1536";a:5:{s:4:"file";s:20:"test-1-1536x1493.png";s:5:"width";i:1536;s:6:"height";i:1493;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1798084;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(161, 55, '_wp_attached_file', '2023/01/profile_sp.webp'),
(162, 55, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:540;s:4:"file";s:23:"2023/01/profile_sp.webp";s:8:"filesize";i:15118;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:23:"profile_sp-600x338.webp";s:5:"width";i:600;s:6:"height";i:338;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:8308;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"profile_sp-400x225.webp";s:5:"width";i:400;s:6:"height";i:225;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:4994;}s:12:"medium_large";a:5:{s:4:"file";s:23:"profile_sp-768x432.webp";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/webp";s:8:"filesize";i:10854;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(170, 57, '_wp_attached_file', '2023/01/top.png'),
(171, 57, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1917;s:6:"height";i:1803;s:4:"file";s:15:"2023/01/top.png";s:8:"filesize";i:2096973;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:15:"top-425x400.png";s:5:"width";i:425;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:169331;}s:5:"large";a:5:{s:4:"file";s:16:"top-1024x963.png";s:5:"width";i:1024;s:6:"height";i:963;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:724118;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"top-400x376.png";s:5:"width";i:400;s:6:"height";i:376;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153546;}s:12:"medium_large";a:5:{s:4:"file";s:15:"top-768x722.png";s:5:"width";i:768;s:6:"height";i:722;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:452058;}s:9:"1536x1536";a:5:{s:4:"file";s:17:"top-1536x1445.png";s:5:"width";i:1536;s:6:"height";i:1445;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1403799;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(176, 8, '_wp_old_date', '2023-01-28'),
(179, 1, '_wp_old_date', '2023-01-28'),
(182, 18, '_wp_old_date', '2023-01-28');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-01-30 16:00:12', '2023-01-30 07:00:12', '<!-- wp:paragraph -->\n<p>札幌市議会議員選挙（厚別区）の候補予定者として立憲民主党の公認が決定しました。<br>札幌市民の皆さんの選択肢となりうる、しっかりとした活動を行ってまいります。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>どうぞよろしくお願いいたします。</p>\n<!-- /wp:paragraph -->', '札幌市議会議員選挙（厚別区）の候補予定者に決定', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2023-01-30 18:13:13', '2023-01-30 09:13:13', '', 0, 'http://localhost:8081/wp/?p=1', 0, 'post', '', 1),
(2, 1, '2022-10-07 13:42:12', '2022-10-07 04:42:12', '[fluentform id="3"]', 'お問い合わせ', '', 'publish', 'closed', 'open', '', 'contact', '', '', '2022-10-25 13:36:26', '2022-10-25 04:36:26', '', 0, 'http://localhost:8081/wp/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-10-07 13:42:12', '2022-10-07 04:42:12', '      <h4>個人情報の取扱い</h4>\r\n      <p>\r\n        当団体は、政治団体ですので、個人情報の保護に関する法律の適用除外に該当します。しかし、その趣旨を踏まえ、皆様からご提供いただきましたいかなる個人情報も厳正に管理・保管し、当団体の活動においてのみ利用し、ご本人の同意なく利用することも、また、無断で第３者に提供または共有することもありません。但し、以下の場合に限り、個人情報を開示することがあります。\r\n      </p>\r\n      <ul>\r\n        <li>情報開示や共有についての同意又は承諾がある場合</li>\r\n        <li>裁判所や警察等の公的機関から、法律に基づく正式な照会を受けた場合</li>\r\n        <li>その他、正当行為等、違法性が阻却される場合</li>\r\n      </ul>\r\n\r\n      <h4>個人情報の利用</h4>\r\n      <p>当団体において、個人情報は以下の政治活動目的又はこれに付随する目的で利用されます。特定の用途での利用を拒絶したい場合やご自身の登録内容を抹消したい場合は、いつでも当団体にその旨を要求することができます。</p>\r\n      <ul>\r\n        <li>政策広報などのため、各種通信物の送信や質問等への返信を行うため</li>\r\n        <li>その他、何らかの理由で皆様とコンタクトする必要が生じたときのため</li>\r\n      </ul>\r\n\r\n      <h4>個人情報の収集と本人の同意</h4>\r\n      <p>\r\n        当団体は、政治団体であるため、第三者からご紹介を受けて個人情報を取得する場合がありますが、その場合は、すみやかに利用目的ならびに紹介者名をご本人様に通知し、ご承諾が得られない場合は、その際に登録された個人情報はすみやかに消去いたします。\r\n      </p>\r\n', 'プライバシーポリシー', '', 'publish', 'closed', 'open', '', 'privacy-policy', '', '', '2023-01-30 20:13:21', '2023-01-30 11:13:21', '', 0, 'http://localhost:8081/wp/?page_id=3', 0, 'page', '', 0),
(5, 1, '2022-10-24 11:09:48', '2022-10-24 02:09:48', '{"version": 2, "isGlobalStylesUserThemeJSON": true }', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-politics', '', '', '2022-10-24 11:09:48', '2022-10-24 02:09:48', '', 0, 'http://localhost:8081/?p=5', 0, 'wp_global_styles', '', 0),
(6, 1, '2022-10-24 11:10:18', '2022-10-24 02:10:18', '', '57446296', '', 'inherit', 'open', 'closed', '', '57446296', '', '', '2022-10-24 11:10:18', '2022-10-24 02:10:18', '', 1, 'http://localhost:8081/wp/wp-content/uploads/2022/10/57446296.jpeg', 0, 'attachment', 'image/jpeg', 0),
(7, 1, '2022-10-24 11:10:26', '2022-10-24 02:10:26', '<!-- wp:paragraph -->\n<p>WordPress へようこそ。こちらは最初の投稿です。編集または削除し、コンテンツ作成を始めてください。</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-10-24 11:10:26', '2022-10-24 02:10:26', '', 1, 'http://localhost:8081/?p=7', 0, 'revision', '', 0),
(8, 1, '2023-01-30 15:00:17', '2023-01-30 06:00:17', '<!-- wp:paragraph -->\n<p>「森きよのり」オフィシャルサイトを開設しました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>本ホームページとSNSを活用し、今後「森きよのり」の活動情報や想いを伝えていきます。<br>よろしくお願いいたします。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":57,"width":561,"height":527,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8081/wp/wp-content/uploads/2023/01/top-1024x963.png" alt="" class="wp-image-57" width="561" height="527"/></figure>\n<!-- /wp:image -->', 'オフィシャルサイトを開設しました。', '', 'publish', 'open', 'open', '', '%e3%83%9b%e3%83%bc%e3%83%a0%e3%83%9a%e3%83%bc%e3%82%b8%e3%82%92%e9%96%8b%e8%a8%ad%e3%81%97%e3%81%be%e3%81%97%e3%81%9f%e3%80%82', '', '', '2023-01-30 18:13:03', '2023-01-30 09:13:03', '', 0, 'http://localhost:8081/?p=8', 0, 'post', '', 0),
(9, 1, '2022-10-24 11:51:17', '2022-10-24 02:51:17', '<!-- wp:paragraph -->\n<p>WordPress へようこそ。こちらは最初の投稿です。編集または削除し、コンテンツ作成を始めてください。</p>\n<!-- /wp:paragraph -->', 'ホームページを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2022-10-24 11:51:17', '2022-10-24 02:51:17', '', 8, 'http://localhost:8081/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-10-24 12:37:15', '2022-10-24 03:37:15', '<!-- wp:paragraph -->\n<p>立憲民主党は、渭i9j(たかひろを須田靖子道議の後継として北海道議会議員選挙（手稲区）の公認候補予定者に決定しました。須田道議は「働く仲間の労働条件向上、安心な医療体制作り、環境問題」などの実現に向け、市民自治の向上や福祉のまちづくりに長年取り組んできました。</p>\n<!-- /wp:paragraph -->', '北海道議会議員選挙（手稲区）の公認候補予定者に決定', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-10-24 12:37:15', '2022-10-24 03:37:15', '', 1, 'http://localhost:8081/?p=10', 0, 'revision', '', 0),
(13, 1, '2022-10-24 16:26:49', '2022-10-24 07:26:49', '', '立憲民主号外', '', 'trash', 'closed', 'closed', '', '%e7%ab%8b%e6%86%b2%e6%b0%91%e4%b8%bb%e5%8f%b7%e5%a4%96__trashed', '', '', '2023-01-27 23:38:22', '2023-01-27 14:38:22', '', 0, 'http://localhost:8081/?post_type=3d-flip-book&#038;p=13', 0, '3d-flip-book', '', 0),
(15, 1, '2022-10-24 16:26:03', '2022-10-24 07:26:03', '', '22.8清水たかひろA4巻三-3', '', 'inherit', 'open', 'closed', '', '22-8%e6%b8%85%e6%b0%b4%e3%81%9f%e3%81%8b%e3%81%b2%e3%82%8da4%e5%b7%bb%e4%b8%89-3', '', '', '2022-10-24 16:26:03', '2022-10-24 07:26:03', '', 13, 'http://localhost:8081/wp/wp-content/uploads/2022/10/3c360c78436f1ce29f0729837da04af1.pdf', 0, 'attachment', 'application/pdf', 0),
(16, 1, '2022-10-25 11:50:14', '2022-10-25 02:50:14', '<!-- wp:heading -->\r\n<h2>私たちについて</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>私たちのサイトアドレスは http://localhost:8081/wp です。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>コメント</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>訪問者がこのサイトにコメントを残す際、コメントフォームに表示されているデータ、そしてスパム検出に役立てるための IP アドレスとブラウザーユーザーエージェント文字列を収集します。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>メールアドレスから作成される匿名化された (「ハッシュ」とも呼ばれる) 文字列は、あなたが Gravatar サービスを使用中かどうか確認するため同サービスに提供されることがあります。同サービスのプライバシーポリシーは https://automattic.com/privacy/ にあります。コメントが承認されると、プロフィール画像がコメントとともに一般公開されます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>メディア</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>サイトに画像をアップロードする際、位置情報 (EXIF GPS) を含む画像をアップロードするべきではありません。サイトの訪問者は、サイトから画像をダウンロードして位置データを抽出することができます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>Cookie</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>サイトにコメントを残す際、お名前、メールアドレス、サイトを Cookie に保存することにオプトインできます。これはあなたの便宜のためであり、他のコメントを残す際に詳細情報を再入力する手間を省きます。この Cookie は1年間保持されます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>ログインページを訪問すると、お使いのブラウザーが Cookie を受け入れられるかを判断するために一時 Cookie を設定します。この Cookie は個人データを含んでおらず、ブラウザーを閉じると廃棄されます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>ログインの際さらに、ログイン情報と画面表示情報を保持するため、私たちはいくつかの Cookie を設定します。ログイン Cookie は2日間、画面表示オプション Cookie は1年間保持されます。「ログイン状態を保存する」を選択した場合、ログイン情報は2週間維持されます。ログアウトするとログイン Cookie は消去されます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>もし投稿を編集または公開すると、さらなる Cookie がブラウザーに保存されます。この Cookie は個人データを含まず、単に変更した投稿の ID を示すものです。1日で有効期限が切れます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>他サイトからの埋め込みコンテンツ</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>このサイトの投稿には埋め込みコンテンツ (動画、画像、投稿など) が含まれます。他サイトからの埋め込みコンテンツは、訪問者がそのサイトを訪れた場合とまったく同じように振る舞います。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>これらのサイトは、あなたのデータの収集、Cookie の使用、サードパーティによる追加トラッキングの埋め込み、埋め込みコンテンツとのやりとりの監視を行うことがあります。アカウントを使ってそのサイトにログイン中の場合、埋め込みコンテンツとのやりとりのトラッキングも含まれます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>あなたのデータの共有先</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>パスワードリセットをリクエストすると、IP アドレスがリセット用のメールに含まれます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>データを保存する期間</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>あなたがコメントを残すと、コメントとそのメタデータが無期限に保持されます。これは、モデレーションキューにコメントを保持しておく代わりに、フォローアップのコメントを自動的に認識し承認できるようにするためです。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:paragraph -->\r\n<p>このサイトに登録したユーザーがいる場合、その方がユーザープロフィールページで提供した個人情報を保存します。すべてのユーザーは自分の個人情報を表示、編集、削除することができます (ただしユーザー名は変更することができません)。サイト管理者もそれらの情報を表示、編集できます。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>データに対するあなたの権利</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>このサイトのアカウントを持っているか、サイトにコメントを残したことがある場合、私たちが保持するあなたについての個人データ (提供したすべてのデータを含む) をエクスポートファイルとして受け取るリクエストを行うことができます。また、個人データの消去リクエストを行うこともできます。これには、管理、法律、セキュリティ目的のために保持する義務があるデータは含まれません。</p>\r\n<!-- /wp:paragraph -->\r\n\r\n<!-- wp:heading -->\r\n<h2>どこにあなたのデータが送られるか</h2>\r\n<!-- /wp:heading -->\r\n\r\n<!-- wp:paragraph -->\r\n<p><strong class="privacy-policy-tutorial">提案テキスト: </strong>訪問者によるコメントは、自動スパム検出サービスを通じて確認を行う場合があります。</p>\r\n<!-- /wp:paragraph -->', 'プライバシーポリシー', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2022-10-25 11:50:14', '2022-10-25 02:50:14', '', 3, 'http://localhost:8081/?p=16', 0, 'revision', '', 0),
(17, 1, '2022-10-25 11:50:48', '2022-10-25 02:50:48', '[fluentform id="3"]', 'お問い合わせ', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2022-10-25 11:50:48', '2022-10-25 02:50:48', '', 2, 'http://localhost:8081/?p=17', 0, 'revision', '', 0),
(18, 1, '2023-01-30 17:00:29', '2023-01-30 08:00:29', '<!-- wp:paragraph -->\n<p>「おはようございます。森 基誉則です」と、今年の1月30日まで、土日を除く毎朝、ラジオ（AIR-G’）でお喋りをしていました。平日早朝6時から始業直前となる方が多い9時までの3時間、少しでも心地のいい目覚めを、少しでも仕事や勉強への活力を届けたいと思いながらの生放送でした。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>リスナーからは、元気をもらえるとか、しっかり目覚められると言っていただくこともあれば、うるさすぎるとか、二日酔いの朝は頭に響くという言葉もいただきました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>私にとっては、全て大切な意見で財産です私のラジオでのモットーは、「批判的な人と距離を取るのではなく、何が気に食わないのかを詳らかにした上で近づいていこう」というものでした。自分に批判的な人とは近づきたくなくなるものです。しかし、それは勿体無いと考えていました。批判は、対立を先鋭化するようなものではなく、気づいていなかった視点を教えてくれるもので、より正しい方向へ協働して模索するために必要な存在です。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>政治の世界へ踏み出そうと決意したこれからは、より強い批判や、反対の意見も頂戴すると思います。その際は、ぜひ話し合いや議論を重ねさせてください。そういう時間は、建築物の筋交いのように私の考えを強靭にしてくれると信じています。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>政治は言葉で動きます。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>あなたの言葉をください。私に浴びせてください、ぶつけてください。どこまであなたの意向に添えるかは分かりませんが、その言葉を札幌市に届けてみせます。共に札幌の明日のために！</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '新たなスタートを切ります。（決意表明）', '', 'publish', 'open', 'open', '', '%e8%a4%87%e8%a3%bd%e3%81%95%e3%82%8c%e3%81%9f%e8%a8%98%e4%ba%8b', '', '', '2023-01-30 18:13:20', '2023-01-30 09:13:20', '', 0, 'http://localhost:8081/?p=18', 0, 'post', '', 0),
(19, 1, '2022-10-25 17:05:51', '2022-10-25 08:05:51', '', '32324171', '', 'inherit', 'open', 'closed', '', '32324171', '', '', '2022-10-25 17:05:51', '2022-10-25 08:05:51', '', 18, 'http://localhost:8081/wp/wp-content/uploads/2022/10/32324171.jpeg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2022-10-25 17:06:29', '2022-10-25 08:06:29', '<!-- wp:paragraph -->\n<p>WordPress へようこそ。こちらは最初の投稿です。編集または削除し、コンテンツ作成を始めてください。</p>\n<!-- /wp:paragraph -->', '複製された記事', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2022-10-25 17:06:29', '2022-10-25 08:06:29', '', 18, 'http://localhost:8081/?p=20', 0, 'revision', '', 0),
(22, 1, '2023-01-27 23:40:26', '2023-01-27 14:40:26', '', 'パンフレット', '', 'publish', 'closed', 'closed', '', '%e3%83%91%e3%83%b3%e3%83%95%e3%83%ac%e3%83%83%e3%83%88', '', '', '2023-01-30 17:41:26', '2023-01-30 08:41:26', '', 0, 'http://localhost:8081/?post_type=3d-flip-book&#038;p=22', 0, '3d-flip-book', '', 0),
(24, 1, '2023-01-27 23:39:24', '2023-01-27 14:39:24', '', 'mori-kiyonori_compressed', '', 'inherit', 'open', 'closed', '', 'mori-kiyonori_compressed', '', '', '2023-01-27 23:39:24', '2023-01-27 14:39:24', '', 22, 'http://localhost:8081/wp/wp-content/uploads/2023/01/mori-kiyonori_compressed.pdf', 0, 'attachment', 'application/pdf', 0),
(27, 1, '2023-01-28 00:06:18', '2023-01-27 15:06:18', '', 'ニュース', '', 'publish', 'closed', 'closed', '', 'newslist', '', '', '2023-01-28 00:06:18', '2023-01-27 15:06:18', '', 0, 'http://localhost:8081/?page_id=27', 0, 'page', '', 0),
(29, 1, '2023-01-28 00:06:18', '2023-01-27 15:06:18', '', 'ニュース', '', 'inherit', 'closed', 'closed', '', '27-revision-v1', '', '', '2023-01-28 00:06:18', '2023-01-27 15:06:18', '', 27, 'http://localhost:8081/?p=29', 0, 'revision', '', 0),
(30, 1, '2023-01-28 00:09:33', '2023-01-27 15:09:33', '', 'maki3ori_A4_3_hidari_omote', '', 'inherit', 'open', 'closed', '', 'maki3ori_a4_3_hidari_omote', '', '', '2023-01-28 00:09:33', '2023-01-27 15:09:33', '', 22, 'http://localhost:8081/wp/wp-content/uploads/2023/01/maki3ori_A4_3_hidari_omote.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2023-01-28 00:20:20', '2023-01-27 15:20:20', '', 'favi', '', 'inherit', 'open', 'closed', '', 'favi', '', '', '2023-01-28 00:20:20', '2023-01-27 15:20:20', '', 0, 'http://localhost:8081/wp/wp-content/uploads/2023/01/favi.png', 0, 'attachment', 'image/png', 0),
(32, 1, '2023-01-28 00:20:25', '2023-01-27 15:20:25', 'http://localhost:8081/wp/wp-content/uploads/2023/01/cropped-favi.png', 'cropped-favi.png', '', 'inherit', 'open', 'closed', '', 'cropped-favi-png', '', '', '2023-01-28 00:20:25', '2023-01-27 15:20:25', '', 0, 'http://localhost:8081/wp/wp-content/uploads/2023/01/cropped-favi.png', 0, 'attachment', 'image/png', 0),
(33, 1, '2023-01-28 00:20:27', '2023-01-27 15:20:27', '{\n    "site_icon": {\n        "value": 32,\n        "type": "option",\n        "user_id": 1,\n        "date_modified_gmt": "2023-01-27 15:20:27"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7b3ad218-df4a-4137-956e-5069862b4792', '', '', '2023-01-28 00:20:27', '2023-01-27 15:20:27', '', 0, 'http://localhost:8081/33.html', 0, 'customize_changeset', '', 0),
(34, 1, '2023-01-28 00:25:15', '2023-01-27 15:25:15', '', 'ogp', '', 'inherit', 'open', 'closed', '', 'ogp', '', '', '2023-01-28 00:25:15', '2023-01-27 15:25:15', '', 0, 'http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2023-01-28 18:39:43', '2023-01-28 09:39:43', '', '森きよのりの決意表明', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-01-28 18:39:43', '2023-01-28 09:39:43', '', 18, 'http://localhost:8081/?p=36', 0, 'revision', '', 0),
(38, 1, '2023-01-28 18:40:12', '2023-01-28 09:40:12', '<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '森きよのりの決意表明', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-01-28 18:40:12', '2023-01-28 09:40:12', '', 18, 'http://localhost:8081/?p=38', 0, 'revision', '', 0),
(40, 1, '2023-01-28 18:41:12', '2023-01-28 09:41:12', '<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '新たなスタートを切ります。（決意表明）', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-01-28 18:41:12', '2023-01-28 09:41:12', '', 18, 'http://localhost:8081/?p=40', 0, 'revision', '', 0),
(41, 1, '2023-01-28 18:42:01', '2023-01-28 09:42:01', '<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>。</p>\n<!-- /wp:paragraph -->', '札幌市議会議員選挙（厚別区）の公認候補予定者に決定', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2023-01-28 18:42:01', '2023-01-28 09:42:01', '', 1, 'http://localhost:8081/?p=41', 0, 'revision', '', 0),
(42, 1, '2023-01-28 18:42:26', '2023-01-28 09:42:26', '<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。文章はいる。</p>\n<!-- /wp:paragraph -->', 'オフィシャルサイトを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-01-28 18:42:26', '2023-01-28 09:42:26', '', 8, 'http://localhost:8081/?p=42', 0, 'revision', '', 0),
(45, 1, '2023-01-29 13:46:24', '2023-01-29 04:46:24', '', 'test', '', 'inherit', 'open', 'closed', '', 'test', '', '', '2023-01-29 13:46:24', '2023-01-29 04:46:24', '', 8, 'http://localhost:8081/wp/wp-content/uploads/2023/01/test.png', 0, 'attachment', 'image/png', 0),
(46, 1, '2023-01-29 13:46:30', '2023-01-29 04:46:30', '<!-- wp:paragraph -->\n<p>森きよのりのオフィシャルホームページを開設しました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>本ホームページとSNSを活用し、今後「森きよのり」の活動情報や想いを伝えていきます。<br>よろしくお願いいたします。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image -->\n<figure class="wp-block-image"><img alt=""/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'オフィシャルサイトを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-01-29 13:46:30', '2023-01-29 04:46:30', '', 8, 'http://localhost:8081/?p=46', 0, 'revision', '', 0),
(47, 1, '2023-01-29 13:46:57', '2023-01-29 04:46:57', '', 'test-1', '', 'inherit', 'open', 'closed', '', 'test-1', '', '', '2023-01-29 13:46:57', '2023-01-29 04:46:57', '', 8, 'http://localhost:8081/wp/wp-content/uploads/2023/01/test-1.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2023-01-29 13:47:09', '2023-01-29 04:47:09', '<!-- wp:paragraph -->\n<p>森きよのりのオフィシャルホームページを開設しました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>本ホームページとSNSを活用し、今後「森きよのり」の活動情報や想いを伝えていきます。<br>よろしくお願いいたします。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":47,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost:8081/wp/wp-content/uploads/2023/01/test-1-1024x995.png" alt="" class="wp-image-47"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'オフィシャルサイトを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-01-29 13:47:09', '2023-01-29 04:47:09', '', 8, 'http://localhost:8081/?p=48', 0, 'revision', '', 0),
(49, 1, '2023-01-29 13:48:13', '2023-01-29 04:48:13', '<!-- wp:paragraph -->\n<p>「森きよのり」オフィシャルサイトを開設しました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>本ホームページとSNSを活用し、今後「森きよのり」の活動情報や想いを伝えていきます。<br>よろしくお願いいたします。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":47,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="http://localhost:8081/wp/wp-content/uploads/2023/01/test-1-1024x995.png" alt="" class="wp-image-47"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'オフィシャルサイトを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-01-29 13:48:13', '2023-01-29 04:48:13', '', 8, 'http://localhost:8081/?p=49', 0, 'revision', '', 0),
(52, 1, '2023-01-29 14:18:54', '2023-01-29 05:18:54', '<!-- wp:paragraph -->\n<p>札幌市議会議員選挙（厚別区）の候補予定者として立憲民主党の公認が決定しました。<br>札幌市民の皆さんの選択肢となりうる、しっかりとした活動を行ってまいります。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>どうぞよろしくお願いいたします。</p>\n<!-- /wp:paragraph -->', '札幌市議会議員選挙（厚別区）の候補予定者に決定', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2023-01-29 14:18:54', '2023-01-29 05:18:54', '', 1, 'http://localhost:8081/?p=52', 0, 'revision', '', 0),
(54, 1, '2023-01-30 10:42:53', '2023-01-30 01:42:53', '<!-- wp:paragraph -->\n<p>「おはようございます。森 基誉則です」と、今年の1月30日まで、土日を除く毎朝、ラジオ（AIR-G’）でお喋りをしていました。平日早朝6時から始業直前となる方が多い9時までの3時間、少しでも心地のいい目覚めを、少しでも仕事や勉強への活力を届けたいと思いながらの生放送でした。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>リスナーからは、元気をもらえるとか、しっかり目覚められると言っていただくこともあれば、うるさすぎるとか、二日酔いの朝は頭に響くという言葉もいただきました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p><br>私にとっては、全て大切な意見で財産です私のラジオでのモットーは、「批判的な人と距離を取るのではなく、何が気に食わないのかを詳らかにした上で近づいていこう」というものでした。自分に批判的な人とは近づきたくなくなるものです。しかし、それは勿体無いと考えていました。批判は、対立を先鋭化するようなものではなく、気づいていなかった視点を教えてくれるもので、より正しい方向へ協働して模索するために必要な存在です。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>政治の世界へ踏み出そうと決意したこれからは、より強い批判や、反対の意見も頂戴すると思います。その際は、ぜひ話し合いや議論を重ねさせてください。そういう時間は、建築物の筋交いのように私の考えを強靭にしてくれると信じています。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>政治は言葉で動きます。<br></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>あなたの言葉をください。私に浴びせてください、ぶつけてください。どこまであなたの意向に添えるかは分かりませんが、その言葉を札幌市に届けてみせます。共に札幌の明日のために！</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', '新たなスタートを切ります。（決意表明）', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2023-01-30 10:42:53', '2023-01-30 01:42:53', '', 18, 'http://localhost:8081/?p=54', 0, 'revision', '', 0),
(55, 1, '2023-01-30 11:38:00', '2023-01-30 02:38:00', '', 'profile_sp', '', 'inherit', 'open', 'closed', '', 'profile_sp', '', '', '2023-01-30 11:38:00', '2023-01-30 02:38:00', '', 18, 'http://localhost:8081/wp/wp-content/uploads/2023/01/profile_sp.webp', 0, 'attachment', 'image/webp', 0),
(57, 1, '2023-01-30 16:39:05', '2023-01-30 07:39:05', '', 'top', '', 'inherit', 'open', 'closed', '', 'top', '', '', '2023-01-30 16:39:05', '2023-01-30 07:39:05', '', 8, 'http://localhost:8081/wp/wp-content/uploads/2023/01/top.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2023-01-30 16:39:56', '2023-01-30 07:39:56', '<!-- wp:paragraph -->\n<p>「森きよのり」オフィシャルサイトを開設しました。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>本ホームページとSNSを活用し、今後「森きよのり」の活動情報や想いを伝えていきます。<br>よろしくお願いいたします。</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":57,"width":561,"height":527,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large is-resized"><img src="http://localhost:8081/wp/wp-content/uploads/2023/01/top-1024x963.png" alt="" class="wp-image-57" width="561" height="527"/></figure>\n<!-- /wp:image -->', 'オフィシャルサイトを開設しました。', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2023-01-30 16:39:56', '2023-01-30 07:39:56', '', 8, 'http://localhost:8081/?p=58', 0, 'revision', '', 0),
(59, 1, '2023-01-30 20:13:21', '2023-01-30 11:13:21', '      <h4>個人情報の取扱い</h4>\r\n      <p>\r\n        当団体は、政治団体ですので、個人情報の保護に関する法律の適用除外に該当します。しかし、その趣旨を踏まえ、皆様からご提供いただきましたいかなる個人情報も厳正に管理・保管し、当団体の活動においてのみ利用し、ご本人の同意なく利用することも、また、無断で第３者に提供または共有することもありません。但し、以下の場合に限り、個人情報を開示することがあります。\r\n      </p>\r\n      <ul>\r\n        <li>情報開示や共有についての同意又は承諾がある場合</li>\r\n        <li>裁判所や警察等の公的機関から、法律に基づく正式な照会を受けた場合</li>\r\n        <li>その他、正当行為等、違法性が阻却される場合</li>\r\n      </ul>\r\n\r\n      <h4>個人情報の利用</h4>\r\n      <p>当団体において、個人情報は以下の政治活動目的又はこれに付随する目的で利用されます。特定の用途での利用を拒絶したい場合やご自身の登録内容を抹消したい場合は、いつでも当団体にその旨を要求することができます。</p>\r\n      <ul>\r\n        <li>政策広報などのため、各種通信物の送信や質問等への返信を行うため</li>\r\n        <li>その他、何らかの理由で皆様とコンタクトする必要が生じたときのため</li>\r\n      </ul>\r\n\r\n      <h4>個人情報の収集と本人の同意</h4>\r\n      <p>\r\n        当団体は、政治団体であるため、第三者からご紹介を受けて個人情報を取得する場合がありますが、その場合は、すみやかに利用目的ならびに紹介者名をご本人様に通知し、ご承諾が得られない場合は、その際に登録された個人情報はすみやかに消去いたします。\r\n      </p>\r\n', 'プライバシーポリシー', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2023-01-30 20:13:21', '2023-01-30 11:13:21', '', 3, 'http://localhost:8081/?p=59', 0, 'revision', '', 0),
(60, 1, '2023-02-03 18:31:38', '0000-00-00 00:00:00', '', '自動下書き', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-02-03 18:31:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8081/?p=60', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_feeds`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_feeds` (
  `id` bigint(20) unsigned NOT NULL,
  `feed_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `feed_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `settings` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `author` bigint(20) unsigned NOT NULL DEFAULT 1,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `last_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_feed_caches`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_feed_caches` (
  `id` bigint(20) unsigned NOT NULL,
  `feed_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `cache_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `cache_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `cron_update` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  `last_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_instagram_feeds_posts`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_instagram_feeds_posts` (
  `record_id` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `instagram_id` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `feed_id` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `hashtag` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_instagram_feed_locator`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_instagram_feed_locator` (
  `id` bigint(20) unsigned NOT NULL,
  `feed_id` varchar(50) NOT NULL DEFAULT '',
  `post_id` bigint(20) unsigned NOT NULL,
  `html_location` varchar(50) NOT NULL DEFAULT 'unknown',
  `shortcode_atts` longtext NOT NULL,
  `last_update` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_instagram_posts`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_instagram_posts` (
  `id` int(11) unsigned NOT NULL,
  `created_on` datetime DEFAULT NULL,
  `instagram_id` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `time_stamp` datetime DEFAULT NULL,
  `top_time_stamp` datetime DEFAULT NULL,
  `json_data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `media_id` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `sizes` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `aspect_ratio` decimal(4,2) NOT NULL DEFAULT 0.00,
  `images_done` tinyint(1) NOT NULL DEFAULT 0,
  `last_requested` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_sbi_sources`
--

CREATE TABLE IF NOT EXISTS `wp_sbi_sources` (
  `id` bigint(20) unsigned NOT NULL,
  `account_id` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `account_type` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `privilege` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `access_token` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `info` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `error` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expires` datetime NOT NULL,
  `last_updated` datetime NOT NULL,
  `author` bigint(20) unsigned NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_termmeta`
--

CREATE TABLE IF NOT EXISTS `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'お知らせ', 'news', 0),
(2, 'politics', 'politics', 0),
(3, 'ニュースレター', 'newsletter', 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 2, 0),
(8, 1, 0),
(13, 3, 0),
(18, 1, 0),
(22, 3, 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, '3d-flip-book-category', '', 0, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'wpmaster'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '0'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '60'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:11:"121.1.137.0";}'),
(19, 1, 'hesh_surveyNoticeDismissedB', ''),
(20, 1, 'hesh_theme', 'wordpress'),
(21, 1, 'hesh_tabSize', '4'),
(22, 1, 'hesh_lineWrapping', '1'),
(23, 1, 'hesh_lineNumbers', '1'),
(24, 1, 'hesh_fontSize', '13'),
(25, 1, 'hesh_lineHeight', '1.5'),
(26, 1, 'hesh_matchBrackets', ''),
(27, 1, 'hesh_matchTags', ''),
(28, 1, 'hesh_highlightSelectionMatches', ''),
(29, 1, 'hesh_autoCloseTags', ''),
(30, 1, 'hesh_autoCloseBrackets', ''),
(31, 1, 'hesh_foldGutter', ''),
(32, 1, 'hesh_scrollbarStyle', ''),
(33, 1, 'hesh_keyMap', 'default'),
(35, 1, '_yoast_wpseo_profile_updated', '1674784650'),
(38, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(39, 1, 'wp_user-settings-time', '1666666235'),
(41, 1, 'closedpostboxes_3d-flip-book', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(42, 1, 'metaboxhidden_3d-flip-book', 'a:1:{i:0;s:7:"slugdiv";}'),
(43, 1, 'session_tokens', 'a:2:{s:64:"8bf55de33dc2149053b737c118d9e48276887649593ccfb0f1e2709c39c7d0fd";a:4:{s:10:"expiration";i:1675870295;s:2:"ip";s:13:"203.181.51.79";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1675697495;}s:64:"70db272c07499c8f2eb58b92862b8102a9e4ce774a8c3d95832e733e28ec9543";a:4:{s:10:"expiration";i:1675906900;s:2:"ip";s:12:"121.1.137.98";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36";s:5:"login";i:1675734100;}}'),
(44, 1, 'closedpostboxes_page', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(45, 1, 'metaboxhidden_page', 'a:4:{i:0;s:16:"commentstatusdiv";i:1;s:11:"commentsdiv";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}'),
(48, 1, '_yoast_settings_introduction', 'a:2:{s:23:"wistia_embed_permission";b:0;s:4:"show";b:0;}'),
(49, 1, 'closedpostboxes_dashboard', 'a:1:{i:0;s:32:"wp_mail_smtp_reports_widget_lite";}'),
(50, 1, 'metaboxhidden_dashboard', 'a:7:{i:0;s:21:"dashboard_site_health";i:1;s:19:"dashboard_right_now";i:2;s:18:"dashboard_activity";i:3;s:22:"fluentform_stat_widget";i:4;s:24:"wpseo-dashboard-overview";i:5;s:21:"dashboard_quick_press";i:6;s:17:"dashboard_primary";}'),
(51, 1, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:3:{s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:24:"yoast-seo/document-panel";i:2;s:14:"featured-image";}s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2023-01-30T01:43:18.800Z";}'),
(52, 1, '_yoast_alerts_dismissed', 'a:1:{s:26:"webinar-promo-notification";b:1;}'),
(53, 1, 'wp_mail_smtp_dash_widget_lite_hide_graph', '1');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'wpmaster', '$P$BQRdmKNs/vvRKJAVgAPlvc9dNcWN3v1', 'wpmaster', 'wp@clear-design.jp', 'http://localhost:8081/wp', '2022-10-07 04:42:12', '', 0, 'wpmaster');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_wpmailsmtp_debug_events`
--

CREATE TABLE IF NOT EXISTS `wp_wpmailsmtp_debug_events` (
  `id` int(10) unsigned NOT NULL,
  `content` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `initiator` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_type` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_wpmailsmtp_tasks_meta`
--

CREATE TABLE IF NOT EXISTS `wp_wpmailsmtp_tasks_meta` (
  `id` bigint(20) NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_wpmailsmtp_tasks_meta`
--

INSERT INTO `wp_wpmailsmtp_tasks_meta` (`id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_summary_report_email', 'W10=', '2022-10-07 05:24:16'),
(3, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2022-10-21 06:29:59');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_yoast_indexable`
--

CREATE TABLE IF NOT EXISTS `wp_yoast_indexable` (
  `id` int(10) unsigned NOT NULL,
  `permalink` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permalink_hash` varchar(40) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_type` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `object_sub_type` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `post_parent` bigint(20) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `breadcrumb_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `is_protected` tinyint(1) DEFAULT 0,
  `has_public_posts` tinyint(1) DEFAULT NULL,
  `number_of_pages` int(10) unsigned DEFAULT NULL,
  `canonical` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `primary_focus_keyword_score` int(11) DEFAULT NULL,
  `readability_score` int(11) DEFAULT NULL,
  `is_cornerstone` tinyint(1) DEFAULT 0,
  `is_robots_noindex` tinyint(1) DEFAULT 0,
  `is_robots_nofollow` tinyint(1) DEFAULT 0,
  `is_robots_noarchive` tinyint(1) DEFAULT 0,
  `is_robots_noimageindex` tinyint(1) DEFAULT 0,
  `is_robots_nosnippet` tinyint(1) DEFAULT 0,
  `twitter_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_description` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `twitter_image_source` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_title` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_description` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image` longtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_id` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_source` text COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `open_graph_image_meta` mediumtext COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `link_count` int(11) DEFAULT NULL,
  `incoming_link_count` int(11) DEFAULT NULL,
  `prominent_words_version` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1,
  `language` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `region` varchar(32) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_page_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schema_article_type` varchar(64) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `has_ancestors` tinyint(1) DEFAULT 0,
  `estimated_reading_time_minutes` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 1,
  `object_last_modified` datetime DEFAULT NULL,
  `object_published_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_yoast_indexable`
--

INSERT INTO `wp_yoast_indexable` (`id`, `permalink`, `permalink_hash`, `object_id`, `object_type`, `object_sub_type`, `author_id`, `post_parent`, `title`, `description`, `breadcrumb_title`, `post_status`, `is_public`, `is_protected`, `has_public_posts`, `number_of_pages`, `canonical`, `primary_focus_keyword`, `primary_focus_keyword_score`, `readability_score`, `is_cornerstone`, `is_robots_noindex`, `is_robots_nofollow`, `is_robots_noarchive`, `is_robots_noimageindex`, `is_robots_nosnippet`, `twitter_title`, `twitter_image`, `twitter_description`, `twitter_image_id`, `twitter_image_source`, `open_graph_title`, `open_graph_description`, `open_graph_image`, `open_graph_image_id`, `open_graph_image_source`, `open_graph_image_meta`, `link_count`, `incoming_link_count`, `prominent_words_version`, `created_at`, `updated_at`, `blog_id`, `language`, `region`, `schema_page_type`, `schema_article_type`, `has_ancestors`, `estimated_reading_time_minutes`, `version`, `object_last_modified`, `object_published_at`) VALUES
(1, 'http://localhost:8081/author/wpmaster', '41:57d096b0b9e964f77af5f08211134e18', 1, 'user', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 'https://secure.gravatar.com/avatar/3765b1833a54010958545d08e8c994d9?s=500&d=mm&r=g', NULL, NULL, 'gravatar-image', NULL, NULL, 'https://secure.gravatar.com/avatar/3765b1833a54010958545d08e8c994d9?s=500&d=mm&r=g', NULL, 'gravatar-image', NULL, NULL, NULL, NULL, '2022-10-07 05:22:40', '2023-01-30 02:13:22', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 11:13:21', '2022-10-07 04:42:12'),
(2, 'http://localhost:8081/privacy-policy.html', '45:bbe7b8c574126d3818aaee858555be8d', 3, 'post', 'page', 1, 0, NULL, NULL, 'プライバシーポリシー', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-07 05:22:40', '2023-01-30 02:13:22', 1, NULL, NULL, NULL, NULL, 0, 5, 2, '2023-01-30 11:13:21', '2022-10-07 04:42:12'),
(3, 'http://localhost:8081/contact.html', '36:57fe42a2bceaabbb8c071cbbd58f3472', 2, 'post', 'page', 1, 0, NULL, NULL, 'お問い合わせ', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2022-10-07 05:22:40', '2023-01-26 18:17:35', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2022-10-25 04:36:26', '2022-10-07 04:42:12'),
(4, 'http://localhost:8081/1.html', '32:c622fd46dcf5786eb8d76071ff4fdbdb', 1, 'post', 'post', 1, 0, NULL, NULL, '札幌市議会議員選挙（厚別区）の候補予定者に決定', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 90, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-07 05:22:40', '2023-01-30 00:13:14', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2023-01-30 09:13:13', '2023-01-30 07:00:12'),
(5, 'http://localhost:8081/c/news', '32:0b6b26c7f01764c4d304eb2ef7d9f55b', 1, 'term', 'category', NULL, NULL, NULL, NULL, 'お知らせ', NULL, NULL, 0, NULL, NULL, NULL, '未分類', 27, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-07 05:22:40', '2023-01-30 00:13:20', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 09:13:20', '2022-10-07 04:42:12'),
(6, NULL, NULL, NULL, 'system-page', '404', NULL, NULL, 'Page not found %%sep%% %%sitename%%', NULL, 'Error 404: Page not found', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-10-07 05:22:40', '2023-01-26 18:17:35', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(7, NULL, NULL, NULL, 'system-page', 'search-result', NULL, NULL, 'You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-10-07 05:22:40', '2023-01-26 18:17:35', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(8, NULL, NULL, NULL, 'date-archive', NULL, NULL, NULL, '%%date%% %%page%% %%sep%% %%sitename%%', '', NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-10-07 05:22:40', '2023-01-26 18:17:35', 1, NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL),
(9, 'http://localhost:8081/', '26:62b9fdbb6cd09bdbe807ba727be8e80e', NULL, 'home-page', NULL, NULL, NULL, '%%sitename%% %%sep%% %%sitedesc%%', '森きよのりは、リスナーが感じている声を札幌市政に直撞眉けたいというものでした。 ラジオを通して25年間、多くのリスナを重ね、実生活では大書な声を上げることができない人に寄り添い、声なき声に耳を傾けることの大切さを学びました。声なき声を言葉にすることを鍛えてき た経験を生かし、行政、議会、市民の双方向による街づくりを進めていきたい。 「森きよのり」と一緒に新しい札幌づく りに挑戦しませんか。', 'ホーム', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, '%%sitename%% %%sep%% %%sitedesc%%', '森きよのりは、リスナーが感じている声を札幌市政に直撞眉けたいというものでした。 ラジオを通して25年間、多くのリスナを重ね、実生活では大書な声を上げることができない人に寄り添い、声なき声に耳を傾けることの大切さを学びました。声なき声を言葉にすることを鍛えてき た経験を生かし、行政、議会、市民の双方向による街づくりを進めていきたい。 「森きよのり」と一緒に新しい札幌づく りに挑戦しませんか。', 'http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png', '34', 'set-by-user', '{"width":1024,"height":512,"filesize":348306,"url":"http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png","path":"/home/cdsv02/mori-kiyonori.com/public_html/wp/wp-content/uploads/2023/01/ogp.png","size":"full","id":34,"alt":"","pixels":524288,"type":"image/png"}', NULL, NULL, NULL, '2022-10-07 05:22:40', '2023-01-30 02:13:22', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 17:51:55', '2023-01-28 06:00:17'),
(11, NULL, '67:021829b336e2ee5e1ea8e19b20c4079a', 6, 'post', 'attachment', 1, 1, NULL, NULL, '57446296', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2022/10/57446296.jpeg', NULL, '6', 'attachment-image', NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2022/10/57446296.jpeg', '6', 'attachment-image', '{"width":1000,"height":566,"filesize":88882,"url":"http://localhost:8081/wp/wp-content/uploads/2022/10/57446296.jpeg","path":"/home/cdsv01/cld-net.com/public_html/w06.cld-net.com/wp/wp-content/uploads/2022/10/57446296.jpeg","size":"full","id":6,"alt":"","pixels":566000,"type":"image/jpeg"}', NULL, NULL, NULL, '2022-10-24 02:10:18', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-10-24 02:10:18', '2022-10-24 02:10:18'),
(12, 'http://localhost:8081/8.html', '32:033060ab7069232beb497708efde8ec1', 8, 'post', 'post', 1, 0, NULL, NULL, 'オフィシャルサイトを開設しました。', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 60, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/top-1024x963.png', NULL, NULL, 'first-content-image', NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/top-1024x963.png', NULL, 'first-content-image', NULL, 0, NULL, NULL, '2022-10-24 02:33:18', '2023-01-30 00:13:03', 1, NULL, NULL, NULL, NULL, 0, 1, 2, '2023-01-30 09:13:03', '2023-01-30 06:00:17'),
(13, 'http://localhost:8081/3d-flip-book-category/newsletter', '58:66db5120ccf87a2bb6400566b9e9c158', 3, 'term', '3d-flip-book-category', NULL, NULL, NULL, NULL, 'ニュースレター', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-24 07:24:30', '2023-01-29 23:41:26', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 08:41:26', '2022-10-24 07:26:49'),
(14, 'http://localhost:8081/?post_type=3d-flip-book&p=13', '52:f7939ae05116a2b51f83d5903de344b1', 13, 'post', '3d-flip-book', 1, 0, NULL, NULL, '立憲民主号外', 'trash', 0, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-24 07:25:37', '2023-01-27 05:38:22', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-27 14:38:22', '2022-10-24 07:26:49'),
(15, NULL, '90:b444cac1903e9f8372a22f8b237801fd', 15, 'post', 'attachment', 1, 13, NULL, NULL, '22.8清水たかひろA4巻三-3', 'inherit', NULL, 0, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-10-24 07:26:03', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-10-24 07:26:03', '2022-10-24 07:26:03'),
(16, 'http://localhost:8081/18.html', '33:d290d8b18f29dabfe70c175f88f619da', 18, 'post', 'post', 1, 0, NULL, NULL, '新たなスタートを切ります。（決意表明）', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 30, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2022-10-25 08:05:19', '2023-01-30 00:13:20', 1, NULL, NULL, NULL, NULL, 0, 2, 2, '2023-01-30 09:13:20', '2023-01-30 08:00:29'),
(17, NULL, '67:a1736406e58b7d76f23a171b61f95a4f', 19, 'post', 'attachment', 1, 18, NULL, NULL, '32324171', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2022/10/32324171.jpeg', NULL, '19', 'attachment-image', NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2022/10/32324171.jpeg', '19', 'attachment-image', '{"width":1000,"height":685,"filesize":213792,"url":"http://localhost:8081/wp/wp-content/uploads/2022/10/32324171.jpeg","path":"/home/cdsv01/cld-net.com/public_html/w06.cld-net.com/wp/wp-content/uploads/2022/10/32324171.jpeg","size":"full","id":19,"alt":"","pixels":685000,"type":"image/jpeg"}', NULL, NULL, NULL, '2022-10-25 08:05:51', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2022-10-25 08:05:51', '2022-10-25 08:05:51'),
(18, 'http://localhost:8081/3d-flip-book/%e3%83%91%e3%83%b3%e3%83%95%e3%83%ac%e3%83%83%e3%83%88', '93:013c5840e919adff16baa77ddf2cc702', 22, 'post', '3d-flip-book', 1, 0, NULL, NULL, 'パンフレット', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-27 14:38:56', '2023-01-29 23:41:26', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-30 08:41:26', '2023-01-27 14:40:26'),
(19, NULL, '82:f4c547eaf8cd9c6782db66083dae4356', 24, 'post', 'attachment', 1, 22, NULL, NULL, 'mori-kiyonori_compressed', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-01-27 14:39:24', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 1, NULL, 2, '2023-01-27 14:39:24', '2023-01-27 14:39:24'),
(22, 'http://localhost:8081/newslist.html', '37:0c43d29c4520eb997ac3458b314ddaab', 27, 'post', 'page', 1, 0, NULL, NULL, 'ニュース', 'publish', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, '2023-01-27 15:06:05', '2023-01-27 06:06:19', 1, NULL, NULL, NULL, NULL, 0, 0, 2, '2023-01-27 15:06:18', '2023-01-27 15:06:18'),
(23, NULL, '84:bdeef7494f5c1e967014049825c8448b', 30, 'post', 'attachment', 1, 22, NULL, NULL, 'maki3ori_A4_3_hidari_omote', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/maki3ori_A4_3_hidari_omote.jpg', NULL, '30', 'attachment-image', NULL, NULL, NULL, '30', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-27 15:09:33', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-27 15:09:33', '2023-01-27 15:09:33'),
(24, NULL, '62:18a1e415d5e30d50e6d31974f09596d7', 31, 'post', 'attachment', 1, 0, NULL, NULL, 'favi', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/favi.png', NULL, '31', 'attachment-image', NULL, NULL, NULL, '31', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-27 15:20:20', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-27 15:20:20', '2023-01-27 15:20:20'),
(25, NULL, '70:bf5875d9bb87de2a7eecef43bdc02718', 32, 'post', 'attachment', 1, 0, NULL, NULL, 'cropped-favi.png', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/cropped-favi.png', NULL, '32', 'attachment-image', NULL, NULL, NULL, '32', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-27 15:20:25', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-27 15:20:25', '2023-01-27 15:20:25'),
(26, NULL, '61:2faa1076e712e6f99707c1f89378b5d4', 34, 'post', 'attachment', 1, 0, NULL, NULL, 'ogp', 'inherit', 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/ogp.png', NULL, '34', 'attachment-image', NULL, NULL, NULL, '34', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-27 15:25:15', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-27 15:25:15', '2023-01-27 15:25:15'),
(27, NULL, '62:8bac1dac9876e2bbcfc82c94d9fb9877', 45, 'post', 'attachment', 1, 8, NULL, NULL, 'test', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/test.png', NULL, '45', 'attachment-image', NULL, NULL, NULL, '45', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-29 04:46:24', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-29 04:46:24', '2023-01-29 04:46:24'),
(28, NULL, '64:b8ec5adb2dc12189b6e0179bd4281d04', 47, 'post', 'attachment', 1, 8, NULL, NULL, 'test-1', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/test-1.png', NULL, '47', 'attachment-image', NULL, NULL, NULL, '47', 'attachment-image', NULL, NULL, 0, NULL, '2023-01-29 04:46:57', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-29 04:46:57', '2023-01-29 04:46:57'),
(29, NULL, '69:99bea5f8696ef80ee9ec1e872f368d7f', 55, 'post', 'attachment', 1, 18, NULL, NULL, 'profile_sp', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/profile_sp.webp', NULL, '55', 'attachment-image', NULL, NULL, NULL, '55', 'attachment-image', NULL, NULL, NULL, NULL, '2023-01-30 02:38:00', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 02:38:00', '2023-01-30 02:38:00'),
(30, NULL, '61:fb22412cc33e0b779322d20527c6e966', 57, 'post', 'attachment', 1, 8, NULL, NULL, 'top', 'inherit', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, 'http://localhost:8081/wp/wp-content/uploads/2023/01/top.png', NULL, '57', 'attachment-image', NULL, NULL, NULL, '57', 'attachment-image', NULL, NULL, 1, NULL, '2023-01-30 07:39:05', '2023-01-30 08:32:07', 1, NULL, NULL, NULL, NULL, 0, NULL, 2, '2023-01-30 07:39:05', '2023-01-30 07:39:05');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_yoast_indexable_hierarchy`
--

CREATE TABLE IF NOT EXISTS `wp_yoast_indexable_hierarchy` (
  `indexable_id` int(10) unsigned NOT NULL,
  `ancestor_id` int(10) unsigned NOT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `blog_id` bigint(20) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_yoast_indexable_hierarchy`
--

INSERT INTO `wp_yoast_indexable_hierarchy` (`indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES
(1, 0, 0, 1),
(2, 0, 0, 1),
(3, 0, 0, 1),
(4, 0, 0, 1),
(5, 0, 0, 1),
(7, 0, 0, 1),
(8, 0, 0, 1),
(9, 0, 0, 1),
(11, 4, 1, 1),
(12, 0, 0, 1),
(13, 0, 0, 1),
(14, 0, 0, 1),
(15, 14, 1, 1),
(16, 0, 0, 1),
(17, 16, 1, 1),
(18, 0, 0, 1),
(19, 18, 1, 1),
(22, 0, 0, 1),
(23, 18, 1, 1),
(24, 0, 0, 1),
(25, 0, 0, 1),
(26, 0, 0, 1),
(27, 12, 1, 1),
(28, 12, 1, 1),
(29, 16, 1, 1),
(30, 12, 1, 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_yoast_migrations`
--

CREATE TABLE IF NOT EXISTS `wp_yoast_migrations` (
  `id` int(10) unsigned NOT NULL,
  `version` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_yoast_migrations`
--

INSERT INTO `wp_yoast_migrations` (`id`, `version`) VALUES
(1, '20171228151840'),
(2, '20171228151841'),
(3, '20190529075038'),
(4, '20191011111109'),
(5, '20200408101900'),
(6, '20200420073606'),
(7, '20200428123747'),
(8, '20200428194858'),
(9, '20200429105310'),
(10, '20200430075614'),
(11, '20200430150130'),
(12, '20200507054848'),
(13, '20200513133401'),
(14, '20200609154515'),
(15, '20200616130143'),
(16, '20200617122511'),
(17, '20200702141921'),
(18, '20200728095334'),
(19, '20201202144329'),
(20, '20201216124002'),
(21, '20201216141134'),
(22, '20210817092415'),
(23, '20211020091404');

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_yoast_primary_term`
--

CREATE TABLE IF NOT EXISTS `wp_yoast_primary_term` (
  `id` int(10) unsigned NOT NULL,
  `post_id` bigint(20) DEFAULT NULL,
  `term_id` bigint(20) DEFAULT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `blog_id` bigint(20) NOT NULL DEFAULT 1
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- テーブルのデータのダンプ `wp_yoast_primary_term`
--

INSERT INTO `wp_yoast_primary_term` (`id`, `post_id`, `term_id`, `taxonomy`, `created_at`, `updated_at`, `blog_id`) VALUES
(1, 1, 1, 'category', '2022-10-24 02:10:27', '2023-01-30 00:13:14', 1),
(2, 8, 1, 'category', '2022-10-24 02:33:18', '2023-01-30 00:13:03', 1),
(3, 18, 1, 'category', '2022-10-25 08:05:19', '2023-01-30 00:13:20', 1);

-- --------------------------------------------------------

--
-- テーブルの構造 `wp_yoast_seo_links`
--

CREATE TABLE IF NOT EXISTS `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `target_post_id` bigint(20) unsigned DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `indexable_id` int(10) unsigned DEFAULT NULL,
  `target_indexable_id` int(10) unsigned DEFAULT NULL,
  `height` int(10) unsigned DEFAULT NULL,
  `width` int(10) unsigned DEFAULT NULL,
  `size` int(10) unsigned DEFAULT NULL,
  `language` varchar(32) DEFAULT NULL,
  `region` varchar(32) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `wp_yoast_seo_links`
--

INSERT INTO `wp_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`, `indexable_id`, `target_indexable_id`, `height`, `width`, `size`, `language`, `region`) VALUES
(2, '/privacy.html', 2, NULL, 'internal', 3, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'http://localhost:8081/wp/wp-content/uploads/2023/01/top-1024x963.png', 8, 57, 'image-in', 12, 30, 1803, 1917, 2096973, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`);

--
-- Indexes for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `wp_fb3d_pages`
--
ALTER TABLE `wp_fb3d_pages`
  ADD PRIMARY KEY (`page_ID`),
  ADD KEY `page_post_ID` (`page_post_ID`),
  ADD KEY `page_source_type` (`page_source_type`),
  ADD KEY `page_thumbnail_type` (`page_thumbnail_type`);

--
-- Indexes for table `wp_ff_scheduled_actions`
--
ALTER TABLE `wp_ff_scheduled_actions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_entry_details`
--
ALTER TABLE `wp_fluentform_entry_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_forms`
--
ALTER TABLE `wp_fluentform_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_form_analytics`
--
ALTER TABLE `wp_fluentform_form_analytics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_form_meta`
--
ALTER TABLE `wp_fluentform_form_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_logs`
--
ALTER TABLE `wp_fluentform_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_submissions`
--
ALTER TABLE `wp_fluentform_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_fluentform_submission_meta`
--
ALTER TABLE `wp_fluentform_submission_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_sbi_feeds`
--
ALTER TABLE `wp_sbi_feeds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `author` (`author`);

--
-- Indexes for table `wp_sbi_feed_caches`
--
ALTER TABLE `wp_sbi_feed_caches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feed_id` (`feed_id`(191));

--
-- Indexes for table `wp_sbi_instagram_feeds_posts`
--
ALTER TABLE `wp_sbi_instagram_feeds_posts`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `hashtag` (`hashtag`(191)),
  ADD KEY `feed_id` (`feed_id`(191));

--
-- Indexes for table `wp_sbi_instagram_feed_locator`
--
ALTER TABLE `wp_sbi_instagram_feed_locator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feed_id` (`feed_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `wp_sbi_instagram_posts`
--
ALTER TABLE `wp_sbi_instagram_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_sbi_sources`
--
ALTER TABLE `wp_sbi_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_type` (`account_type`(191)),
  ADD KEY `author` (`author`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wpmailsmtp_debug_events`
--
ALTER TABLE `wp_wpmailsmtp_debug_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wp_wpmailsmtp_tasks_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wp_yoast_indexable`
--
ALTER TABLE `wp_yoast_indexable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_type_and_sub_type` (`object_type`,`object_sub_type`),
  ADD KEY `object_id_and_type` (`object_id`,`object_type`),
  ADD KEY `permalink_hash_and_object_type` (`permalink_hash`,`object_type`),
  ADD KEY `subpages` (`post_parent`,`object_type`,`post_status`,`object_id`),
  ADD KEY `prominent_words` (`prominent_words_version`,`object_type`,`object_sub_type`,`post_status`),
  ADD KEY `published_sitemap_index` (`object_published_at`,`is_robots_noindex`,`object_type`,`object_sub_type`);

--
-- Indexes for table `wp_yoast_indexable_hierarchy`
--
ALTER TABLE `wp_yoast_indexable_hierarchy`
  ADD PRIMARY KEY (`indexable_id`,`ancestor_id`),
  ADD KEY `indexable_id` (`indexable_id`),
  ADD KEY `ancestor_id` (`ancestor_id`),
  ADD KEY `depth` (`depth`);

--
-- Indexes for table `wp_yoast_migrations`
--
ALTER TABLE `wp_yoast_migrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wp_yoast_migrations_version` (`version`);

--
-- Indexes for table `wp_yoast_primary_term`
--
ALTER TABLE `wp_yoast_primary_term`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_taxonomy` (`post_id`,`taxonomy`),
  ADD KEY `post_term` (`post_id`,`term_id`);

--
-- Indexes for table `wp_yoast_seo_links`
--
ALTER TABLE `wp_yoast_seo_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `link_direction` (`post_id`,`type`),
  ADD KEY `indexable_link_direction` (`indexable_id`,`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  MODIFY `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  MODIFY `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2271;
--
-- AUTO_INCREMENT for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  MODIFY `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  MODIFY `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_fb3d_pages`
--
ALTER TABLE `wp_fb3d_pages`
  MODIFY `page_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_ff_scheduled_actions`
--
ALTER TABLE `wp_ff_scheduled_actions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_fluentform_entry_details`
--
ALTER TABLE `wp_fluentform_entry_details`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `wp_fluentform_forms`
--
ALTER TABLE `wp_fluentform_forms`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_fluentform_form_analytics`
--
ALTER TABLE `wp_fluentform_form_analytics`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `wp_fluentform_form_meta`
--
ALTER TABLE `wp_fluentform_form_meta`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `wp_fluentform_logs`
--
ALTER TABLE `wp_fluentform_logs`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `wp_fluentform_submissions`
--
ALTER TABLE `wp_fluentform_submissions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_fluentform_submission_meta`
--
ALTER TABLE `wp_fluentform_submission_meta`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12865;
--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `wp_sbi_feeds`
--
ALTER TABLE `wp_sbi_feeds`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_sbi_feed_caches`
--
ALTER TABLE `wp_sbi_feed_caches`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_sbi_instagram_feeds_posts`
--
ALTER TABLE `wp_sbi_instagram_feeds_posts`
  MODIFY `record_id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_sbi_instagram_feed_locator`
--
ALTER TABLE `wp_sbi_instagram_feed_locator`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_sbi_instagram_posts`
--
ALTER TABLE `wp_sbi_instagram_posts`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_sbi_sources`
--
ALTER TABLE `wp_sbi_sources`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `wp_wpmailsmtp_debug_events`
--
ALTER TABLE `wp_wpmailsmtp_debug_events`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `wp_wpmailsmtp_tasks_meta`
--
ALTER TABLE `wp_wpmailsmtp_tasks_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `wp_yoast_indexable`
--
ALTER TABLE `wp_yoast_indexable`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `wp_yoast_migrations`
--
ALTER TABLE `wp_yoast_migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `wp_yoast_primary_term`
--
ALTER TABLE `wp_yoast_primary_term`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `wp_yoast_seo_links`
--
ALTER TABLE `wp_yoast_seo_links`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
